function G_k = Freespace_G_k_generate(lambda,user_position,Vs,K,NumdS,delta_x,delta_y)
G_k=zeros(3,3,K,NumdS);

for k=1:K
    for a=1:delta_x
        for b=1:delta_y                          
            G_k(:,:,k,a+delta_x*(b-1))=Green(user_position(:,k),Vs(:,a+delta_x*(b-1)),lambda);
        end
    end
end
end

