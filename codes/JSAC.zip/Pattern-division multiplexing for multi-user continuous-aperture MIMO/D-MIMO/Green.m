function G = Green(r,s,lambda)

kappa=2*pi/lambda;

p=r-s;
p_hat=p/norm(p);
%a=1;
G=exp(1j*kappa*norm(p))/4/pi/norm(p)*(eye(3)-p_hat*p_hat'+1j*lambda/2/pi/norm(p)*(eye(3)-3*p_hat*p_hat'));

end

