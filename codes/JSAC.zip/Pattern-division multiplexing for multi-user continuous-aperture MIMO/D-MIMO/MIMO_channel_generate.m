function H_k = MIMO_channel_generate(lambda,user_position,S_m,K,M)

H_k_m=zeros(3,3,K,M);
H_k = zeros(3,3*M,K);

A_m = (lambda^2/4/pi);

S_m_element = zeros(3,16,M);   % 量化16份

for m =1:M
for a = 1:4
    for b = 1:4
        S_m_element(1,a+(b-1)*4,m) = S_m(1,m) + a * sqrt(A_m)/8 - sqrt(A_m)/4;
        S_m_element(2,a+(b-1)*4,m) = S_m(2,m) + b * sqrt(A_m)/8 - sqrt(A_m)/4;
    end
end
end

for k = 1:K
   for m = 1:M
       H_k_m(:,:,k,m) = 0* H_k_m(:,:,k,m);
       
       for jj = 1:16
            temp0 = squeeze(S_m_element(:,jj,m));
            H_k_m(:,:,k,m) = squeeze(H_k_m(:,:,k,m)) + Green(user_position(:,k),temp0,lambda) * A_m/16;
       end

       H_k(:,3*(m-1)+1:3*m,k) = H_k_m(:,:,k,m);
   end
end

end