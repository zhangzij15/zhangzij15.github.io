function P = w_k_2_power(K,dS,NumdS,NumF,f_base,w_k)

% w_k_uv = w_k_2_w_k_uv(K,NumF,w_k);
% theta_k = w_k_2_theta_k(K,NumdS,NumF,w_k_uv,f_base);
% 
% temp=0;
% for n=1:NumdS
%         temp=temp+(norm(theta_k(:,:,n),'fro'))^2*dS;
% end
% 
% P=temp;

P=0;

for k=1:K
    P=P+norm(w_k(:,k))^2;
end

end

