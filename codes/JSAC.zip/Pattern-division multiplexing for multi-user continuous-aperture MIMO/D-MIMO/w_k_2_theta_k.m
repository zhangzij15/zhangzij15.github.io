function theta_k = w_k_2_theta_k(K,NumdS,NumF,w_k_uv,f_base)

theta_k=zeros(3,K,NumdS);                   %发射机表面电流密度 K个用户

for n=1:NumdS
for k=1:K
    for m=1:NumF         
            theta_k(:,k,n)=theta_k(:,k,n)+w_k_uv(:,k,m)*f_base(m,n);         
    end   
end
end



end