function [alpha_k]= alpha_k_uv_2_alpha_k(K,NumF,alpha_k_uv)

alpha_k=zeros(3*NumF,K);

for k=1:K
    for m=1:NumF  
        alpha_k((m-1)*3+1:1:(m)*3,k)=alpha_k_uv(:,k,m);    
    end
end

end

