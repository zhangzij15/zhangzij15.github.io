function w_k_uv = w_k_2_w_k_uv(K,NumF,w_k)

w_k_uv=zeros(3,K,NumF);

for k=1:K
    for m=1:NumF  
        w_k_uv(:,k,m)=w_k((m-1)*3+1:1:(m)*3,k);    
    end
end

end

