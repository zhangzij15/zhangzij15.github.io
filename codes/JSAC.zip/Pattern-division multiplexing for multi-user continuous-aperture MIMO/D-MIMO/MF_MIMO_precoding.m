function [Psi_k,theta_k,sum_rate] = MF_MIMO_precoding(K,NumdS,dS,G_k,Psi_k,theta_k,P_T,sigma_2)

Q=1;
sum_rate_temp=zeros(Q,1);


for k = 1:K
     Psi_k(1,k) = 0;     %ֻx�᷽�򼫻�
     Psi_k(2,k) = 1;
     Psi_k(3,k) = 0;
end

h_k = h_k_update(K,NumdS,G_k,Psi_k);

theta_k = h_k;                  %ת��Ϊ����������ܶ�
temp=0;
for n=1:NumdS
    for k=1:K         
        temp=temp+norm(theta_k(:,k,n))^2*dS;
    end
end
theta_k=theta_k*sqrt(P_T)/sqrt(temp);

[sum_rate_temp,SINR_k] = Capacity_calculate(K,NumdS,dS,G_k,Psi_k,theta_k,sigma_2);

sum_rate=max(sum_rate_temp);

end

