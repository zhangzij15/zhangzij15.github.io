function alpha_k_uv = alpha_k_uv_update(K,NumdS,NumF,dS,h_k,f_base,Ls_x,Ls_y)

alpha_k_uv=zeros(3,K,NumF);

for k=1:K
    for m=1:NumF       
        alpha_k_uv(:,k,m)=zeros(3,1);      
        for n=1:NumdS
            alpha_k_uv(:,k,m)=alpha_k_uv(:,k,m)+1/sqrt(Ls_x*Ls_y)*h_k(:,k,n)*(f_base(m,n))'*dS;
        end
    end
end



end

