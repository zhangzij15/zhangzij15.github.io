function h_k = h_k_update(K,NumdS,G_k,Psi_k)

h_k=zeros(3,K,NumdS);

for k=1:K
    for n=1:NumdS
        h_k(:,k,n)=(G_k(:,:,k,n))'*Psi_k(:,k);
    end
end

end