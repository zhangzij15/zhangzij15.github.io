load('main_3_15.mat');
h1_11=sum_rate_H_MIMO_Upper;
h2_11=sum_rate_H_MIMO_freespace;

load('Digital_MIMO_area.mat');

load('main_3_9.mat');
h1_9=sum_rate_H_MIMO_Upper;
h2_9=sum_rate_H_MIMO_freespace;

load('main_3_3.mat');
h1_3=sum_rate_H_MIMO_Upper;
h2_3=sum_rate_H_MIMO_freespace;

figure;
hold on;
grid on;
box on;

a=plot(Ls_Mianji,h1_11,'--k','LineWidth',1.5);
b=plot(Ls_Mianji,h2_11,'-pr','LineWidth',1.5,'color',String2Color('#ff0b00')/256);
c=plot(Ls_Mianji,h2_9,'--or','LineWidth',1.5,'color',String2Color('#a626aa')/256);
d=plot(Ls_Mianji,h2_3,'->m','LineWidth',1.5,'color',String2Color('#f39c12')/256);
e=plot(Ls_Mianji,sum_rate_MF,'-bs','LineWidth',1.5);
f=plot(Ls_Mianji,sum_rate_ditial,'-.d','LineWidth',1.5);

f.Color = String2Color('#8b0000')/256;

set(gca, 'XTick', [0:0.1:1]);

xlabel('Aperture area $A_{\rm T}$ (${\rm m}^2$)','Interpreter','latex');
ylabel('Sum-rate (bps/Hz)','Interpreter','latex');
legend([a b c d e f],'Upper bound (without interference)','Proposed PDM ($N_F=225$)','Proposed PDM ($N_F=81$)','Proposed PDM ($N_F=9$)','MF scheme','Fully-digital MIMO','Interpreter','latex','FontSize',12);
set(gca,'FontName','Times','FontSize',14);

