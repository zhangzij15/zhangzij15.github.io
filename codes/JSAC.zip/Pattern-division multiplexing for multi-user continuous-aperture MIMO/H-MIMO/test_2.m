load('main_2_15.mat');
h1_11=sum_rate_H_MIMO_Upper;
h2_11=sum_rate_H_MIMO_freespace;

load('Digital_MIMO_power.mat');

load('main_2_9.mat');
h1_9=sum_rate_H_MIMO_Upper;
h2_9=sum_rate_H_MIMO_freespace;

load('main_2_3.mat');
h1_3=sum_rate_H_MIMO_Upper;
h2_3=sum_rate_H_MIMO_freespace;

figure;

slg = semilogx(P_T,h1_11,'--k',P_T,h2_11,'-rp',P_T,h2_9,'--o',P_T,h2_3,'-m>' ...
    ,P_T,sum_rate_MF,'-bs',P_T,sum_rate_ditial,'-.d','LineWidth',1.5);

grid on;
slg(2).Color = String2Color('#ff0b00')/256;
slg(3).Color = String2Color('#a626aa')/256;
slg(4).Color = String2Color('#f39c12')/256;
slg(6).Color = String2Color('#8b0000')/256;

hold on;

box on;
xlabel('Maximum transmit power $P_{\rm T}$ (${\rm mA}^2$)','Interpreter','latex');
ylabel('Sum-rate (bps/Hz)','Interpreter','latex');
legend('Upper bound (without interference)','Proposed PDM ($N_F=225$)','Proposed PDM ($N_F=81$)','Proposed PDM ($N_F=9$)','MF scheme','Fully-digital MIMO','Interpreter','latex','FontSize',12);
set(gca,'FontName','Times','FontSize',14);
ylim([0 20])
