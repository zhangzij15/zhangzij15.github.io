function [Psi_k,theta_k,sum_rate] = Upperbound_H_MIMO_precoding2(K,NumdS,NumF,dS,G_k,Psi_k,theta_k,f_base,P_T,sigma_2,Ls_x,Ls_y)

Q=5;
sum_rate_temp=zeros(Q,1);

for q=1:Q
[sum_rate_temp(q),SINR_k] = Upper_Capacity_calculate(K,NumdS,dS,G_k,Psi_k,theta_k,sigma_2);
end

sum_rate=max(sum_rate_temp);

end

