function createfigure(X1, YMatrix1)
%CREATEFIGURE(X1, YMatrix1)
%  X1:  x 数据的向量
%  YMATRIX1:  y 数据的矩阵

%  由 MATLAB 于 16-Oct-2021 16:15:43 自动生成

% 创建 figure
figure('OuterPosition',[459 232 576 514]);

% 创建 axes
axes1 = axes;
hold(axes1,'on');

% 使用 semilogx 的矩阵输入创建多行
semilogx1 = semilogx(X1,YMatrix1,'LineWidth',1.5);
set(semilogx1(1),'DisplayName','Upper bound (without interference)',...
    'LineStyle','--',...
    'Color',[0 0 0]);
set(semilogx1(2),'DisplayName','Proposed EM-waveforming',...
    'Marker','pentagram',...
    'Color',[1 0 0]);
set(semilogx1(3),'DisplayName','Wavenumber-division multiplexing',...
    'Marker','square',...
    'Color',[0 0 1]);

% 创建 ylabel
ylabel('Capacity (bps/Hz)','FontName','Times','Interpreter','latex');

% 创建 xlabel
xlabel('Maximum transmit power $P_{\rm T}$ (${\rm A}^2$)',...
    'FontName','Times',...
    'Interpreter','latex');

% 取消以下行的注释以保留坐标区的 X 范围
% xlim(axes1,[1e-06 0.001]);
% 取消以下行的注释以保留坐标区的 Y 范围
% ylim(axes1,[0 14]);
box(axes1,'on');
grid(axes1,'on');
hold(axes1,'off');
% 设置其余坐标区属性
set(axes1,'FontName','Times','FontSize',14,'XMinorTick','on','XScale','log');
% 创建 legend
legend1 = legend(axes1,'show');
set(legend1,...
    'Position',[0.151943556214635 0.751746033789619 0.539723110452031 0.149047617004031],...
    'Interpreter','latex',...
    'FontSize',12);

