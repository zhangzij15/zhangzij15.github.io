function w_k = w_k_optimize(K,dS,NumdS,NumF,f_base,rho_k,alpha_k,P_T)


left_zeta=0;
right_zeta=0.001;

w_k_left = w_k_update(K,NumF,rho_k,left_zeta,alpha_k);
P_left = w_k_2_power(K,dS,NumdS,NumF,f_base,w_k_left);

if P_left<=P_T
    w_k=w_k_left; return;
end

w_k_right = w_k_update(K,NumF,rho_k,right_zeta,alpha_k);
P_right = w_k_2_power(K,dS,NumdS,NumF,f_base,w_k_right); 
while (P_right>P_T)
    right_zeta=10*right_zeta;
    w_k_right = w_k_update(K,NumF,rho_k,right_zeta,alpha_k);
    P_right = w_k_2_power(K,dS,NumdS,NumF,f_base,w_k_right);
end

while (abs(P_left-P_right)>0.001)
    center_zeta=(left_zeta+right_zeta)/2;
    w_k_center = w_k_update(K,NumF,rho_k,center_zeta,alpha_k);
    P_center = w_k_2_power(K,dS,NumdS,NumF,f_base,w_k_center);
    
    if P_center==P_T
        w_k=w_k_center; return;
    end
    
    if P_center<P_T
        right_zeta=center_zeta;
    else
        left_zeta=center_zeta;       
    end    
    
    w_k_left = w_k_update(K,NumF,rho_k,left_zeta,alpha_k);
    P_left = w_k_2_power(K,dS,NumdS,NumF,f_base,w_k_left);
    w_k_right = w_k_update(K,NumF,rho_k,right_zeta,alpha_k);
    P_right = w_k_2_power(K,dS,NumdS,NumF,f_base,w_k_right);
    
    
end

w_k=w_k_center;

end

