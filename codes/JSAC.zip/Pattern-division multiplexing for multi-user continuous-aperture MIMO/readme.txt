This simulation code package is mainly used to reproduce the results of the following paper [1]:

[1] Z. Zhang and L. Dai, ��Pattern-division multiplexing for multi-user continuous-aperture MIMO,�� IEEE J. Sel. Areas Commun., vol. 41, no. 8, pp. 2350-2366, Aug. 2023.

*********************************************************************************************************************************
If you use this simulation code package in any way, please cite the original paper [1] above. 

The author in charge of this simulation code pacakge is: Zijian Zhang (email: zhangzj20@mails.tsinghua.edu.cn).

Reference: We highly respect reproducible research, so we try to provide the simulation codes for our published papers (more information can be found at: 
http://oa.ee.tsinghua.edu.cn/dailinglong/publications/publications.html). 

Please note that the MATLAB R2023a and CVX 3.1 are used for this simulation code package,  and there may be some imcompatibility problems among different software versions. 

Copyright reserved by the Broadband Communications and Signal Processing Laboratory (led by Dr. Linglong Dai), Tsinghua National Laboratory
for Information Science and Technology (TNList), Department of Electronic Engineering, Tsinghua University, Beijing 100084, China. 

*********************************************************************************************************************************
Abstract of the paper: 

In recent years, thanks to the advances in meta-materials, the concept of continuous-aperture MIMO (CAP-MIMO) is reinvestigated to achieve improved communication performance with limited antenna apertures. Unlike the classical MIMO composed of discrete antennas, CAP-MIMO has a quasi-continuous antenna surface, which is expected to generate any current distribution (i.e., pattern) and induce controllable spatial electromagnetic (EM) waves. In this way, the information is directly modulated on the EM waves, which makes it promising to approach the ultimate capacity of finite apertures. The pattern design is the key factor to determine the communication performance of CAP-MIMO, but it has not been well studied in the literature. In this paper, we develop pattern-division multiplexing (PDM) to design the patterns for CAP-MIMO. Specifically, we first study and model a typical multi-user CAP-MIMO system, which allows us to formulate the sum-rate maximization problem. Then, we develop a general PDM technique to transform the design of the continuous pattern functions to the design of their projection lengths on finite orthogonal bases, which can overcome the challenge of functional programming. Utilizing PDM, we further propose a block coordinate descent (BCD) based pattern design scheme to solve the formulated sum-rate maximization problem. Simulation results show that, the sum-rate achieved by the proposed scheme is higher than that achieved by benchmark schemes, which demonstrates the effectiveness of the developed PDM for CAP-MIMO.

*********************************************************************************************************************************
How to use this simulation code package?

1. Run "H-MIMO/test_2.m" to obtain the result in Fig. 6.

2. Run "H-MIMO/test_3.m" to obtain the results in Fig. 5.

3. Run "H-MIMO/new_main_2.m" and "H-MIMO/new_main_3.m" to obtain the curve "Proposed PDM".

4. Run "D-MIMO/Digital_MIMO_power.m" and  "D-MIMO/Digital_MIMO_area.m" to obtain the curve "MF scheme" and "Fully-digital MIMO".

5. Run "D-MIMO/H_MIMO_position.m" to obtain the results in Fig. 9.
*********************************************************************************************************************************
Enjoy the reproducible research!






