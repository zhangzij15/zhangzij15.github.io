function [Psi_k,theta_k,sum_rate] = Wavenumber_precoding(K,NumdS,NumF,dS,G_k,Psi_k,theta_k,f_base,P_T,sigma_2,Ls_x,Ls_y,Vs)

f_base=zeros(K,NumdS);           %���ָ�������
for k=1:K
	for n=1:NumdS
        f_base(k,n)=1/sqrt(Ls_x*Ls_y)*exp(1j*2*pi*(k-(K/2))*(Vs(1,n)-Ls_x/2)/Ls_x)*exp(1j*2*pi*(k-(K/2))*(Vs(2,n)-Ls_y/2)/Ls_y);      
	end  
end

Q=5;
sum_rate_temp=zeros(Q,1);
for q=1:Q

[sum_rate_temp(q),SINR_k] = Capacity_calculate(K,NumdS,dS,G_k,Psi_k,theta_k,sigma_2);

rho_k = rho_k_update(K,NumdS,dS,G_k,Psi_k,theta_k);

Psi_k = Psi_update(K,NumdS,dS,rho_k,G_k,theta_k,sigma_2);

theta_k=zeros(3,K,NumdS); 

for k=1:K
    for n=1:NumdS
        theta_k(1,k,n)=f_base(k,n); 
        theta_k(2,k,n)=f_base(k,n); 
        theta_k(3,k,n)=0; 
    end
end

temp=0;
for n=1:NumdS
    for k=1:K         
        temp=temp+norm(theta_k(:,k,n))^2*dS;
    end
end
theta_k=theta_k*sqrt(P_T)/sqrt(temp);

% [sum_rate_temp(q),SINR_k] = Capacity_calculate(K,NumdS,dS,G_k,Psi_k,theta_k,sigma_2);
end

plot(sum_rate_temp);



sum_rate=max(sum_rate_temp);

end

