function [sum_rate,SINR_k] = Capacity_calculate(K,NumdS,dS,G_k,Psi_k,theta_k,sigma_2)
SINR_k=zeros(K,1);
sum_rate=0;

%load('temp.mat');

%for n=1:NumdS
%    theta_k(:,1,n)=js(:,n);
%    Psi_k(:,1)=phi;
%end

for k=1:K
    temp_fenzi=0;
    for n=1:NumdS
        temp_fenzi=temp_fenzi+(Psi_k(:,k))'*G_k(:,:,k,n)*theta_k(:,k,n)*dS; 
    end   
    
    temp_fenzi=(abs(temp_fenzi))^2;
    
    temp_fenmu=0;
    for j=1:K
        temp0=zeros(3,1);
        for n=1:NumdS
            temp0=temp0+G_k(:,:,k,n)*theta_k(:,j,n);
        end
        temp0=abs((Psi_k(:,k))'*temp0*dS)^2;
        temp_fenmu=temp_fenmu+temp0;
    end
    temp_fenmu=temp_fenmu-temp_fenzi+sigma_2*(norm(Psi_k(:,k)))^2;
    
    SINR_k(k)=temp_fenzi/temp_fenmu;
    sum_rate=sum_rate+log2(1+SINR_k(k));
end


end

