function G_k = Clark_G_k_generate(lambda,user_position,Vs,K,NumdS,delta_x,delta_y,U_corr)
G_k=zeros(3,3,K,NumdS);

AA=1/sqrt(2)*(randn(NumdS,1)+1j*randn(NumdS,1));
AA=U_corr'*AA;

for k=1:K
    for a=1:delta_x
        for b=1:delta_y                 
            G_k(:,:,k,a+delta_x*(b-1))=AA(a+delta_x*(b-1))*Green(user_position(:,k),Vs(:,a+delta_x*(b-1)),lambda);
        end
    end
end
end

