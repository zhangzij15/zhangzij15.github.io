function w_k_uv = theta_k_2_w_k(K,NumdS,NumF,dS,theta_k,f_base)

w_k_uv=zeros(3,K,NumF);
%theta_k=zeros(3,K,NumdS);                   %�������������ܶ� K���û�
for n=1:NumdS
for k=1:K
    for m=1:NumF             
            w_k_uv(:,k,m)=w_k_uv(:,k,m)+1/sqrt(Ls_x*Ls_y)*theta_k(:,k,n)*(f_base(m,n))'*dS;        
 %           theta_k(:,k,n)=theta_k(:,k,n)+w_k_uv(:,k,m)*f_base(m,n);         
    end   
end
end



end

