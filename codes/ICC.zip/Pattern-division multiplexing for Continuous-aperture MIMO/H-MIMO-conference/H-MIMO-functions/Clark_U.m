function U_corr = Clark_U(lambda,Vs,NumdS)

R_corr=zeros(NumdS,NumdS);
for m=1:NumdS
    for n=1:NumdS
        if m==n
            R_corr(m,n)=1;
        else
            R_corr(m,n)=sin(2*pi/lambda*norm(Vs(:,m)-Vs(:,n)))/(2*pi/lambda*norm(Vs(:,m)-Vs(:,n)));
        end        
    end
end
[~,S,V] = svd(R_corr);
U_corr=(abs(S)).^(1/2)*V;

end

