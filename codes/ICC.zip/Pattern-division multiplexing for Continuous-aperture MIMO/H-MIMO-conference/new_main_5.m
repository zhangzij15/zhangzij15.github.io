clear all; close all; clc;

load('Best3_new_main_4');

delta=33;

Surface_1=zeros(delta,delta);
Surface_2=zeros(delta,delta);

for a=1:delta
   for b=1:delta     
       Surface_1(a,b)=theta_k_1(1,1,a+(b-1)*delta);
   end
end

Surface_1_abs=Surface_1/max(max(abs(Surface_1)));

Surface_1_ang=angle(Surface_1);

Surface_1_ang=2*pi*angle(Surface_1)/max(max(abs(angle(Surface_1))))-pi;

figure;
surf([1:delta],[1:delta],abs(Surface_1_abs));
shading interp;
xlim([1,delta]);
ylim([1,delta]);
axis off;
axis equal;
colorbar;
% colorbar('Ticks', [0.6 0.7 0.8 0.9 1], 'FontSize', 15, 'TickLabelInterpreter', 'latex');


figure;
surf([1:delta],[1:delta],abs(Surface_1_ang));
shading interp;
xlim([1,delta]);
ylim([1,delta]);
axis off;
axis equal;
colorbar;
% colorbar('Ticks', [1.2 1.6 2 2.4 2.6], 'FontSize', 15, 'TickLabelInterpreter', 'latex');


for a=1:delta
   for b=1:delta     
       Surface_1(a,b)=theta_k_1(1,2,a+(b-1)*delta);
   end
end

Surface_1_abs=Surface_1/max(max(abs(Surface_1)));
Surface_1_ang=angle(Surface_1);

figure;
surf([1:delta],[1:delta],abs(Surface_1_abs));
shading interp;
xlim([1,delta]);
ylim([1,delta]);
;
axis off;
axis equal;
colorbar;
% colorbar('Ticks', [0.6 0.7 0.8 0.9 1], 'FontSize', 15, 'TickLabelInterpreter', 'latex');


figure;
surf([1:delta],[1:delta],abs(Surface_1_ang));
shading interp;
xlim([1,delta]);
ylim([1,delta]);
axis off;
axis equal;
colorbar;
% colorbar('Ticks', [1.2 1.6 2 2.4 2.6], 'FontSize', 15, 'TickLabelInterpreter', 'latex');


for a=1:delta
   for b=1:delta     
       Surface_1(a,b)=theta_k_1(1,3,a+(b-1)*delta);
   end
end

Surface_1_abs=Surface_1/max(max(abs(Surface_1)));
Surface_1_ang=angle(Surface_1);

figure;
surf([1:delta],[1:delta],abs(Surface_1_abs));
shading interp;
xlim([1,delta]);
ylim([1,delta]);
axis off;
axis equal;
colorbar;
% colorbar('Ticks', [0.6 0.7 0.8 0.9 1], 'FontSize', 15, 'TickLabelInterpreter', 'latex');


figure;
surf([1:delta],[1:delta],abs(Surface_1_ang));
shading interp;
xlim([1,delta]);
ylim([1,delta]);
axis off;
axis equal;
colorbar;
% colorbar('Ticks', [1.2 1.6 2 2.4 2.6], 'FontSize', 15, 'TickLabelInterpreter', 'latex');


for a=1:delta
   for b=1:delta     
       Surface_1(a,b)=theta_k_1(1,4,a+(b-1)*delta);
   end
end

Surface_1_abs=Surface_1/max(max(abs(Surface_1)));
Surface_1_ang=angle(Surface_1);

figure;
surf([1:delta],[1:delta],abs(Surface_1_abs));
shading interp;
xlim([1,delta]);
ylim([1,delta]);

axis off;
axis equal;
colorbar;
% colorbar('Ticks', [0.6 0.7 0.8 0.9 1], 'FontSize', 15, 'TickLabelInterpreter', 'latex');


figure;
surf([1:delta],[1:delta],abs(Surface_1_ang));
shading interp;
xlim([1,delta]);
ylim([1,delta]);
axis off;
axis equal;
colorbar;
% colorbar('Ticks', [1.2 1.6 2 2.4 2.6], 'FontSize', 15, 'TickLabelInterpreter', 'latex');

