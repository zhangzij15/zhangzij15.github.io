function w_k =  Upper_w_k_update(K,NumF,rho_k,zeta,alpha_k)

w_k=zeros(3*NumF,K);

%temp = alpha_k(:,k)*(alpha_k(:,k))' + zeta*eye(3*NumF);

for k=1:K
    w_k(:,k)=sqrt(1+rho_k(k))*pinv(alpha_k(:,k)*(alpha_k(:,k))' + zeta*eye(3*NumF))*alpha_k(:,k);
end

end

