
This simulation code package is mainly used to reproduce the results of the following paper [1]:

[1] K. Liu, Z. Zhang, and L. Dai, ��User-side RIS: Realizing large-scale array at user side,�� IEEE Global Communications Conference (GLOBECOM), 2021.

Please also refer to the full journal version of this paper [2] for more details:

[2] K. Liu, Z. Zhang, L. Dai, and L. Hanzo, ��Compact user-specific reconfigurable intelligent surfaces for uplink transmission,�� IEEE Trans. Commun., vol. 70, no. 1, pp. 680-692, Jan. 2022.

*********************************************************************************************************************************
If you use this simulation code package in any way, please cite the original paper [1] above. 
 
The author in charge of this simulation code package is: Kunzan Liu (email: lkz18@mails.tsinghua.edu.cn).

Reference: We highly respect reproducible research, so we try to provide the simulation codes for our published papers (more information can be found at: 
http://oa.ee.tsinghua.edu.cn/dailinglong/publications/publications.html). 

Please note that the MATLAB R2019b is used for this simulation code package, and there may be some incompatibility problems among different MATLAB versions. 

Copyright reserved by the Broadband Communications and Signal Processing Laboratory (led by Dr. Linglong Dai), Beijing National Research Center for Information Science and Technology (BNRist), Department of Electronic Engineering, Tsinghua University, Beijing 100084, China. 

*********************************************************************************************************************************
Abstract of the paper: 

Massive multiple-input multiple-output (MIMO) with a large-scale antenna array at the base station (BS) side is one of the most essential techniques for 5G wireless communications. However, due to the forbidden hardware cost and mismatched size, it is physically limited to deploy massive MIMO at the user side. To break this limitation, inspired by the promising technique called reconfigurable intelligent surface (RIS), we firstly propose the concept of user-side RIS (US-RIS) which is a cost- and energy-efficient realization for large-scale array at the user side. Different from the existing RISs that work as base-station-side RISs (BSS-RISs), US-RIS is the first usage of RIS at the user side. Then, we propose a novel architecture of user with the aid of US-RIS with a multi-layer structure for compact implementation. Based on the proposed multi-layer USRIS, we formulate the signal-to-noise ratio (SNR) maximization problem in the US-RIS-aided communications. To tackle the challenge of solving this non-convex problem, we propose a multilayer precoding design that can obtain the optimal parameters at transceivers and US-RIS by iterative optimization. Finally, simulation results are shown to verify the practicability and superiorities of the proposed multi-layer US-RIS as a realization of the large-scale array at the user side.
*********************************************************************************************************************************
How to use this simulation code package?

All figures can be derived by running the corresponding m file.

The simulation results in Fig. 5 & 6 can be directly obtained by running Transmission.m.

It costs very short time to process, and the figures would quickly pop out.
*********************************************************************************************************************************
Enjoy the reproducible research!