function SNR = Scene1(g, f, Sigma, Pmax)
[v, ~] = eigs(g'*f*f'*g, 1);
a = f'*g*v;
w = a/norm(a);
[v, ~] = eigs(g'*diag(f*w)*diag(f*w)'*g, 1);
b = v'*g'*diag(f*w);
theta = exp(1j*angle(b'));
SNR = abs(v'*g'*diag(theta)*f*w)^2/norm(v)^2/Sigma*Pmax;
end