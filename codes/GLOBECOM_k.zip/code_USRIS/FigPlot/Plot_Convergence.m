function Plot_Convergence(UC_SNR, Ref_SNR, Tran_SNR)
rpt = length(UC_SNR);
UC_SNR = 10*log10(UC_SNR);
Ref_SNR = 10*log10(Ref_SNR);
Tran_SNR = 10*log10(Tran_SNR);
figure;
hold on;
plot(0:rpt-1, UC_SNR, 'LineWidth', 2, 'Marker', 'o', 'MarkerSize', 9);
plot(0:rpt-1, Ref_SNR, 'LineWidth', 2, 'Marker', 'x', 'MarkerSize', 9);
plot(0:rpt-1, Tran_SNR, 'LineWidth', 2, 'Marker', '^', 'MarkerSize', 9);
box on;
grid on;
xlim([0 rpt-1]);
xlabel('Iterations', 'FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
ylabel('SNR (dB)', 'FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
legend('Multi-layer UC-RIS', 'Single-layer CC-RIS', ...
    'Single-layer UC-RIS', 'FontSize', 15, 'Location', 'SouthEast', ...
    'Fontname', 'Times');
set(gcf, 'Position', [554,110,560,420]);
end

