%% Specify the model.
% RX(tau)=P*exp(-alpha*|tau|);
% SX(f) = 2P*alpha/(alpha^2+(2pi*f)^2);
% SN(f) = n0/2

P_arr = [1, 2, 4];

L = length(P_arr);
T_arr = 0.01:0.01:2;
N_T_arr = length(T_arr);
I_T = zeros(L, N_T_arr);
I_sh = zeros(L, N_T_arr);

for iter = 1:L
    P = P_arr(iter);
    n0 = 1;
    alpha = 1;
    N_lambdas = 500;
    C_sh = calc_shannon_capacity(P, alpha, n0);
    I_sh(iter, :) = C_sh * T_arr;
    
    
    for idx = 1:N_T_arr
        T = T_arr(idx);
        I_T(iter, idx) = calc_finite_time_capacity(P, alpha, n0, T, N_lambdas);
    end
end


disp('Calc complete.');

%% Plot the curves.
set(0,'DefaultLineMarkerSize',4);
set(0,'DefaultTextFontSize',14);

set(0,'DefaultAxesFontSize',12);
set(0,'DefaultLineLineWidth',1.4);

set(0,'defaultfigurecolor','w');

figure('color',[1 1 1]); hold on;
plot(T_arr, I_sh(3,:), 'r-.');
plot(T_arr, I_T(3,:), 'b-');

plot(T_arr, I_sh(2,:), 'r-.');
plot(T_arr, I_T(2,:), 'b-');

plot(T_arr, I_sh(1,:), 'r-.'); 
plot(T_arr, I_T(1,:), 'b-');

legend('Shannon', 'I(T)');
grid on; xlabel('Sample time T(s)'); ylabel('Mutual information within [0,T] (nat)');
set(gca,'FontName','Times New Roman'); box on;

text(0,1,'$P=1$','Interpreter','latex','FontSize',14)
text(0,2,'$P=2$','Interpreter','latex','FontSize',14)
text(0,3,'$P=4$','Interpreter','latex','FontSize',14)

C_T = zeros(size(I_T));
C_sh = zeros(size(I_sh));

for idx = 1:L
   C_T(idx, :) = I_T(idx, :) ./ T_arr;
   C_sh(idx, :) = I_sh(idx, :) ./ T_arr;
end
figure('color',[1 1 1]); hold on;
plot(T_arr, C_sh(3,:), 'r-.');
plot(T_arr, C_T(3,:), 'b-');

plot(T_arr, C_sh(2,:), 'r-.');
plot(T_arr, C_T(2,:), 'b-');

plot(T_arr, C_sh(1,:), 'r-.'); 
plot(T_arr, C_T(1,:), 'b-');

legend('Shannon P=4', 'C(T) P=4','Shannon P=2', 'C(T) P=2','Shannon P=1', 'C(T) P=1');
grid on; xlabel('Sample time T(s)'); ylabel('Average rate within [0,T] (nat/s)');
set(gca,'FontName','Times New Roman'); box on;
text(0,1,'$P=1$','Interpreter','latex','FontSize',14)
text(0,2,'$P=2$','Interpreter','latex','FontSize',14)
text(0,3,'$P=4$','Interpreter','latex','FontSize',14)

%% Plot the 2arctan curves.
alpha = 1;
w_arr = (0:0.1:8);   
n_arr = [1, 2, 3, 4];                   % Draw 4 curves.

T = 2;

figure('color', [1,1,1]);
lhs = atan(w_arr/alpha);
rhs = zeros(length(n_arr), length(w_arr));
for idx = 1:length(n_arr)
    rhs(idx, :) = n_arr(idx)*pi - w_arr*T;
end

plot(w_arr, lhs, 'color', 'r'); hold on;
% for idx = 1:length(n_arr)
%     plot(w_arr, rhs(idx, :));
% end
plot(w_arr, rhs(1,:), 'color', [1, 0.6, 0]);
plot(w_arr, rhs(2,:), 'color', 'm');
plot(w_arr, rhs(3,:), 'color', 'b');
plot(w_arr, rhs(4,:), 'color', [0, 0.7, 0]);

xlabel('\omega');
ylabel('Function value y_1, y_2');

set(gca, 'xlim', [w_arr(1), w_arr(end)]);
set(gca, 'ylim', [0, 1.2*pi]);
set(gca,'FontName','Times New Roman');
grid on; axis on; box on;
legend('2arctan(\omega)', '\pi-2\omegaT', '2\pi-2\omegaT', '3\pi-2\omegaT', '4\pi-2\omegaT');

%% Utils.
function C = calc_shannon_capacity(P, alpha, n0)
    C = 0.5*(sqrt(alpha^2+(4*P*alpha/n0))-alpha);
end

function I = calc_finite_time_capacity(P, alpha, n0, T, N_lambdas)
    % Solve the equation for w: 2arctan(w/alpha) = n*pi -w*T.
    lambdas = zeros(1, N_lambdas);
    for n = 1:N_lambdas
        g = @(w)(2*atan(w/alpha) + w*T-n*pi);
        w = fzero(g, 0);
        lambdas(n) = 2*P*alpha/(alpha^2+w^2);
    end
    I = 0.5*sum(log(1+(lambdas)/(n0/2)));
end