%% Setup process correlation functions.
Rx = @(t1,t2)(sinc(10*(t1-t2)));    % Bandlimited.
Rn = @(t1,t2)(exp(-abs(t1-t2)));    % Not Bandlimited.

set(0,'DefaultLineMarkerSize',4);
set(0,'DefaultTextFontSize',14);

set(0,'DefaultAxesFontSize',12);
set(0,'DefaultLineLineWidth',1.4);

set(0,'defaultfigurecolor','w');


%% Plot the increasing curves w.r.t. number of samples n.
n_arr = 1:250;
T_arr = [1, 2, 4, 8];

C_arr = zeros(length(T_arr), length(n_arr));
for idx_n = 1:length(n_arr)
    for idx_t = 1:length(T_arr)
        n = n_arr(idx_n);
        T = T_arr(idx_t);
        sample_instants = ((1:n)-1)/n*T;
        
        K_X = zeros(n,n);
        K_N = zeros(n,n);
        
        for idx1 = 1:n
            for idx2 = 1:n
                K_X(idx1, idx2) = Rx(sample_instants(idx1), sample_instants(idx2));
                K_N(idx1, idx2) = Rn(sample_instants(idx1), sample_instants(idx2));
            end
        end
        
        C_arr(idx_t, idx_n) = 0.5*log(det(eye(n) + K_N \ K_X));
    end
end
fprintf('Complete!\n');

%% Plot.
figure('color',[1 1 1]); hold on;
% for idx_t = 1:length(T_arr)
%     plot(n_arr, C_arr(idx_t, :)/T_arr(idx_t));
% end
plot(n_arr, C_arr(1,:)/T_arr(1), 'b-.', 'LineWidth', 1.5);
plot(n_arr, C_arr(2,:)/T_arr(2), 'c-.', 'LineWidth', 1.5);
plot(n_arr, C_arr(3,:)/T_arr(3), 'g--', 'LineWidth', 1.5);
plot(n_arr, C_arr(4,:)/T_arr(4), 'm--', 'LineWidth', 1.5);

xlabel('Number of samples n within [0,T]');
ylabel('Transmission Rate (nat/s)');

% Calculate the Shannon limit.
g = @(f)(log(1+(0.1)./(2./(1+(2*pi*f).^2))));
C_sh = 0.5*integral(g, -5, 5);
line([n_arr(1), n_arr(end)], [C_sh, C_sh], 'linestyle', '-', 'color', 'r');
grid on;
box on;
legend('T=1', 'T=2', 'T=4', 'T=8', 'Average');
set(gca,'FontName','Times New Roman');
