clear all; clc;

sigma2_dB_list = [-20:2.5:20];% -5~10

for kk = 1:length(sigma2_dB_list)
    sigma2_dB = sigma2_dB_list(kk);
    Kernal_CDL_learning;
end