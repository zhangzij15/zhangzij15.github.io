function h = SV_channel(x,Lambda,L)

N = length(x);

h = zeros(N,1);
% for l = 1: L
%     theta_n = 2*pi/Lambda*(x(2)-x(1))*(2*rand()-1);
%     % theta_n = pi*(2*floor(N*rand())-N+1)/N;
%     h = h + 1/sqrt(2)*(randn()+1j*randn())*exp(1j*theta_n*[0:1:N-1]');
% end
% h = h + exp(1j*2*pi*rand())* exp(1j*theta_n*[0:1:N-1]');

% h = h/sqrt(L);

Angle_spr = 5/180*pi;
R = 100;      % Number of rays
B = zeros(N,R);

for l = 1: L
    theta_n = 2*pi*rand();
    for r = 1:R
        theta_n_r = theta_n + (rand()-0.5)*Angle_spr;
        theta_n_r = 2*pi/Lambda*(x(2)-x(1))*cos(theta_n_r);
        B(:,r) = exp(1j*theta_n_r*[0:1:N-1]');
    end
    gain_l = 1/sqrt(2)*(randn(R,1)+1j*randn(R,1));
    h = h + B*gain_l;
end
h = h/sqrt(L*R);

% h = zeros(N,1);
% h(randperm(N,L)) = 1/sqrt(2)*(randn(L,1)+1j*randn(L,1));
% h = dftmtx(N)'*h/sqrt(N);
% h = h/sqrt(L);

end

