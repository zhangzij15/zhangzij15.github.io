sigma2_dB_all = (-30:5:10);

% for a = 1:length(sigma2_dB_all)
%     sigma2_dB = sigma2_dB_all(a);
%     Kernal_CDL_learning;
%     fprintf("SNR %d complete.\n", a);
% end

for a = 1:length(sigma2_dB_all)
    sigma2_dB = sigma2_dB_all(a);
    Kernal_SV_learning;
    fprintf("SNR %d complete.\n", a);
end