This simulation code package is mainly used to reproduce the results of the following paper [1]:

[1] Z. Zhang, J. Zhu, L. Dai, and R. W. Heath, "Successive Bayesian reconstructor for channel estimation in fluid antenna systems," IEEE Transactions on Wireless Communications, vol. 24, no. 3, pp. 1992-2006, Mar. 2025.

The conference version of this journal paper is:

[2] Z. Zhang, J. Zhu, L. Dai, and R. Heath, "Successive Bayesian reconstructor for FAS channel estimation," in Proc. 2024 IEEE Wireless Communications and Networking Conference (IEEE WCNC’24), Dubai, United Arab Emirates, Apr. 2024.
*********************************************************************************************************************************
If you use this simulation code package in any way, please cite the original paper [1] above. 

The author in charge of this simulation code pacakge is: Zijian Zhang (email: zhangzj20@mails.tsinghua.edu.cn).

Reference: We highly respect reproducible research, so we try to provide the simulation codes for our published papers (more information can be found at: 
http://oa.ee.tsinghua.edu.cn/dailinglong/publications/publications.html). 

Please note that the MATLAB R2023b and CVX are used for this simulation code package,  and there may be some imcompatibility problems among different software versions. 

Copyright reserved by the Broadband Communications and Signal Processing Laboratory (led by Dr. Linglong Dai), Tsinghua National Laboratory
for Information Science and Technology (TNList), Department of Electronic Engineering, Tsinghua University, Beijing 100084, China. 

*********************************************************************************************************************************
Abstract of the paper: 

Fluid antenna systems (FASs) can reconfigure their antenna locations freely within a spatially continuous space. To keep favorable antenna positions, the channel state information (CSI) acquisition for FASs is essential. While some techniques have been proposed, most existing FAS channel estimators require several channel assumptions, such as slow variation and angular-domain sparsity. When these assumptions are not reasonable, the model mismatch may lead to unpredictable performance losses. In this paper, we propose the successive Bayesian reconstructor (S-BAR) as a general solution to estimate FAS channels. Unlike model-based estimators, the proposed S-BAR is prior-aided, which builds the experiential kernel for CSI acquisition. Inspired by Bayesian regression, the key idea of S-BAR is to model the FAS channels as a stochastic process, whose uncertainty can be successively eliminated by kernel-based sampling and regression. In this way, the predictive mean of the regressed stochastic process can be viewed as a Bayesian channel estimator. Simulation results verify that, in both model mismatched and model-matched cases, the proposed S-BAR can achieve higher estimation accuracy than the existing schemes.

*********************************************************************************************************************************
How to use this simulation code package?

1. Run "main.m" and adjust parameters to obtain the results in Fig. 3.

2. Run "NMSE_vs_SNR.m" and "NMSE_vs_SNR_SV.m" to obtain the results in Fig. 4 and Fig. 5.

3. Run "NMSE_vs_P.m" and "NMSE_vs_P_SV.m" to obtain the results in Fig. 6 and Fig. 7.

4. Run "NMSE_vs_W.m" to obtain the results in Fig. 8.

*********************************************************************************************************************************
Enjoy the reproducible research!






