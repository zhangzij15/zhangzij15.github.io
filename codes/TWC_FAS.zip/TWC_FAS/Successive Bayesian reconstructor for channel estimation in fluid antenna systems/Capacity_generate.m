clear all; clc;

% rng(10);

f_c = 3.5e9;        % Frequency

sigma2_dB = (-10:2.5:10);
sigma2 = 10.^(sigma2_dB/10);   % Noise power

beta = 3;

P = 10;
N_ports = 4;

load('Kernal.mat');

Rep = 512;

Length = length(sigma2_dB);

NMSE_GPR = zeros(Length,Rep);
NMSE_GPR_exp = zeros(Length,Rep);
NMSE_GPR_J0 = zeros(Length,Rep);
NMSE_OMP = zeros(Length,Rep);
NMSE_ML = zeros(Length,Rep);
NMSE_LMMSE = zeros(Length,Rep);

N = length(x);

h_list = zeros(N,Length,Rep);
h_hat_GPR_list = zeros(N,Length,Rep);
h_hat_exp_list = zeros(N,Length,Rep);
h_hat_LMMSE_list = zeros(N,Length,Rep);
h_hat_OMP_list = zeros(N,Length,Rep);
h_hat_ML_list = zeros(N,Length,Rep);

for rp = 1:Rep
    h = CDL_channel(x, f_c);
    h = h/sqrt(mean(diag(Kernal_CDL_mean)));

    for qq = 1:Length

        load(['Kernal_CDL_learning/Kernal_' num2str(sigma2_dB(qq)) '.mat']);

        % load('Kernal_exp/Kernal_exp_-10.mat');

        [h_hat_GPR,~,~,~] = GPR_multi(x,h,Kernal_CDL_mean, sigma2(qq), P*N_ports, 1);
        [h_hat_exp,~,~,~] = GPR_multi(x,h,Kernal_exp, sigma2(qq), P*N_ports, 1);
        % [h_hat_J0,~,~,~] = GPR_multi(x,h,Kernal_J0, sigma2(qq), P, N_ports);

        [h_hat_ML, h_hat_OMP] = ML_OMP_estimator(h, P, N_ports, 2*L, sigma2(qq), 10);

        [h_hat_LMMSE] = SeLMMSE(x,h,sigma2(qq),P*N_ports);

        NMSE_GPR(qq,rp) = mag2db(norm(h_hat_GPR - h)/norm(h));
        NMSE_GPR_exp(qq,rp) = mag2db(norm(h_hat_exp - h)/norm(h));
        NMSE_LMMSE(qq,rp) = mag2db(norm(h_hat_LMMSE - h)/norm(h));
        % NMSE_GPR_J0(qq,rp) = mag2db(norm(h_hat_J0 - h)/norm(h));
        NMSE_OMP(qq,rp) = mag2db(norm(h_hat_OMP - h)/norm(h));
        NMSE_ML(qq,rp) = mag2db(norm(h_hat_ML - h)/norm(h));

        h_list(:,qq,rp) = h;
        h_hat_GPR_list(:,qq,rp) = h_hat_GPR;
        h_hat_exp_list(:,qq,rp) = h_hat_exp;
        h_hat_LMMSE_list(:,qq,rp) = h_hat_LMMSE;
        h_hat_OMP_list(:,qq,rp) = h_hat_OMP;
        h_hat_ML_list(:,qq,rp) = h_hat_ML;

    end
    fprintf("Rep %d complete.\n", rp);
end

NMSE_GPR = mean(NMSE_GPR,2);
NMSE_GPR_exp = mean(NMSE_GPR_exp,2);
NMSE_GPR_J0 = mean(NMSE_GPR_J0,2);
NMSE_OMP = mean(NMSE_OMP,2);
NMSE_ML = mean(NMSE_ML,2);
NMSE_LMMSE = mean(NMSE_LMMSE,2);

SNR = - sigma2_dB;

save('h_list.mat','SNR','h_list','h_hat_GPR_list','h_hat_exp_list','h_hat_LMMSE_list','h_hat_OMP_list','h_hat_ML_list');



