clear all; clc;

%% 节点坐标初始化
N_a=10; %有源节点数量

P=zeros(2,N_a);
P_k=zeros(2,1);

%有源节点坐标
%X_a=30*[1.7 4.51 6.8 8.2 3.4 7.7 8.9 2.5 6.71 5.4]-10;
%Y_a=30*[5.2 4.5 6.65 2.6 7.7 4.3 6.5 3.1 9.2 3.5]-10;

X_a = 300*rand(1,N_a);
Y_a = 300*rand(1,N_a);

P(1,:)=X_a;
P(2,:)=Y_a;

P_hat=P+randn(2,N_a);    %待估计初值

%Target坐标
X_k=160;
Y_k=170;
P_k(1)=X_k;
P_k(2)=Y_k;

P_k_hat=P_k+randn(2,1);    %待估计初值

%% 节点测距信息初始化
ppm = 100;                      %钟偏范围
light_speed = 299792458;              %光速
Delay = 0.001*light_speed;            %节点发送间隔
noise_power = 1*10^(-9)*light_speed;  %测量噪声

e=ppm*(2*rand(N_a,1)-1)*0.000001; %各节点钟偏情况

[Distance,Summation] = distance_generate(N_a,X_a,Y_a,X_k,Y_k);
[Distance_hat,Summation_hat]=Proposed_algorithm(N_a,e,Delay,noise_power,Distance,Summation,ppm);

Loss_0 = Loss_Func(N_a,P_hat,P_k_hat,Distance_hat,Summation_hat);
[P_hat,P_k_hat] = Localization(N_a,P_hat,P_k_hat,Distance_hat,Summation_hat);
Loss_end = Loss_Func(N_a,P_hat,P_k_hat,Distance_hat,Summation_hat);

[P_hat(1,:),P_hat(2,:),P_k_hat(1),P_k_hat(2)] = relative_localization(N_a,1,P(1,:),P(2,:),P_k(1),P_k(2),P_hat(1,:),P_hat(2,:),P_k_hat(1),P_k_hat(2));

%% 画图
figure;
box on;
hold on;
grid on;
axis square;
scatter(P(1,1:N_a),P(2,1:N_a),60,'ro','filled');
scatter(P_k(1),P_k(2),60,'kd','filled');
scatter(P_hat(1,1:N_a),P_hat(2,1:N_a),120,'b+','LineWidth',1);
scatter(P_k_hat(1),P_k_hat(2),120,[1 0.5 0],'x','LineWidth',1);

set(gca,'XTick',[-30:30:300]);%设置要显示坐标刻度
set(gca,'YTick',[-30:30:300]);%设置要显示坐标刻度
xlim([-30 300]);
ylim([-30 300]);
legend('Real positions of active nodes','Real position of target', ...
    'Estimated positions of active nodes','Estimated position of target','location','southwest');
set(gca,'FontName','Times','FontSize',12);
set(legend,'FontName','Times','FontSize',12);
%set (gca,'position',[0.1,0.1,0.9,0.9] );
xlabel('X axis (m)','Interpreter','latex');
ylabel('Y axis (m)','Interpreter','latex');
