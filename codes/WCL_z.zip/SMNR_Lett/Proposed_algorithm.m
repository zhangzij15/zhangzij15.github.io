function [Distance_hat,Summation_hat]=Proposed_algorithm(N_a,e,Delay,noise_power,Distance,Summation,ppm)

e=zeros(N_a,1);
for i=1:N_a
    e(i)=ppm*(2*rand()-1)*0.000001; %各节点钟偏情况
end

t1=zeros(N_a,N_a+1);       %节点理想时间戳 LoS
t2=zeros(N_a,N_a+1);       %节点理想时间戳 NLoS

t1_hat=zeros(N_a,N_a+1);   %节点实际时间戳 LoS
t2_hat=zeros(N_a,N_a+1);   %节点实际时间戳 NLoS

t1(1,1)=0;
t2(1,1)=0;
for i=2:N_a
	t1(i,1)=t1(1,1)+Distance(1,i);
    t2(i,1)=t2(1,1)+Summation(1,i);
end

for j=2:N_a
    t1(j,j)=t1(j,j-1)+Delay;
    t2(j,j)=t1(j,j);
    for i=1:N_a
        if i~=j
            t1(i,j)=t1(j,j)+Distance(i,j);
            t2(i,j)=t2(j,j)+Summation(i,j);
        end
    end
end

t1(1,N_a+1)=t1(1,N_a)+Delay;
t2(1,N_a+1)=t1(1,N_a+1);
for i=2:N_a
    t1(i,N_a+1)=t1(1,N_a+1)+Distance(1,i);    %最后一条消息
    t2(i,N_a+1)=t2(1,N_a+1)+Summation(1,i);
end

for i=1:N_a
    for j=1:N_a+1
        t1_hat(i,j)=(1+e(i))*t1(i,j)+noise_power^2*randn();
        t2_hat(i,j)=(1+e(i))*t2(i,j)+noise_power^2*randn();
    end
end

T1_hat=zeros(N_a,1);                     %LoS同步时间
T2_hat=zeros(N_a,1);                     %NLoS同步时间
for i=1:N_a
    T1_hat(i)=t1_hat(i,N_a+1)-t1_hat(i,1);
    T2_hat(i)=t2_hat(i,N_a+1)-t2_hat(i,1);
end
T_mean=max(max(T1_hat),max(T2_hat))/(1+ppm*0.000001);

Distance_hat=zeros(N_a,N_a);
Summation_hat=zeros(N_a,N_a);

for i=1:N_a
    for j=i+1:N_a
        D_ab_a=t1_hat(i,j)-t1_hat(i,i);
        D_ab_b=t1_hat(j,j)-t1_hat(j,i);    
        Distance_hat(i,j)=T_mean*D_ab_a/T1_hat(i)-T_mean*D_ab_b/T1_hat(j);
        Distance_hat(i,j)=Distance_hat(i,j)*0.5;
        Distance_hat(j,i)=Distance_hat(i,j);

        D_ab_a=t2_hat(i,j)-t2_hat(i,i);
        D_ab_b=t2_hat(j,j)-t2_hat(j,i); 
        Summation_hat(i,j)=T_mean*D_ab_a/T2_hat(i)-T_mean*D_ab_b/T2_hat(j);
        Summation_hat(i,j)=Summation_hat(i,j)*0.5;
        Summation_hat(j,i)=Summation_hat(i,j);
    end
end

end



