function Deriva_Pi = Loss_Deriva_Pi(i,N_a,P_hat,P_k_hat,Distance_hat,Summation_hat)

Deriva_Pi=0;
eta_a=1;
eta_k=sqrt(2/N_a/(N_a+1));

for j=1:N_a
    if j~=i
        Deriva_Pi=Deriva_Pi+2*eta_a*(norm(P_hat(:,i)-P_hat(:,j))-Distance_hat(i,j))*(P_hat(:,i)-P_hat(:,j))/norm(P_hat(:,i)-P_hat(:,j)) ...
            + 2*eta_k*(norm(P_hat(:,i)-P_k_hat)+norm(P_hat(:,j)-P_k_hat)-Summation_hat(i,j))*((P_hat(:,i)-P_k_hat)/norm(P_hat(:,i)-P_k_hat)+(P_hat(:,j)-P_k_hat)/norm(P_hat(:,j)-P_k_hat));
    end
end

end

