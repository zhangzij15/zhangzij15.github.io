function [Distance_hat]=AltTWR(N_a,Delay,noise_power,Distance,ppm)

e=zeros(N_a,1);
for i=1:N_a
    e(i)=ppm*(2*rand()-1)*0.000001;
end

Distance_hat=zeros(N_a,N_a);

k=1+e;
for i=1:N_a
    for j=i+1:1:N_a
       t=zeros(9,1);
       t(1)=0;
       t(4)=t(1)+Distance(i,j);
       t(7)=t(1)+Distance(i,end);
       t(5)=t(4)+Delay;
       t(2)= t(5)+Distance(i,j);      
       t(3)=t(2)+Delay;
       t(6)=t(3)+Distance(i,j);
       t(9)=t(3)+Distance(i,end);
       t_hat=zeros(9,1);
       t_hat(1)=k(i)*t(1)+noise_power^2*randn();
       t_hat(2)=k(i)*t(2)+noise_power^2*randn();
       t_hat(3)=k(i)*t(3)+noise_power^2*randn();
       t_hat(4)=k(j)*t(4)+noise_power^2*randn();
       t_hat(5)=k(j)*t(5)+noise_power^2*randn();
       t_hat(6)=k(j)*t(6)+noise_power^2*randn();
       
       Distance_hat(i,j)=(t_hat(2)-t_hat(1))*(t_hat(6)-t_hat(5))-(t_hat(3)-t_hat(2))*(t_hat(5)-t_hat(4));
       Distance_hat(i,j)=Distance_hat(i,j)/(t_hat(3)-t_hat(1)+t_hat(6)-t_hat(4));
       Distance_hat(j,i)=Distance_hat(i,j);
       
    end
end



end



