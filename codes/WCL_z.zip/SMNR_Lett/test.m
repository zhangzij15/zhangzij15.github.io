close all; clear all; clc;

main
new_main_2