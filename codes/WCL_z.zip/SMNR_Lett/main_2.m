clear all; clc;

N_a=50;     

Lx = 300;     Ly = 300;               %仿真场景长宽

light_speed = 299792458;              %光速
ppm = 100;                            %钟偏范围

Delay = 0.001*light_speed;            %节点发送间隔

noise=[0:0.025:1];
noise_power = noise*10^(-9)*light_speed;  %测量噪声

iteration = 10000000;                       %重复10次



R_tof = zeros(length(noise),iteration);           %节点间ToF测距误差
R_tof_Alt = zeros(length(noise),iteration);       %AltTWR节点间ToF测距误差
R_tof_SMNR = zeros(length(noise),iteration);      %SM-NR节点间ToF测距误差

R_tsof = zeros(length(noise),iteration);    %TSoF误差


ppmlength = length(noise);

parfor p = 1:iteration
    for q = 1:ppmlength
    
    X_a = Lx*rand(N_a,1);    %节点X坐标
    Y_a = Ly*rand(N_a,1);    %节点Y坐标
    
    X_k = Lx*rand();    %Target X坐标
    Y_k = Ly*rand();    %Target Y坐标
    
    e=ppm*(2*rand(N_a,1)-1)*0.000001; %各节点钟偏情况

    [Distance,Summation] = distance_generate(N_a,X_a,Y_a,X_k,Y_k);  %实际距离及距离和生成
    
    [Distance_hat,Summation_hat]=Proposed_algorithm(N_a,e,Delay,noise_power(q),Distance,Summation,ppm);
    [R_tof(q,p),R_tsof(q,p)] = ToF_TSoF_error(Distance_hat,Summation_hat,Distance,Summation);

    [Distance_hat]=AltTWR(N_a,Delay,noise_power(q),Distance,ppm);
    [R_tof_Alt(q,p)] = ToF_error(Distance_hat,Distance);

    [Distance_hat]=SM_NR(N_a,e,Delay,noise_power(q),Distance,ppm);
    [R_tof_SMNR(q,p)] = ToF_error(Distance_hat,Distance);

    end
end

R_tof=1000*sqrt(mean(R_tof,2));
R_tof_Alt=1000*sqrt(mean(R_tof_Alt,2));
R_tof_SMNR=1000*sqrt(mean(R_tof_SMNR,2));

R_tsof=1000*sqrt(mean(R_tsof,2));

steplength=4;
figure;
box on;
semilogy(noise,R_tof,'-r',noise,R_tsof,'-b',noise,R_tof_Alt,'-m',noise,R_tof_SMNR,'--k','LineWidth',1.5,'MarkerSize',6);
hold on;
semilogy(noise(1:steplength:end),R_tof(1:steplength:end),'hr',noise(1:steplength:end),R_tsof(1:steplength:end),'ob',noise(1:steplength:end),R_tof_Alt(1:steplength:end),'^m',noise(1:steplength:end),R_tof_SMNR(1:steplength:end),'sk','LineWidth',1.5,'MarkerSize',6);
h1=semilogy(noise(end),R_tof(end),'-hr',noise(end),R_tsof(end),'-ob',noise(end),R_tof_Alt(end),'-^m',noise(end),R_tof_SMNR(end),'--sk','LineWidth',1.5,'MarkerSize',6);
legend(h1,'Proposed method (ToF)','Proposed method (TSoF)','AltDS-TWR (ToF)','SM-NR (ToF)','FontSize',14,'Interpreter','latex','Location','SouthEast');
xlabel('Standard deviation of timestamp measurement error $\sigma_{w}$ (ns)','Interpreter','latex');
ylabel('RMSE of ranges (mm)','Interpreter','latex');
set(gca,'FontName','Times','FontSize',12);
grid on;
ylim([10^(0) 10^(2)])

% steplength=8;
% figure;
% box on;
% semilogy([0 ppm],[10^(-10);R_tsof],'-b','LineWidth',1.5,'MarkerSize',6);
% hold on;
% semilogy(ppm(1:steplength:end),R_tsof(1:steplength:end),'ob','LineWidth',1.5,'MarkerSize',6);
% [h1]=semilogy(ppm(end),R_tsof(end),'-ob','LineWidth',1.5,'MarkerSize',6);
% legend(h1,'Proposed method','FontSize',14,'Interpreter','latex','Location','SouthEast');
% xlabel('Maximal clock frequency deviation $e_{\max}$ (ppm)','Interpreter','latex');
% ylabel('RMSE of sum ranges $E_{\rm TSoF}$ (mm)','Interpreter','latex');
% set(gca,'FontName','Times','FontSize',12);
% grid on;
% ylim([10^(-3) 10^(1)])
