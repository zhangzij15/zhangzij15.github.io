function [R_tof] = ToF_error(Distance_hat,Distance)

N_a=size(Distance_hat,1);

R_tof=0;
for i=1:N_a
    for j=i+1:N_a
        R_tof=R_tof+(Distance_hat(i,j)-Distance(i,j))^2;
    end
end
R_tof=(R_tof/(N_a*(N_a-1)/2));

end

