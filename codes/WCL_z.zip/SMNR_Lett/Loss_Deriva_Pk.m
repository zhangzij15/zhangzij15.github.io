function Deriva_Pk = Loss_Deriva_Pk(N_a,P_hat,P_k_hat,Summation_hat)

Deriva_Pk=0;

eta_k=sqrt(2/N_a/(N_a+1));

for i=1:N_a
    for j=1:N_a
        if j~=i
            Deriva_Pk=Deriva_Pk+2*eta_k*(norm(P_hat(:,i)-P_k_hat)+ norm(P_hat(:,j)-P_k_hat)-Summation_hat(i,j))*((P_k_hat-P_hat(:,i))/norm(P_hat(:,i)-P_k_hat)+(P_k_hat-P_hat(:,j))/norm(P_hat(:,j)-P_k_hat));
        end
    end
end

end

