function [X_hat_corrected,Y_hat_corrected,X_p_hat_corrected,Y_p_hat_corrected] = relative_localization(N_a,N_p,X,Y,X_p,Y_p,X_hat,Y_hat,X_p_hat,Y_p_hat)
P=zeros(2*N_a+2*N_p,1);
P_hat=zeros(2*N_a+2*N_p,1);

X_hat_corrected=X;
Y_hat_corrected=Y;
X_p_hat_corrected=X_p;
Y_p_hat_corrected=Y_p;

for i=1:N_a
    P(2*i-1)=X(i);
    P(2*i)=Y(i);
    P_hat(2*i-1)=X_hat(i);
    P_hat(2*i)=Y_hat(i);    
end
for i=N_a+1:N_a+N_p
    P(2*i-1)=X_p(i-N_a);
    P(2*i)=Y_p(i-N_a);
    P_hat(2*i-1)=X_p_hat(i-N_a);
    P_hat(2*i)=Y_p_hat(i-N_a);    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M=zeros(N_a+N_p,2);
M_hat=zeros(N_a+N_p,2);
for i=1:N_a
    M(i,1)=X(i);
    M(i,2)=Y(i);
    M_hat(i,1)=X_hat(i);
    M_hat(i,2)=Y_hat(i);
end
for i=N_a+1:N_a+N_p
    M(i,1)=X_p(i-N_a);
    M(i,2)=Y_p(i-N_a);
    M_hat(i,1)=X_p_hat(i-N_a);
    M_hat(i,2)=Y_p_hat(i-N_a);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Q=eye(N_a+N_p)-1/(N_a+N_p)*ones(N_a+N_p,N_a+N_p);

[U,S,V]=svd(M_hat'*Q*M);

Gamma=V*U';
PP=(M'-Gamma*M_hat')*ones(N_a+N_p,1)/(N_a+N_p);
x=PP(1);
y=PP(2);

R=zeros(2*(N_a+N_p),2*(N_a+N_p));
for i=1:N_a+N_p
    R((i-1)*2+1:1:(i-1)*2+2,(i-1)*2+1:1:(i-1)*2+2)=Gamma;
end

v_x=zeros(2*(N_a+N_p),1);
v_y=zeros(2*(N_a+N_p),1);
for i=1:2*N_a+2*N_p
    if mod(i,2)==1
        v_x(i)=1;
    else
        v_y(i)=1;
    end
end

PP=R*P_hat+x*v_x+y*v_y;

for i=1:N_a
    X_hat_corrected(i)=PP(2*i-1);
    Y_hat_corrected(i)=PP(2*i); 
end
for i=N_a+1:N_a+N_p
    X_p_hat_corrected(i-N_a)=PP(2*i-1);
    Y_p_hat_corrected(i-N_a)=PP(2*i);
end

end

