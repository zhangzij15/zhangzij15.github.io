clear all; clc;

N_a=50;     

Lx = 300;     Ly = 300;               %仿真场景长宽

light_speed = 299792458;              %光速
ppm = [0:2.5:100];                      %钟偏范围

ppm(1) = 1;                           %对数坐标没法表示0所以最小为1ppm
Delay = 0.001*light_speed;            %节点发送间隔
noise_power = 0*10^(-9)*light_speed;  %测量噪声

iteration = 100000;                       %重复10次

repeat_num=floor(3*N_a*(N_a-1)/2/(N_a+1));

R_tof = zeros(length(ppm),iteration);           %节点间ToF测距误差
R_tof_rep = zeros(length(ppm),iteration);           %节点间ToF测距误差

R_tof_Alt = zeros(length(ppm),iteration);       %AltTWR节点间ToF测距误差
R_tof_SMNR = zeros(length(ppm),iteration);      %SM-NR节点间ToF测距误差
R_tof_SMNR_rep = zeros(length(ppm),iteration);      %SM-NR节点间ToF测距误差

R_tsof = zeros(length(ppm),iteration);    %TSoF误差
R_tsof_rep = zeros(length(ppm),iteration);    %TSoF误差


ppmlength = length(ppm);

parfor p = 1:iteration
    for q = 1:ppmlength
    
    X_a = Lx*rand(N_a,1);    %节点X坐标
    Y_a = Ly*rand(N_a,1);    %节点Y坐标
    
    X_k = Lx*rand();    %Target X坐标
    Y_k = Ly*rand();    %Target Y坐标

    e=ppm(q)*(2*rand(N_a,1)-1)*0.000001; %各节点钟偏情况

    [Distance,Summation] = distance_generate(N_a,X_a,Y_a,X_k,Y_k);  %实际距离及距离和生成
    
    [Distance_hat,Summation_hat]=Proposed_algorithm(N_a,e,Delay,noise_power,Distance,Summation,ppm(q));
    [R_tof(q,p),R_tsof(q,p)] = ToF_TSoF_error(Distance_hat,Summation_hat,Distance,Summation);

    Distance_hat=0*Distance_hat;
    Summation_hat=0*Summation_hat;
    for pp = 1:repeat_num
        e=ppm(q)*(2*rand(N_a,1)-1)*0.000001; %各节点钟偏情况
        [Distance_hat_temp,Summation_hat_temp]=Proposed_algorithm(N_a,e,Delay,noise_power,Distance,Summation,ppm(q));
        Distance_hat = Distance_hat + Distance_hat_temp;
        Summation_hat = Summation_hat + Summation_hat_temp;
    end
    Distance_hat = Distance_hat/repeat_num;
    Summation_hat = Summation_hat/repeat_num;

    [R_tof_rep(q,p),R_tsof_rep(q,p)] = ToF_TSoF_error(Distance_hat,Summation_hat,Distance,Summation);

    [Distance_hat]=AltTWR(N_a,Delay,noise_power,Distance,ppm(q));
    [R_tof_Alt(q,p)] = ToF_error(Distance_hat,Distance);

    [Distance_hat]=SM_NR(N_a,e,Delay,noise_power,Distance,ppm(q));
    [R_tof_SMNR(q,p)] = ToF_error(Distance_hat,Distance);

    Distance_hat=0*Distance_hat;
    for pp = 1:repeat_num
        e=ppm(q)*(2*rand(N_a,1)-1)*0.000001; %各节点钟偏情况
        [Distance_hat_temp]=SM_NR(N_a,e,Delay,noise_power,Distance,ppm(q));
        Distance_hat = Distance_hat + Distance_hat_temp;
    end
    Distance_hat = Distance_hat/repeat_num;  
    [R_tof_SMNR_rep(q,p)] = ToF_error(Distance_hat,Distance);

    end
end

R_tof=1000*sqrt(mean(R_tof,2));
R_tof_Alt=1000*sqrt(mean(R_tof_Alt,2));
R_tof_SMNR=1000*sqrt(mean(R_tof_SMNR,2));
R_tsof=1000*sqrt(mean(R_tsof,2));

R_tof_rep=1000*sqrt(mean(R_tof_rep,2));
R_tof_SMNR_rep=1000*sqrt(mean(R_tof_SMNR_rep,2));
R_tsof_rep=1000*sqrt(mean(R_tsof_rep,2));

steplength=4;
figure;
box on;
semilogy([0 ppm],[10^(-10);R_tof],'-r',[0 ppm],[10^(-10);R_tsof],'-b',...
    [0 ppm],[10^(-10);R_tof_Alt],'-m',[0 ppm],[10^(-10);R_tof_SMNR],'-k',...
    [0 ppm],[10^(-10);R_tof_rep],'--r',[0 ppm],[10^(-10);R_tsof_rep],'--b',...
    [0 ppm],[10^(-10);R_tof_SMNR_rep],'--k','LineWidth',1.5,'MarkerSize',6);
hold on;
semilogy(ppm(1:steplength:end),R_tof(1:steplength:end),'hr',...
    ppm(1:steplength:end),R_tsof(1:steplength:end),'ob',...
    ppm(1:steplength:end),R_tof_Alt(1:steplength:end),'^m',...
    ppm(1:steplength:end),R_tof_SMNR(1:steplength:end),'sk',...
    ppm(1:steplength:end),R_tof_rep(1:steplength:end),'pr',...
    ppm(1:steplength:end),R_tof_SMNR_rep(1:steplength:end),'sk', ...
    ppm(1:steplength:end),R_tsof_rep(1:steplength:end),'>b',...
    'LineWidth',1.5,'MarkerSize',6);
h1=semilogy(ppm(end),R_tof_Alt(end),'-^m',ppm(end),R_tof(end),'-hr',...
    ppm(end),R_tsof(end),'-ob',ppm(end),R_tof_SMNR(end),'-sk',...
    ppm(end),R_tof_rep(end),'--pr',ppm(end),R_tsof_rep(end),'-->b',...
    ppm(end),R_tof_SMNR_rep(end),'--sk','LineWidth',1.5,'MarkerSize',6);

legend(h1,'AltDS-TWR \,[7] (ToF, 3675 signals)','SM-TR~~~~~~~~\,(ToF, 51 signals)','SM-TR~~~~~~~~\,(TSoF, 51 signals)',...
    'SM-NR [9]~~~~~~~~\,(ToF, 51 signals)','SM-TR~~~~~~~~\,(ToF, 3672 signals)','SM-TR~~~~~~~~\,(TSoF, 3672 signals)','SM-NR [9]~~~~~~~~\,(ToF, 3672 signals)',...
    'FontSize',10,'Interpreter','latex','Location','SouthEast');
xlabel('Maximal clock frequency deviation $e_{\max}$ (ppm)','Interpreter','latex');
ylabel('RMSE of ranges (mm)','Interpreter','latex');
set(gca,'FontName','Times','FontSize',12);
grid on;
ylim([5*10^(-3) 10^(1)])

% steplength=8;
% figure;
% box on;
% semilogy([0 ppm],[10^(-10);R_tsof],'-b','LineWidth',1.5,'MarkerSize',6);
% hold on;
% semilogy(ppm(1:steplength:end),R_tsof(1:steplength:end),'ob','LineWidth',1.5,'MarkerSize',6);
% [h1]=semilogy(ppm(end),R_tsof(end),'-ob','LineWidth',1.5,'MarkerSize',6);
% legend(h1,'Proposed method','FontSize',14,'Interpreter','latex','Location','SouthEast');
% xlabel('Maximal clock frequency deviation $e_{\max}$ (ppm)','Interpreter','latex');
% ylabel('RMSE of sum ranges $E_{\rm TSoF}$ (mm)','Interpreter','latex');
% set(gca,'FontName','Times','FontSize',12);
% grid on;
% ylim([10^(-3) 10^(1)])
