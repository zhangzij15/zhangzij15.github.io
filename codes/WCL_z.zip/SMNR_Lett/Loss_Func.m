function Loss = Loss_Func(N_a,P_hat,P_k_hat,Distance_hat,Summation_hat)

Loss=0;
eta_a=1;
eta_k=sqrt(2/N_a/(N_a+1));

for i=1:N_a
    for j=1:N_a
        if i~=j
            Loss=Loss+eta_a*(norm(P_hat(:,i)-P_hat(:,j))-Distance_hat(i,j))^2 ...
                +eta_k*(norm(P_hat(:,i)-P_k_hat)+norm(P_hat(:,j)-P_k_hat)-Summation_hat(i,j))^2;   
        end
    end
end

end

