function [Distance_hat]=SM_NR(N_a,e,Delay,noise_power,Distance,ppm)


t1=zeros(N_a,N_a+1);       %节点理想时间戳 LoS

t1_hat=zeros(N_a,N_a+1);   %节点实际时间戳 LoS

t1(1,1)=0;

for i=2:N_a
	t1(i,1)=t1(1,1)+Distance(1,i);
end

for j=2:N_a
    t1(j,j)=t1(j,j-1)+Delay;
    for i=1:N_a
        if i~=j
            t1(i,j)=t1(j,j)+Distance(i,j);
        end
    end
end

t1(1,N_a+1)=t1(1,N_a)+Delay;
for i=2:N_a
    t1(i,N_a+1)=t1(1,N_a+1)+Distance(1,i);    %最后一条消息
end

for i=1:N_a
    for j=1:N_a+1
        t1_hat(i,j)=(1+e(i))*t1(i,j)+noise_power^2*randn();
    end
end

T1_hat=zeros(N_a,1);                     %LoS同步时间
for i=1:N_a
    T1_hat(i)=t1_hat(i,N_a+1)-t1_hat(i,1);
end
T_mean=max(max(T1_hat))/(1+ppm*0.000001);

Distance_hat=zeros(N_a,N_a);

for i=1:N_a
    for j=i+1:N_a
        D_ab_a=t1_hat(i,j)-t1_hat(i,i);
        D_ab_b=t1_hat(j,j)-t1_hat(j,i);    
        Distance_hat(i,j)=T_mean*D_ab_a/T1_hat(i)-T_mean*D_ab_b/T1_hat(j);
        Distance_hat(i,j)=Distance_hat(i,j)*0.5;
        Distance_hat(j,i)=Distance_hat(i,j);
    end
end

end



