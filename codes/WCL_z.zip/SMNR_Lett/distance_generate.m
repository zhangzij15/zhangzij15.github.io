function [Distance,Summation] = distance_generate(N_a,X_a,Y_a,X_k,Y_k)
Distance = zeros(N_a,N_a);
Summation = zeros(N_a,N_a);

for i=1:1:N_a
    for j=i+1:1:N_a
        Distance(i,j) = distance(X_a(i),Y_a(i),X_a(j),Y_a(j));
        Distance(j,i) = Distance(i,j);
        
        Summation(i,j) = distance(X_a(i),Y_a(i),X_k,Y_k)+distance(X_k,Y_k,X_a(j),Y_a(j));
        Summation(j,i) = Summation(i,j);
    end
end


end

