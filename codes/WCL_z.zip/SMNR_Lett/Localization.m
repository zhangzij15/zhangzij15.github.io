function [P_hat,P_k_hat] = Localization(N_a,P_hat,P_k_hat,Distance_hat,Summation_hat)

lambda=0.001;   %迭代步长

Iteration = 1000;

for pp=1:Iteration
    for i=1:N_a   
        Deriva_Pi = Loss_Deriva_Pi(i,N_a,P_hat,P_k_hat,Distance_hat,Summation_hat);
        P_hat(:,i) = P_hat(:,i) - lambda*Deriva_Pi;
    end

    Deriva_Pk = Loss_Deriva_Pk(N_a,P_hat,P_k_hat,Summation_hat);
    P_k_hat = P_k_hat - lambda*Deriva_Pk;

end

end

