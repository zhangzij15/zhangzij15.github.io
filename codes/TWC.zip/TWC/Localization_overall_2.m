function [X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = Localization_overall(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance_hat,Difference_hat)
% X_a_hat=10*rand(N_a,1);
% Y_a_hat=10*rand(N_a,1);
% X_p_hat=10*rand(N_p,1);
% Y_p_hat=10*rand(N_p,1);
X_a_hat=X_a;
Y_a_hat=Y_a;
X_p_hat=X_p;
Y_p_hat=Y_p;

for k=3:N_a    
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat]=location_apssive(k,1,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat,Distance_hat,Difference_hat);
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = relative_localization(k,1,X_a,Y_a,X_p,Y_p,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat);
end

for k=2:N_p    
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat]=location_apssive(N_a,k,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat,Distance_hat,Difference_hat);
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = relative_localization(N_a,k,X_a,Y_a,X_p,Y_p,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat);
end

end

