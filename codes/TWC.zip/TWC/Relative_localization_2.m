function [X_hat_corrected,Y_hat_corrected,Z_hat_corrected] = Relative_localization_2(N_a,X,Y,Z,X_hat,Y_hat,Z_hat)
P=zeros(3*N_a,1);
P_hat=zeros(3*N_a,1);

% X_hat_corrected=X;
% Y_hat_corrected=Y;
% Z_hat_corrected=Z;

for i=1:N_a
    P(3*i-2)=X(i);
    P(3*i-1)=Y(i);
    P(3*i)=Z(i);
    P_hat(3*i-2)=X_hat(i);
    P_hat(3*i-1)=Y_hat(i);    
    P_hat(3*i)  =Z_hat(i);    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M=zeros(N_a,3);
M_hat=zeros(N_a,3);
for i=1:N_a
    M(i,1)=X(i);
    M(i,2)=Y(i);
    M(i,3)=Z(i);
    M_hat(i,1)=X_hat(i);
    M_hat(i,2)=Y_hat(i);
    M_hat(i,3)=Z_hat(i);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Q=eye(N_a)-1/N_a*ones(N_a,N_a);

[U,S,V]=svd(M_hat.'*Q*M);

Gamma=V*U.';
PP=(M.'-Gamma*M_hat.')*ones(N_a,1)/N_a;
x=PP(1);
y=PP(2);
z=PP(3);

R=zeros(3*N_a,3*N_a);
for i=1:N_a
    R((i-1)*3+1:1:(i-1)*3+3,(i-1)*3+1:1:(i-1)*3+3)=Gamma;
end

v_x=zeros(3*N_a,1);
v_y=zeros(3*N_a,1);
v_z=zeros(3*N_a,1);
for i=1:3*N_a
    if mod(i,3)==1
        v_x(i)=1;
    elseif mod(i,3)==2
        v_y(i)=1;
    else
        v_z(i)=1;  
    end
end

PP=R*P_hat+x*v_x+y*v_y+z*v_z;

for i=1:N_a
    X_hat_corrected(i)=PP(3*i-2);
    Y_hat_corrected(i)=PP(3*i-1); 
    Z_hat_corrected(i)=PP(3*i); 
end

end

