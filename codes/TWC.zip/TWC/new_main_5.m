clear all; clc;

load('Location_3.mat');

light_speed=299792458;
ppm=10;
Delay=0.001*light_speed;

noise=[0:0.025:2];
noise_power=noise*10^(-9)*light_speed;

[Distance,Difference] = distance_generate(N,N_a,N_p,X_a,Y_a,X_p,Y_p);

iteration=1;

repeat_num=floor(3*N_a*(N_a-1)/2/(N_a+1));
% repeat_num=1;
%%

R_Alt=zeros(length(ppm),iteration,length(noise));
R_EDT=zeros(length(ppm),iteration,length(noise));
R_EDT_limit=zeros(length(ppm),iteration,length(noise));
R_ours=zeros(length(ppm),iteration,length(noise));
R_ours_limit=zeros(length(ppm),iteration,length(noise));


for p=1:length(ppm)
for m=1:length(noise)  
for q=1:iteration

[Distance_hat,Difference_hat]=AltTWR(N_a,N_p,Delay,noise_power(m),Distance,Difference,ppm(p));
Distance_hat_Alt=Distance_hat;
Difference_hat_Alt=Difference_hat;
% [X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = Localization_overall(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance_hat,Difference_hat);
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = Localization_overall(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance,Difference,Distance_hat,Difference_hat);
R_Alt(p,q,m)= Relative_error(N_a,N_p,X_a,Y_a,X_p,Y_p,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat);
%%
Distance_hat=0; Difference_hat=0;
for kk=1:repeat_num
[Distance_hat_temp,Difference_hat_temp]=EDTWR(N_a,N_p,Delay,noise_power(m),Distance,Difference,ppm(p));
Distance_hat=Distance_hat+Distance_hat_temp;
Difference_hat=Difference_hat+Difference_hat_temp;
end
Distance_hat=Distance_hat/repeat_num;
Difference_hat=Difference_hat/repeat_num;
Distance_hat_EDT=Distance_hat;
Difference_hat_EDT=Difference_hat;
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = Localization_overall(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance,Difference,Distance_hat_temp,Difference_hat_temp);
R_EDT_limit(p,q,m)= Relative_error(N_a,N_p,X_a,Y_a,X_p,Y_p,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat);
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = Localization_overall(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance,Difference,Distance_hat,Difference_hat);
R_EDT(p,q,m)= Relative_error(N_a,N_p,X_a,Y_a,X_p,Y_p,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat);
%%
Distance_hat=0; Difference_hat=0;
for kk=1:repeat_num
[Distance_hat_temp,Difference_hat_temp]=Proposed_algorithm_2(N_a,N_p,Delay,noise_power(m),Distance,Difference,ppm(p));
Distance_hat=Distance_hat+Distance_hat_temp;
Difference_hat=Difference_hat+Difference_hat_temp;
end
Distance_hat=Distance_hat/repeat_num;
Difference_hat=Difference_hat/repeat_num;
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = Localization_overall(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance,Difference,Distance_hat_temp,Difference_hat_temp);
R_ours_limit(p,q,m)= Relative_error(N_a,N_p,X_a,Y_a,X_p,Y_p,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat);
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = Localization_overall(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance,Difference,Distance_hat,Difference_hat);
R_ours(p,q,m)= Relative_error(N_a,N_p,X_a,Y_a,X_p,Y_p,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat);

end
end

% for ppp=1:length(ppm)
% R_Alt_mean(ppp,m)=mean(R_Alt(ppp,:,m));
% R_EDT_mean(ppp,m)=mean(R_EDT(ppp,:,m));
% R_ours_mean(ppp,m)=mean(R_ours(ppp,:,m));
% end

end

R_Alt_mean=mean(R_Alt,2);
R_EDT_mean=mean(R_EDT,2);
R_ours_mean=mean(R_ours,2);
R_EDT_limit_mean=mean(R_EDT_limit,2);
R_ours_limit_mean=mean(R_ours_limit,2);

R_Alt_mean=reshape(R_Alt_mean(1,1,:),length(noise),1);
R_EDT_mean=reshape(R_EDT_mean(1,1,:),length(noise),1);
R_ours_mean=reshape(R_ours_mean(1,1,:),length(noise),1);
R_EDT_limit_mean=reshape(R_EDT_limit_mean(1,1,:),length(noise),1);
R_ours_limit_mean=reshape(R_ours_limit_mean(1,1,:),length(noise),1);

steplength=8;
figure;
box on;
semilogy(noise,R_Alt_mean,'-k',noise,R_EDT_limit_mean,'--b',noise,R_EDT_mean,'-b',noise,R_ours_limit_mean,'--r',noise,R_ours_mean,'-r','LineWidth',1.5,'MarkerSize',6);
hold on;
semilogy(noise(1:steplength:end),R_Alt_mean(1:steplength:end),'^k',noise(1:steplength:end),R_EDT_limit_mean(1:steplength:end),'>b',noise(1:steplength:end),R_EDT_mean(1:steplength:end),'pb',noise(1:steplength:end),R_ours_limit_mean(1:steplength:end),'or',noise(1:steplength:end),R_ours_mean(1:steplength:end),'hr','LineWidth',1.5,'MarkerSize',6);
h1=semilogy(noise(end),R_Alt_mean(end),'-^k',noise(end),R_EDT_limit_mean(end),'-->b',noise(end),R_EDT_mean(end),'-pb',noise(end),R_ours_limit_mean(end),'--or',noise(end),R_ours_mean(end),'-hr','LineWidth',1.5,'MarkerSize',6);
grid on;
ylabel('Error of relative position estimations $\varepsilon$ (m)','Interpreter','latex');
legend(h1,'AltDS-TWR [17] + PER [28] (2340 signals)','NB-TWR + NB-PR [24]~~~~~~~\,(41 signals)','NB-TWR + NB-PR [24]~~~~~~~\,(2337 signals)','Proposed SM-NR method~~~~~~(41 signals)','Proposed SM-NR method~~~~~~(2337 signals)','FontSize',12,'Interpreter','latex');
xlabel('Standard deviation of timestamp measurement error $\sigma_{w}$ (ns)','Interpreter','latex');
set(gca,'FontName','Times','FontSize',12);

