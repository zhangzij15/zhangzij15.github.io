function Distance = distance(X1,Y1,X2,Y2)

Distance=sqrt((X1-X2)^2+(Y1-Y2)^2);
end

