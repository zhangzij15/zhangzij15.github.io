clear all; clc;

load('test.mat');

clear Difference X_p Y_p N_p N

B=zeros(N_a,N_a);
temp=0;
for i=1:N_a
    for j=1:N_a
        temp=temp+Distance_hat(i,j)^2;
    end
end
temp=temp/N_a^2;

for i=1:N_a
    for j=1:N_a
        temp1=0; temp2=0;
        for k=1:N_a
            temp1=temp1+Distance_hat(k,j)^2;
            temp2=temp2+Distance_hat(i,k)^2;
        end
        temp1=temp1/N_a; temp2=temp2/N_a;
        B(i,j)=-0.5*(Distance_hat(i,j)^2-temp1-temp2+temp);        
    end
end
[U,V]=eig(B);
V=sqrtm(V);
X=U*V;
X=[X(:,1),X(:,2)];

[X(:,1),X(:,2),~] = Relative_localization_2(N_a,X_a,Y_a,zeros(N_a,1),X(:,1),X(:,2),zeros(N_a,1));


figure;
box on;
hold on;
grid on;
% axis square;
scatter(X_a,Y_a,60,'ro','filled');

xlabel('X axis (m)','Interpreter','latex');
ylabel('Y axis (m)','Interpreter','latex');

figure;
box on;
hold on;
grid on;
% axis square;
scatter(X(:,1),X(:,2),60,'ko','filled');

xlabel('X axis (m)','Interpreter','latex');
ylabel('Y axis (m)','Interpreter','latex');
