clear all; close all; clc;

N_a=10;

X=10*rand(N_a,1);
Y=10*rand(N_a,1);

%scatter(X,Y);
Distance=zeros(N_a,N_a);
Distance_hat=zeros(N_a,N_a);
for i=1:1:N_a
    for j=i+1:1:N_a
        Distance(i,j)=distance(X(i),Y(i),X(j),Y(j));
        Distance_hat(i,j)=Distance(i,j)+2*rand();
    end
end

for k=1:1:N_a   
mse = MSE(N_a,X,Y,Distance_hat)    
G_x=0;
G_y=0;
for i=2:1:N_a
    G_x=G_x+2*(distance(X(1),Y(1),X(i),Y(i))-Distance_hat(1,i))*(X(1)-X(i))/distance(X(1),Y(1),X(i),Y(i));
    G_y=G_y+2*(distance(X(1),Y(1),X(i),Y(i))-Distance_hat(1,i))*(Y(1)-Y(i))/distance(X(1),Y(1),X(i),Y(i));
end
f1i=zeros(N_a,1);
f1i_X1=zeros(N_a,1);
f1i_Y1=zeros(N_a,1);
for i=2:1:N_a
    f1i(i)=distance(X(1),Y(1),X(i),Y(i))-Distance_hat(1,i);
    f1i_X1(i)=(X(1)-X(i))/distance(X(1),Y(1),X(i),Y(i));
    f1i_Y1(i)=(Y(1)-Y(i))/distance(X(1),Y(1),X(i),Y(i));
end
L_zi=0;
L_mu=0;
for i=2:1:N_a
    L_zi=L_zi+f1i(i)*(G_x*f1i_X1(i)+G_y*f1i_Y1(i));
    L_mu=L_mu+(G_x*f1i_X1(i)+G_y*f1i_Y1(i))^2;
end
L=L_zi/L_mu;

X(1)=X(1)-L*G_x;
Y(1)=Y(1)-L*G_y;

temp_X=X(1);
temp_Y=Y(1);

for i=1:N_a-1
    X(i)=X(i+1);
    Y(i)=Y(i+1); 
end
X(N_a)=temp_X;
Y(N_a)=temp_Y;

temp=zeros(1,N_a);
for i=1:N_a
    temp(i)=Distance_hat(1,i);
end
for i=1:1:N_a-1
    for j=i+1:1:N_a-1
        Distance_hat(i,j)=Distance_hat(i+1,j+1);
    end
end
for i=1:N_a-1
    Distance_hat(i,N_a)=temp(i+1);
end
end












