function [Distance_hat,Difference_hat]=EDTWR(N_a,N_p,Delay,noise_power,Distance,Difference,ppm)

e=zeros(N_a+N_p,1);
for i=1:N_a+N_p
    e(i)=ppm*(2*rand()-1)*0.000001;
end

t=zeros(N_a+N_p,N_a+1);
t_hat=zeros(N_a+N_p,N_a+1);

t(1,1)=0;
for i=2:N_a+N_p
    t(i,1)=t(1,1)+Distance(1,i);
end

t(1,2)=t(1,1)+0.005*299792458;
for i=2:N_a+N_p
    t(i,2)=t(1,2)+Distance(1,i);
end

for j=2:N_a
    t(j,j+1)=t(j,j)+Delay;
    for i=1:N_a+N_p
        if i~=j
            t(i,j+1)=t(j,j+1)+Distance(i,j);
        end
    end
end

for i=1:N_a+N_p
    for j=1:N_a+1
        t_hat(i,j)=(1+e(i))*t(i,j)+noise_power^2*randn();
    end
end

T_hat=zeros(N_a+N_p,1);
for i=1:N_a+N_p
    T_hat(i)=t_hat(i,2)-t_hat(i,1);
end

Distance_hat=zeros(N_a,N_a);
Difference_hat=zeros(N_a,N_a,N_p);

for i=2:N_a
	D_ab_a=t_hat(1,i+1)-t_hat(1,2);
	D_ab_b=t_hat(i,i+1)-t_hat(i,2);    
    
    ToF_1=0.5*(D_ab_a-D_ab_b/T_hat(i)*T_hat(1));
    ToF_2=0.5*(D_ab_a/T_hat(1)*T_hat(i)-D_ab_b);
    Distance_hat(1,i)=2/(1/ToF_1+1/ToF_2);
    Distance_hat(i,1)=Distance_hat(1,i);
    
    for k=1:N_p
        D_ab_x=t_hat(N_a+k,i+1)-t_hat(N_a+k,2);
        DoF_1=D_ab_x/T_hat(N_a+k)*T_hat(1)-0.5*D_ab_b/T_hat(i)*T_hat(1)-0.5*D_ab_a;
        DoF_2=D_ab_x/T_hat(N_a+k)*T_hat(i)-0.5*D_ab_b-0.5*D_ab_a/T_hat(1)*T_hat(i);
        DoF_3=D_ab_x-0.5*D_ab_b/T_hat(i)*T_hat(N_a+k)-0.5*D_ab_a/T_hat(1)*T_hat(N_a+k);
    
        Difference_hat(1,i,k)=-3/(1/DoF_1+1/DoF_2+1/DoF_3);
        Difference_hat(i,1,k)=-Difference_hat(1,i,k);
    end
end

for i=2:N_a
    for j=i+1:N_a
        D_A_alpha_beta=t_hat(j,i+1)-t_hat(j,2);
        D_A_alpha_alpha=t_hat(i,i+1)-t_hat(i,2);
        D_A_alpha_A=t_hat(1,i+1)-t_hat(1,2);
        D_A_beta_beta=t_hat(j,j+1)-t_hat(j,2);
        D_A_beta_A=t_hat(1,j+1)-t_hat(1,2);
        
        D_alpha_beta_beta=t_hat(j,j+1)-t_hat(j,i+1);
        
        ToF=D_A_alpha_beta/T_hat(j) - 0.5*D_A_alpha_alpha/T_hat(i) - 0.5*D_A_beta_beta/T_hat(j) - 0.5*D_A_alpha_A/T_hat(1) + 0.5*D_A_beta_A/T_hat(1);
                      
        ToF_1=ToF*T_hat(1);
        ToF_2=ToF*T_hat(i);
        ToF_3=ToF*T_hat(j);
        Distance_hat(i,j)=3/(1/ToF_1+1/ToF_2+1/ToF_3);
        Distance_hat(j,i)=Distance_hat(i,j);  
        
        for k=1:N_p
            D_alpha_beta_chi=t_hat(N_a+k,j+1)-t_hat(N_a+k,i+1);
            DoF=D_alpha_beta_beta/T_hat(j)-D_alpha_beta_chi/T_hat(N_a+k)+ToF;
            DoF_1=DoF*T_hat(1);
            DoF_2=DoF*T_hat(i);
            DoF_3=DoF*T_hat(j);
            DoF_4=DoF*T_hat(N_a+k);
      
            Difference_hat(i,j,k)=4/(1/DoF_1+1/DoF_2+1/DoF_3+1/DoF_4);
            Difference_hat(j,i,k)=-Difference_hat(i,j,k);    
        end
        
    end
end


end



