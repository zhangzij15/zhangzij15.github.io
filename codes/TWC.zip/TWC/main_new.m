clear all; close all; clc;

load('Location.mat');

Ireation=10;

X_hat_ours=zeros(N_a,Ireation);
Y_hat_ours=zeros(N_a,Ireation);
X_p_hat_ours=zeros(1,Ireation);
Y_p_hat_ours=zeros(1,Ireation);
RMSE_ours=zeros(1,Ireation);

X_hat_Alt=zeros(N_a,Ireation);
Y_hat_Alt=zeros(N_a,Ireation);
X_p_hat_Alt=zeros(1,Ireation);
Y_p_hat_Alt=zeros(1,Ireation);
RMSE_Alt=zeros(1,Ireation);

light_speed=299792458;
ppm=20;
Delay=0.001*light_speed;
noise_power=10*10^(-9)*light_speed;

for qqq=1:Ireation

e=zeros(N_a+1,1);
for i=1:N_a+1
    e(i)=ppm*(2*rand()-1)*0.000001;
end
Distance=zeros(N_a+1,N_a+1);
Difference=zeros(N_a,N_a);
for i=1:1:N_a
    for j=i+1:1:N_a
        Distance(i,j)=distance(X(i),Y(i),X(j),Y(j));
        Difference(i,j)=distance(X(i),Y(i),X_p,Y_p)-distance(X(j),Y(j),X_p,Y_p);
    end
end
for j=1:N_a
    Distance(N_a+1,j)=distance(X_p,Y_p,X(j),Y(j));
end
Distance=Distance+Distance';
Difference=Difference-Difference';

X_intilaize=10*rand(N_a,1);
Y_intilaize=10*rand(N_a,1);
X_p_intilaize=10*rand();
Y_p_intilaize=10*rand();

% X_intilaize=X;
% Y_intilaize=Y;
% X_p_intilaize=X_p;
% Y_p_intilaize=Y_p;

[Distance_hat,Difference_hat]=Proposed_algorithm(N_a,e,Delay,noise_power,Distance,Difference);
[X_hat_ours(:,qqq),Y_hat_ours(:,qqq),X_p_hat_ours(1,qqq),Y_p_hat_ours(1,qqq)]=location_apssive(N_a,X_intilaize,Y_intilaize,X_p_intilaize,Y_p_intilaize,Distance_hat,Difference_hat);
%[X_hat_ours(:,qqq),Y_hat_ours(:,qqq),X_p_hat_ours(1,qqq),Y_p_hat_ours(1,qqq)] = relative_localization(N_a,X,Y,X_p,Y_p,X_hat_ours(:,qqq),Y_hat_ours(:,qqq),X_p_hat_ours(1,qqq),Y_p_hat_ours(1,qqq));

% [Distance_hat,Difference_hat]=AltTWR(N_a,e,Delay,noise_power,Distance,Difference);
% [X_hat_Alt(:,qqq),Y_hat_Alt(:,qqq),X_p_hat_Alt(1,qqq),Y_p_hat_Alt(1,qqq)]=location_apssive(N_a,X_intilaize,Y_intilaize,X_p_intilaize,Y_p_intilaize,Distance_hat,Difference_hat);

RMSE_ours(qqq)=(X_hat_ours(:,qqq)-X)'*(X_hat_ours(:,qqq)-X)+(Y_hat_ours(:,qqq)-Y)'*(Y_hat_ours(:,qqq)-Y);
RMSE_ours(qqq)=RMSE_ours(qqq)+(X_p_hat_ours(1,qqq)-X_p)^2+(Y_p_hat_ours(1,qqq)-Y_p)^2;
RMSE_ours(qqq)=sqrt(RMSE_ours(qqq));

RMSE_Alt(qqq)=(X_hat_Alt(:,qqq)-X)'*(X_hat_Alt(:,qqq)-X)+(Y_hat_Alt(:,qqq)-Y)'*(Y_hat_Alt(:,qqq)-Y);
RMSE_Alt(qqq)=RMSE_Alt(qqq)+(X_p_hat_Alt(1,qqq)-X_p)^2+(Y_p_hat_Alt(1,qqq)-Y_p)^2;
RMSE_Alt(qqq)=sqrt(RMSE_Alt(qqq));
end

RMSE_ours_mean=mean(RMSE_ours);
RMSE_Alt_mean=mean(RMSE_Alt);

figure;
box on;
hold on;
grid on;
scatter(X,Y,60,'ro','filled');
scatter(X_p,Y_p,60,'ko','filled');
set(gca,'XTick',[0:1:10]);%����Ҫ��ʾ����̶�
set(gca,'YTick',[0:1:10]);%����Ҫ��ʾ����̶�
for qqq=1:1:1
    scatter(X_hat_ours(:,qqq),Y_hat_ours(:,qqq),120,'b+','LineWidth',1);
    scatter(X_p_hat_ours(qqq),Y_p_hat_ours(qqq),120,[1 0.5 0],'x','LineWidth',1);
end
% scatter(X,Y,60,'ro','filled');
% scatter(X_p,Y_p,80,'ko','filled');
xlim([0 10]);
ylim([0 10]);
legend('Real position of active nodes','Real position of passive node', ...
    'Proposed active ranging','Proposed passive ranging');
xlabel('X axis');
ylabel('Y axis');