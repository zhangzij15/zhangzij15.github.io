function [X_a,Y_a,X_p,Y_p]=location_apssive(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance_hat,Difference_hat)

Quanzhi=1/N_p;
% Quanzhi=1;

for qq=1:5
   
for m=1:1:N_a 
   
    G_x=0;
    G_y=0;
    for i=2:1:N_a
        G_x=G_x+2*(distance(X_a(1),Y_a(1),X_a(i),Y_a(i))-Distance_hat(1,i))*(X_a(1)-X_a(i))/distance(X_a(1),Y_a(1),X_a(i),Y_a(i));
        G_y=G_y+2*(distance(X_a(1),Y_a(1),X_a(i),Y_a(i))-Distance_hat(1,i))*(Y_a(1)-Y_a(i))/distance(X_a(1),Y_a(1),X_a(i),Y_a(i));
    end
    for i=2:1:N_a
        for k=1:N_p
        G_x=G_x+Quanzhi*(2*(distance(X_a(1),Y_a(1),X_p(k),Y_p(k))-distance(X_a(i),Y_a(i),X_p(k),Y_p(k))-Difference_hat(1,i,k))*(X_a(1)-X_p(k))/distance(X_a(1),Y_a(1),X_p(k),Y_p(k)));
        G_y=G_y+Quanzhi*(2*(distance(X_a(1),Y_a(1),X_p(k),Y_p(k))-distance(X_a(i),Y_a(i),X_p(k),Y_p(k))-Difference_hat(1,i,k))*(Y_a(1)-Y_p(k))/distance(X_a(1),Y_a(1),X_p(k),Y_p(k)));   
        end
    end
    f1i=zeros(N_a,1);
    f1i_X1=zeros(N_a,1);
    f1i_Y1=zeros(N_a,1);
    for i=2:1:N_a
        f1i(i)=distance(X_a(1),Y_a(1),X_a(i),Y_a(i))-Distance_hat(1,i);
        f1i_X1(i)=(X_a(1)-X_a(i))/distance(X_a(1),Y_a(1),X_a(i),Y_a(i));
        f1i_Y1(i)=(Y_a(1)-Y_a(i))/distance(X_a(1),Y_a(1),X_a(i),Y_a(i));
    end

    f1i_p=zeros(N_a,1);
    f1i_X1_p=zeros(N_a,1);
    f1i_Y1_p=zeros(N_a,1);
    for i=2:1:N_a
        for k=1:N_p
            f1i_p(i)=f1i_p(i)+Quanzhi*(distance(X_a(1),Y_a(1),X_p(k),Y_p(k))-distance(X_a(i),Y_a(i),X_p(k),Y_p(k))-Difference_hat(1,i,k));
            f1i_X1_p(i)=f1i_X1_p(i)+Quanzhi*(X_a(1)-X_p(k))/distance(X_a(1),Y_a(1),X_p(k),Y_p(k));
            f1i_Y1_p(i)=f1i_Y1_p(i)+Quanzhi*(Y_a(1)-Y_p(k))/distance(X_a(1),Y_a(1),X_p(k),Y_p(k));
        end
    end

    L_zi=0;
    L_mu=0;
    for i=2:1:N_a
        L_zi=L_zi+f1i(i)*(G_x*f1i_X1(i)+G_y*f1i_Y1(i));
        L_mu=L_mu+(G_x*f1i_X1(i)+G_y*f1i_Y1(i))^2;
    end
    for i=2:1:N_a
        L_zi=L_zi+f1i_p(i)*(G_x*f1i_X1_p(i)+G_y*f1i_Y1_p(i));
        L_mu=L_mu+(G_x*f1i_X1_p(i)+G_y*f1i_Y1_p(i))^2;
    end
    L=L_zi/L_mu;

    X_a(1)=X_a(1)-L*G_x;
    Y_a(1)=Y_a(1)-L*G_y;

    temp_X=X_a(1);
    temp_Y=Y_a(1);

    for i=1:N_a-1
        X_a(i)=X_a(i+1);
        Y_a(i)=Y_a(i+1); 
    end
    X_a(N_a)=temp_X;
    Y_a(N_a)=temp_Y;

    temp=zeros(1,N_a);
    temp_p=zeros(N_a,N_p);
    for i=1:N_a
        temp(i)=Distance_hat(1,i);
        for k=1:N_p
            temp_p(i,k)=Difference_hat(1,i,k);
        end
    end
    for i=1:1:N_a-1
        for j=i+1:1:N_a-1
            Distance_hat(i,j)=Distance_hat(i+1,j+1);
            for k=1:N_p
                Difference_hat(i,j,k)=Difference_hat(i+1,j+1,k);
            end
        end
    end
    for i=1:N_a-1
        Distance_hat(i,N_a)=temp(i+1);
        for k=1:N_p
            Difference_hat(i,N_a,k)=-temp_p(i+1,k);
        end
    end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%以下是无源节点定位%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for k=1:N_p
    X_p_k=X_p(k);
    Y_p_k=Y_p(k);
    fij=zeros(N_a,N_a);
    fij_x=zeros(N_a,N_a);
    fij_y=zeros(N_a,N_a);
    G_x=0;
    G_y=0;
    for i=1:N_a
        for j=i+1:N_a
            fij(i,j)=distance(X_a(i),Y_a(i),X_p_k,Y_p_k)-distance(X_a(j),Y_a(j),X_p_k,Y_p_k)-Difference_hat(i,j,k); 
            fij_x(i,j)=(X_p_k-X_a(i))/distance(X_a(i),Y_a(i),X_p_k,Y_p_k)-(X_p_k-X_a(j))/distance(X_a(j),Y_a(j),X_p_k,Y_p_k);
            fij_y(i,j)=(Y_p_k-Y_a(i))/distance(X_a(i),Y_a(i),X_p_k,Y_p_k)-(Y_p_k-Y_a(j))/distance(X_a(j),Y_a(j),X_p_k,Y_p_k);
            G_x=G_x+2*fij(i,j)*fij_x(i,j);
            G_y=G_y+2*fij(i,j)*fij_y(i,j);
        end
    end

    L_zi=0;
    L_mu=0;
    for i=1:N_a
        for j=i+1:N_a
            L_zi=L_zi+fij(i,j)*(G_x*fij_x(i,j)+G_y*fij_y(i,j));
            L_mu=L_mu+(G_x*fij_x(i,j)+G_y*fij_y(i,j))^2;
        end
    end
    L=L_zi/L_mu;
    
    X_p(k)=X_p_k-L*G_x;
    X_p(k)=X_p_k-L*G_y;
end

end

end







