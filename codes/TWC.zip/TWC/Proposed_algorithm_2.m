function [Distance_hat,Difference_hat]=Proposed_algorithm_2(N_a,N_p,Delay,noise_power,Distance,Difference,ppm)

e=zeros(N_a+N_p,1);
for i=1:N_a+N_p
    e(i)=ppm*(2*rand()-1)*0.000001;
end

t=zeros(N_a+1,N_a+1);
t_hat=zeros(N_a+1,N_a+1);

t(1,1)=0;
for i=2:N_a+N_p
	t(i,1)=t(1,1)+Distance(1,i);
end

for j=2:N_a
    t(j,j)=t(j,j-1)+Delay;
    for i=1:N_a+N_p
        if i~=j
            t(i,j)=t(j,j)+Distance(i,j);
        end
    end
end

t(1,N_a+1)=t(1,N_a)+Delay;
for i=2:N_a+N_p
    t(i,N_a+1)=t(1,N_a+1)+Distance(1,i);
end


for i=1:N_a+N_p
    for j=1:N_a+1
        t_hat(i,j)=(1+e(i))*t(i,j)+noise_power^2*randn();
    end
end

T_hat=zeros(N_a+N_p,1);
for i=1:N_a+N_p
    T_hat(i)=t_hat(i,N_a+1)-t_hat(i,1);
end
T_mean=max(T_hat)/(1+ppm*0.000001);

Distance_hat=zeros(N_a,N_a);
Difference_hat=zeros(N_a,N_a,N_p);
for i=1:N_a
    for j=i+1:N_a
        D_ab_a=t_hat(i,j)-t_hat(i,i);
        D_ab_b=t_hat(j,j)-t_hat(j,i);    
        Distance_hat(i,j)=T_mean*D_ab_a/T_hat(i)-T_mean*D_ab_b/T_hat(j);
        Distance_hat(i,j)=Distance_hat(i,j)*0.5;
        Distance_hat(j,i)=Distance_hat(i,j);
        for k=1:N_p
            D_ab_x=t_hat(N_a+k,j)-t_hat(N_a+k,i);        
            Difference_hat(i,j,k)=D_ab_x/T_hat(N_a+k)-D_ab_b/2/T_hat(j)-D_ab_a/2/T_hat(i);
            Difference_hat(i,j,k)=-T_mean*Difference_hat(i,j,k);
            Difference_hat(j,i,k)=-Difference_hat(i,j,k);
        end
    end
end
end



