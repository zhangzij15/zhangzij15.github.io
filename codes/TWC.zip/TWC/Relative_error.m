function [R] = Relative_error(N_a,N_p,X_a,Y_a,X_p,Y_p,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat)
R=0;

for i=1:N_a
    R=R+(X_a(i)-X_a_hat(i))^2+(Y_a(i)-Y_a_hat(i))^2;
end

for i=1:N_p
    R=R+(X_p(i)-X_p_hat(i))^2+(Y_p(i)-Y_p_hat(i))^2;
end

R=sqrt(R/(N_a+N_p));
end

