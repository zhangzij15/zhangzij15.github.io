function [R_tof,R_tofd] = ToF_ToFD_error(Distance_hat,Difference_hat,Distance,Difference)

N_a=size(Distance_hat,1);
N_p=size(Difference_hat,3);

R_tof=0;

for i=1:N_a
    for j=i+1:N_a
        R_tof=R_tof+(Distance_hat(i,j)-Distance(i,j))^2;
    end
end
R_tof=(R_tof/(N_a*(N_a-1)/2));

R_tofd=0;
for i=1:N_a
    for j=i+1:N_a
        for k=1:1:N_p
            R_tofd=R_tofd+(Difference_hat(i,j,k)-Difference(i,j,k))^2;
        end
    end
end
R_tofd=(R_tofd/(N_p*(N_a*(N_a-1)/2)));
end

