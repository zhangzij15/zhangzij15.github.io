function [X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = Localization_overall(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance,Difference,Distance_hat,Difference_hat)
%%
B=zeros(N_a,N_a);
temp=0;
for i=1:N_a
    for j=1:N_a
        temp=temp+Distance_hat(i,j)^2;
    end
end
temp=temp/N_a^2;

for i=1:N_a
    for j=1:N_a
        temp1=0; temp2=0;
        for k=1:N_a
            temp1=temp1+Distance_hat(k,j)^2;
            temp2=temp2+Distance_hat(i,k)^2;
        end
        temp1=temp1/N_a; temp2=temp2/N_a;
        B(i,j)=-0.5*(Distance_hat(i,j)^2-temp1-temp2+temp);        
    end
end
[U,V]=eig(B);
V=sqrtm(V);
X=U*V;
X=X(:,[1:2]);
[X(:,1),X(:,2),~] = Relative_localization_2(N_a,X_a,Y_a,zeros(N_a,1),X(:,1),X(:,2),zeros(N_a,1));
X_a_hat=X(:,1);
Y_a_hat=X(:,2);
%%
B=zeros(N_a,N_a);
X_p_hat=zeros(N_p,1);
Y_p_hat=zeros(N_p,1);
X_p=[X_p',Y_p'];
X_a=[X_a',Y_a'];

for k=1:N_p
for m=1:N_a
    for n=1:N_a
        B(m,n)=(Difference_hat(m,1,k)-Difference_hat(n,1,k))^2-(X_a_hat(m,:)-X_a_hat(n,:))*(X_a_hat(m,:)-X_a_hat(n,:))';
    end
end
B=0.5*B;

Z=zeros(N_a,3);

for m=1:N_a
    Z(m,1)=X_a_hat(m)-X_p(k,1);
    Z(m,2)=Y_a_hat(m)-X_p(k,2);
    Z(m,3)=1j*(Difference(m,1,k)+ distance(X_a_hat(1),Y_a_hat(1),X_p(k,1),X_p(k,2)));
end
E=B-Z*Z.';

[U,V]=eig(B);

V=V^(1/2);

X=U*V;

X=[X(:,1),X(:,[N_a-1:N_a])];
[X(:,2),X(:,3),X(:,1)] = Relative_localization_2(N_a,Z(:,1),Z(:,2),Z(:,3),X(:,2),X(:,3),X(:,1));
X=-[X(:,2)-X_a_hat(:),X(:,3)-Y_a_hat(:)];

X=mean(X,1);
X_p_hat(k)=X(1);
Y_p_hat(k)=X(2);
end

end

