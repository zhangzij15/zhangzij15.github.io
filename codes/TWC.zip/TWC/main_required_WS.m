clear all; close all; clc;

N_a=[3:1:12];
WS_ours=N_a+1;
EDT=N_a+1;
AltTWR=3*(N_a.^2+N_a)/2;

figure;
box on;
hold on;
grid on;

plot(N_a,AltTWR,'-^k','LineWidth',1.5);
plot(N_a,EDT,'-pb','LineWidth',1.5);
plot(N_a,WS_ours,'--hr','LineWidth',1.5);

legend('AltDS-TWR','ED-TWR','Proposed active ranging','location','northwest','FontSize',14);
xlabel('Number of active nodes $N_{\rm a}$','Interpreter','latex');
ylabel('Required wideband signals $M$','Interpreter','latex');

set(gca,'FontName','Times','FontSize',12);
