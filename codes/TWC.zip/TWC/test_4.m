clear all; clc;

load('test.mat');

[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = Localization_overall(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance,Difference,Distance_hat,Difference_hat);

X_a=[X_a',Y_a'];
X_p=[X_p',Y_p'];
X_a_hat=[X_a_hat,Y_a_hat];
X_p_hat=[X_p_hat,Y_p_hat];

figure;
box on;
hold on;
grid on;
% set(gca,'XTick',[-20:20:240]);%设置要显示坐标刻度
% set(gca,'YTick',[-20:20:200]);%设置要显示坐标刻度
% axis square;
scatter(X_a_hat(:,1),X_a_hat(:,2),60,'ro','filled');
scatter(X_p_hat(:,1),X_p_hat(:,2),60,'ko','filled');

xlabel('X axis (m)','Interpreter','latex');
ylabel('Y axis (m)','Interpreter','latex');




