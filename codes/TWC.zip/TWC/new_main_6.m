clear all; clc;

N_a=[5:5:45];
N_p=[45:-5:5];

light_speed=299792458;
ppm=400;
Delay=0.001*light_speed;
noise=0.4;
noise_power=noise*10^(-9)*light_speed;

iteration=3000;

%repeat_num=1;

R_tof_EDTWR=zeros(length(N_a),iteration);
R_tofd_EDTWR=zeros(length(N_a),iteration);
R_tof_AltTWR=zeros(length(N_a),iteration);
R_tofd_AltTWR=zeros(length(N_a),iteration);

R_tof_EDTWR_limit=zeros(length(N_a),iteration);
R_tofd_EDTWR_limit=zeros(length(N_a),iteration);
R_tof_AltTWR_limit=zeros(length(N_a),iteration);
R_tofd_AltTWR_limit=zeros(length(N_a),iteration);

R_tof_ours=zeros(length(N_a),iteration);
R_tofd_ours=zeros(length(N_a),iteration);

Nodelength=length(N_a);

parfor p=1:iteration
for q=1:Nodelength
    
X_a=200*rand(N_a(q),1);
Y_a=200*rand(N_a(q),1);
X_p=200*rand(N_p(q),1);  % 6
Y_p=200*rand(N_p(q),1);  % 5.5

repeat_num=floor(3*N_a(q)*(N_a(q)-1)/2/(N_a(q)+1));

[Distance,Difference] = distance_generate(N_a(q)+N_p(q),N_a(q),N_p(q),X_a,Y_a,X_p,Y_p);
[Distance_hat,Difference_hat]=AltTWR(N_a(q),N_p(q),Delay,noise_power^0.5,Distance,Difference,ppm);
[R_tof_AltTWR(q,p),R_tofd_AltTWR(q,p)] = ToF_ToFD_error(Distance_hat,Difference_hat,Distance,Difference);

Distance_hat=0; Difference_hat=0;
for kk=1:repeat_num
[Distance_hat_temp,Difference_hat_temp]=EDTWR(N_a(q),N_p(q),Delay,noise_power^0.5,Distance,Difference,ppm);
Distance_hat=Distance_hat+Distance_hat_temp;
Difference_hat=Difference_hat+Difference_hat_temp;
end
Distance_hat=Distance_hat/repeat_num;
Difference_hat=Difference_hat/repeat_num;
[R_tof_EDTWR(q,p),R_tofd_EDTWR(q,p)] = ToF_ToFD_error(Distance_hat,Difference_hat,Distance,Difference);
[R_tof_EDTWR_limit(q,p),R_tofd_EDTWR_limit(q,p)] = ToF_ToFD_error(Distance_hat_temp,Difference_hat_temp,Distance,Difference);

Distance_hat=0; Difference_hat=0;
for kk=1:repeat_num
[Distance_hat_temp,Difference_hat_temp]=Proposed_algorithm_2(N_a(q),N_p(q),Delay,noise_power^0.5,Distance,Difference,ppm);
Distance_hat=Distance_hat+Distance_hat_temp;
Difference_hat=Difference_hat+Difference_hat_temp;
end
Distance_hat=Distance_hat/repeat_num;
Difference_hat=Difference_hat/repeat_num;
[R_tof_ours(q,p),R_tofd_ours(q,p)] = ToF_ToFD_error(Distance_hat,Difference_hat,Distance,Difference);
[R_tof_ours_limit(q,p),R_tofd_ours_limit(q,p)] = ToF_ToFD_error(Distance_hat_temp,Difference_hat_temp,Distance,Difference);
end
end
R_tof_AltTWR=sqrt(mean(R_tof_AltTWR,2));
R_tofd_AltTWR=sqrt(mean(R_tofd_AltTWR,2));
R_tof_EDTWR=sqrt(mean(R_tof_EDTWR,2));
R_tofd_EDTWR=sqrt(mean(R_tofd_EDTWR,2));
R_tof_ours=sqrt(mean(R_tof_ours,2));
R_tofd_ours=sqrt(mean(R_tofd_ours,2));
R_tof_EDTWR_limit=sqrt(mean(R_tof_EDTWR_limit,2));
R_tofd_EDTWR_limit=sqrt(mean(R_tofd_EDTWR_limit,2));
R_tof_ours_limit=sqrt(mean(R_tof_ours_limit,2));
R_tofd_ours_limit=sqrt(mean(R_tofd_ours_limit,2));

steplength=1;
figure;
box on;
semilogy(N_a,R_tof_AltTWR,'-k',N_a,R_tof_EDTWR_limit,'--b',N_a,R_tof_EDTWR,'-b',N_a,R_tof_ours_limit,'--r',N_a,R_tof_ours,'-r','LineWidth',1.5,'MarkerSize',6);
hold on;
semilogy(N_a(1:steplength:end),R_tof_AltTWR(1:steplength:end),'^k',N_a(1:steplength:end),R_tof_EDTWR_limit(1:steplength:end),'>b',N_a(1:steplength:end),R_tof_EDTWR(1:steplength:end),'pb',N_a(1:steplength:end),R_tof_ours_limit(1:steplength:end),'or',N_a(1:steplength:end),R_tof_ours(1:steplength:end),'hr','LineWidth',1.5,'MarkerSize',6);
h1=semilogy(N_a(end),R_tof_AltTWR(end),'-^k',N_a(end),R_tof_EDTWR_limit(end),'-->b',N_a(end),R_tof_EDTWR(end),'-pb',N_a(end),R_tof_ours_limit(end),'--or',N_a(end),R_tof_ours(end),'-hr','LineWidth',1.5,'MarkerSize',6);
grid on;
h=legend(h1,'AltDS-TWR [17]~\,~~($3{N_{\rm a} \choose 2}$ signals)','NB-TWR [24]~~~~\,~~~($N_{\rm a}+1$ signals)','NB-TWR [24]~~~~\,~~~($3{N_{\rm a} \choose 2}$ signals)','Proposed SM-NR~~~($N_{\rm a}+1$ signals)','Proposed SM-NR~~~($3{N_{\rm a} \choose 2}$ signals)','FontSize',14,'location','northwest');
set(h,'Interpreter','latex');
xlabel('Number of active nodes $N_{\rm a}$','Interpreter','latex');
ylabel('RMSE of absolute ranges $E_{\rm ToF}$ (m)','Interpreter','latex');
set(gca,'FontName','Times','FontSize',12);
ylim([10^(-3) 1])


figure;
box on;
semilogy(N_a,R_tofd_AltTWR,'-k',N_a,R_tofd_EDTWR_limit,'--b',N_a,R_tofd_EDTWR,'-b',N_a,R_tofd_ours_limit,'--r',N_a,R_tofd_ours,'-r','LineWidth',1.5,'MarkerSize',6);
hold on;
semilogy(N_a(1:steplength:end),R_tofd_AltTWR(1:steplength:end),'sk',N_a(1:steplength:end),R_tofd_EDTWR_limit(1:steplength:end),'vb',N_a(1:steplength:end),R_tofd_EDTWR(1:steplength:end),'bd',N_a(1:steplength:end),R_tofd_ours_limit(1:steplength:end),'or',N_a(1:steplength:end),R_tofd_ours(1:steplength:end),'hr','LineWidth',1.5,'MarkerSize',6);
h2=semilogy(N_a(end),R_tofd_AltTWR(end),'-sk',N_a(end),R_tofd_EDTWR_limit(end),'--vb',N_a(end),R_tofd_EDTWR(end),'-bd',N_a(end),R_tofd_ours_limit(end),'--or',N_a(end),R_tofd_ours(end),'-hr','LineWidth',1.5,'MarkerSize',6);
grid on;
legend(h2,'PER [28]~~~~~~~\,~~~~~~($3{N_{\rm a} \choose 2}$ signals)','NB-PR [24]~~~~\,~~~~~~($N_{\rm a}+1$ signals)','NB-PR [24]~~~~\,~~~~~~($3{N_{\rm a} \choose 2}$ signals)','Proposed SM-NR~~~($N_{\rm a}+1$ signals)','Proposed SM-NR~~~($3{N_{\rm a} \choose 2}$ signals)','FontSize',14,'location','northwest','Interpreter','latex');
xlabel('Number of active nodes $N_{\rm a}$','Interpreter','latex');
ylabel('RMSE of differential ranges $E_{\rm ToFD}$ (m)','Interpreter','latex');
set(gca,'FontName','Times','FontSize',12);
ylim([10^(-3) 1])

% figure;
% box on;
% hold on;
% grid on;
% set(gca,'XTick',ppm);%设置要显示坐标刻度
% %set(gca,'XTick',[0:10:100]);%设置要显示坐标刻度
% plot(ppm,R_tof_AltTWR,'-^k','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tof_EDTWR_limit,'->b','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tof_EDTWR,'-pb','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tof_ours_limit,'--or','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tof_ours,'-hr','LineWidth',1.5,'MarkerSize',5);
% 
% legend('AltDS-TWR [17]','NB-TWR [24] (Perform once)','NB-TWR [24]','Proposed SM-NR (Perform once)','Proposed SM-NR','FontSize',14,'location','northwest');
% xlabel('Maximal clock frequency deviation $e_{\max}$ (ppm)','Interpreter','latex');
% ylabel('RMSE of absolute ranges $E_{\rm ToF}$ (mm)','Interpreter','latex');
% % set(gcf,'Units','centimeters','Position',[2 2 18 10]);
% % set(gca,'looseInset',[0 0 0 0]);
% set(gca,'FontName','Times','FontSize',12);

% figure;
% box on;
% hold on;
% grid on;
% set(gca,'XTick',ppm);%设置要显示坐标刻度
% %set(gca,'XTick',[0:10:100]);%设置要显示坐标刻度
% plot(ppm,R_tofd_AltTWR,'-^k','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tofd_EDTWR_limit,'-hb','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tofd_EDTWR,'-pb','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tofd_ours_limit,'--or','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tofd_ours,'-hr','LineWidth',1.5,'MarkerSize',5);
% legend('PER [28]','NB-PR [24] (Perform once)','NB-PR [24]','Proposed SM-NR (Perform once)','Proposed SM-NR','FontSize',14,'location','northwest');
% xlabel('Maximal clock frequency deviation $e_{\max}$ (ppm)','Interpreter','latex');
% ylabel('RMSE of differential ranges $E_{\rm ToFD}$ (mm)','Interpreter','latex');
% % set(gcf,'Units','centimeters','Position',[2 2 18 10]);
% % set(gca,'looseInset',[0 0 0 0]);
% set(gca,'FontName','Times','FontSize',12);
