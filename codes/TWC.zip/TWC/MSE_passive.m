function mse = MSE_passive(N_a,X,Y,X_p,Y_p,Distance_hat,Difference_hat)
mse=0;
for i=1:N_a
    for j=i+1:N_a
        mse=mse+(distance(X(i),Y(i),X(j),Y(j))-Distance_hat(i,j))^2;
    end
end
for i=1:N_a
    for j=i+1:N_a
        mse=mse+(distance(X(i),Y(i),X_p,Y_p)-distance(X(j),Y(j),X_p,Y_p)-Difference_hat(i,j))^2;
    end
end

end

