% clear all; clc;
% 
% load('Location_3.mat');

light_speed=299792458;
ppm=[0:6.25:500];
Delay=0.001*light_speed;
noise=0.05;
noise_power=noise*10^(-9)*light_speed;

[Distance,Difference] = distance_generate(N,N_a,N_p,X_a,Y_a,X_p,Y_p);

iteration=3000;
repeat_num=floor(3*N_a*(N_a-1)/2/(N_a+1));

R_Alt=zeros(length(ppm),iteration,length(noise));
R_EDT=zeros(length(ppm),iteration,length(noise));
R_EDT_limit=zeros(length(ppm),iteration,length(noise));
R_ours=zeros(length(ppm),iteration,length(noise));
R_ours_limit=zeros(length(ppm),iteration,length(noise));

R_Alt_mean=zeros(length(ppm),length(noise));
R_EDT_mean=zeros(length(ppm),length(noise));
R_EDT_limit_mean=zeros(length(ppm),length(noise));
R_ours_mean=zeros(length(ppm),length(noise));
R_ours_limit_mean=zeros(length(ppm),length(noise));

for m=1:length(noise)
for p=1:length(ppm)
parfor q=1:iteration

[Distance_hat,Difference_hat]=AltTWR(N_a,N_p,Delay,noise_power(m)^0.5,Distance,Difference,ppm(p));
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = Localization_overall(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance,Difference,Distance_hat,Difference_hat);
R_Alt(p,q,m)= Relative_error(N_a,N_p,X_a,Y_a,X_p,Y_p,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat);

Distance_hat=0; Difference_hat=0;
for kk=1:repeat_num
[Distance_hat_temp,Difference_hat_temp]=Proposed_algorithm_2(N_a,N_p,Delay,noise_power(m)^0.5,Distance,Difference,ppm(p));
Distance_hat=Distance_hat+Distance_hat_temp;
Difference_hat=Difference_hat+Difference_hat_temp;
end
Distance_hat=Distance_hat/repeat_num;
Difference_hat=Difference_hat/repeat_num;
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = Localization_overall(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance,Difference,Distance_hat_temp,Difference_hat_temp);
R_ours_limit(p,q,m)= Relative_error(N_a,N_p,X_a,Y_a,X_p,Y_p,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat);
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = Localization_overall(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance,Difference,Distance_hat,Difference_hat);
R_ours(p,q,m)= Relative_error(N_a,N_p,X_a,Y_a,X_p,Y_p,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat);

Distance_hat=0; Difference_hat=0;
for kk=1:repeat_num
[Distance_hat_temp,Difference_hat_temp]=EDTWR(N_a,N_p,Delay,noise_power(m)^0.5,Distance,Difference,ppm(p));
Distance_hat=Distance_hat+Distance_hat_temp;
Difference_hat=Difference_hat+Difference_hat_temp;
end
Distance_hat=Distance_hat/repeat_num;
Difference_hat=Difference_hat/repeat_num;
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = Localization_overall(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance,Difference,Distance_hat_temp,Difference_hat_temp);
R_EDT_limit(p,q,m)= Relative_error(N_a,N_p,X_a,Y_a,X_p,Y_p,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat);
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = Localization_overall(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance,Difference,Distance_hat,Difference_hat);
R_EDT(p,q,m)= Relative_error(N_a,N_p,X_a,Y_a,X_p,Y_p,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat);

end
end

for p=1:length(ppm)
R_Alt_mean(p,m)=mean(R_Alt(p,:,m));
R_EDT_mean(p,m)=mean(R_EDT(p,:,m));
R_ours_mean(p,m)=mean(R_ours(p,:,m));
R_EDT_limit_mean(p,m)=mean(R_EDT_limit(p,:,m));
R_ours_limit_mean(p,m)=mean(R_ours_limit(p,:,m));
end
end

steplength=8;
figure;
box on;
semilogy(ppm,R_Alt_mean,'-k',ppm,R_EDT_limit_mean,'--b',ppm,R_EDT_mean,'-b',ppm,R_ours_limit_mean,'--r',ppm,R_ours_mean,'-r','LineWidth',1.5,'MarkerSize',6);
hold on;
semilogy(ppm(1:steplength:end),R_Alt_mean(1:steplength:end),'^k',ppm(1:steplength:end),R_EDT_limit_mean(1:steplength:end),'>b',ppm(1:steplength:end),R_EDT_mean(1:steplength:end),'pb',ppm(1:steplength:end),R_ours_limit_mean(1:steplength:end),'or',ppm(1:steplength:end),R_ours_mean(1:steplength:end),'hr','LineWidth',1.5,'MarkerSize',6);
h1=semilogy(ppm(end),R_Alt_mean(end),'-^k',ppm(end),R_EDT_limit_mean(end),'-->b',ppm(end),R_EDT_mean(end),'-pb',ppm(end),R_ours_limit_mean(end),'--or',ppm(end),R_ours_mean(end),'-hr','LineWidth',1.5,'MarkerSize',6);
grid on;
xlabel('Maximal clock frequency deviation $e_{\max}$ (ppm)','Interpreter','latex');
legend(h1,'AltDS-TWR [17] + PER [28] (2340 signals)','NB-TWR + NB-PR [24]~~~~~~~\,(41 signals)','NB-TWR + NB-PR [24]~~~~~~~\,(2337 signals)','Proposed SM-NR method~~~~~~(41 signals)','Proposed SM-NR method~~~~~~(2337 signals)','FontSize',12,'Interpreter','latex');
ylabel('Error of relative position estimations $\varepsilon$ (m)','Interpreter','latex');
set(gca,'FontName','Times','FontSize',12);

