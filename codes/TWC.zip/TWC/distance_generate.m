function [Distance,Difference] = distance_generate(N,N_a,N_p,X_a,Y_a,X_p,Y_p)
Distance=zeros(N,N);
Difference=zeros(N_a,N_a,N_p);
for i=1:1:N_a
    for j=i+1:1:N_a
        Distance(i,j)=distance(X_a(i),Y_a(i),X_a(j),Y_a(j));
        Distance(j,i)=Distance(i,j);
        for k=1:1:N_p
            Difference(i,j,k)=distance(X_a(i),Y_a(i),X_p(k),Y_p(k))-distance(X_a(j),Y_a(j),X_p(k),Y_p(k));
            Difference(j,i,k)=-Difference(i,j,k);
        end
    end
end
for k=1:N_a
    for j=1:N_p
        Distance(k,N_a+j)=distance(X_a(k),Y_a(k),X_p(j),Y_p(j));
        Distance(N_a+j,k)=Distance(k,N_a+j);
    end
end

for k=1:N_p
    for j=1:N_p
        Distance(N_a+k,N_a+j)=distance(X_p(k),Y_p(k),X_p(j),Y_p(j));
    end
end
end

