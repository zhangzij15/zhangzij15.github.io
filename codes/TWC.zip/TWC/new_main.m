clear all; clc;

% X_a=20*[1.7 4.51 6.8 8.2 3.4 7.7 8.9 2.5 6.71 5.4 2.2 4.2 6 6.5 2.4 4.5 2.9 7.5 5 9];
% X_a=[X_a-10 X_a X_a];
% Y_a=20*[5.2 4.5 6.65 2.6 7.7 4.3 6.5 3.1 9.2 3.5 9.1 6.5 5 3.5 6.9 8.5 4.5 8 5.5 9.5];
% Y_a=[Y_a-10 Y_a Y_a-10];
% 
% X_p=20*[3.9 5.3 5.6 6 3 7.5];% 6
% Y_p=20*[3.92 6.9 7.8 5.5 6 5];%5.5
% X_p=[X_p-10 X_p];
% Y_p=[Y_p-10 Y_p];
% N_a=40;
% N_p=10;
% N=N_a+N_p;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% X_a=zeros(1,40);
% Y_a=zeros(1,40);
% for m=1:5
%     for n=1:8
%         X_a((m-1)*8+n)=30*n-30;
%         Y_a((m-1)*8+n)=40*m-20;
%     end
% end
% X_p=zeros(1,10);
% Y_p=zeros(1,10);
% for m=1:2
%     for n=1:5
%         X_p((m-1)*5+n)=30*n;
%         Y_p((m-1)*5+n)=40*m+40;
%     end
% end
% N_a=length(X_a);
% N_p=length(X_p);
% N=N_a+N_p;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
X_a=zeros(1,40);
Y_a=zeros(1,40);
X_a(1)=90;
Y_a(1)=90;

for m=2:30
    Theta= 2*pi/29*(m-1);
    X_a(m)=X_a(1)+100*cos(Theta);
    Y_a(m)=Y_a(1)+100*sin(Theta);
end

for m=31:40
    Theta= 2*pi/10*(m-1);
    X_a(m)=X_a(1)+75*cos(Theta);
    Y_a(m)=Y_a(1)+75*sin(Theta);
end

X_p=zeros(1,10);
Y_p=zeros(1,10);

for m=1:10
    Theta= 2*pi/10*(m-1);
    X_p(m)=X_a(1)+50*cos(Theta);
    Y_p(m)=Y_a(1)+50*sin(Theta);
end

N_a=length(X_a);
N_p=length(X_p);
N=N_a+N_p;

% save('Location_3.mat','N_a','N_p','N','X_a','Y_a','X_p','Y_p');


light_speed=299792458;
ppm=400;
Delay=0.001*light_speed;
%noise_power=5*10^(-12)*light_speed;
%P=1000;

%P_our=P/(N_a+1);
%noise_for_our=sqrt(1./P_our)*10^(-9)*light_speed; %ns
noise_for_our=0.5*10^(-9)*light_speed;

[Distance,Difference] = distance_generate(N,N_a,N_p,X_a,Y_a,X_p,Y_p);

%[Distance_hat,Difference_hat]=Proposed_algorithm(N_a,N_p,e,Delay,noise_power,Distance,Difference);
% [Distance_hat,Difference_hat]=AltTWR(N_a,N_p,e,Delay,noise_power,Distance,Difference);
[Distance_hat,Difference_hat]=Proposed_algorithm_2(N_a,N_p,Delay,noise_for_our,Distance,Difference,ppm);

% save('test.mat','N_a','N_p','N','X_a','Y_a','X_p','Y_p','Distance','Difference','Distance_hat','Difference_hat');

%[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = Localization_overall(N_a,N_p,X_a,Y_a,X_p,Y_p,Distance,Difference,Distance_hat,Difference_hat);

X_a_hat=X_a;
Y_a_hat=Y_a;
X_p_hat=X_p;
Y_p_hat=Y_p;

for k=3:N_a    
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat]=location_apssive(k,1,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat,Distance_hat,Difference_hat);
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = relative_localization(k,1,X_a,Y_a,X_p,Y_p,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat);
end

for k=2:N_p    
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat]=location_apssive(N_a,k,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat,Distance_hat,Difference_hat);
[X_a_hat,Y_a_hat,X_p_hat,Y_p_hat] = relative_localization(N_a,k,X_a,Y_a,X_p,Y_p,X_a_hat,Y_a_hat,X_p_hat,Y_p_hat);
end


figure;
box on;
hold on;
grid on;
axis square;
% axis square;
scatter(X_a(1:N_a),Y_a(1:N_a),60,'ro','filled');
scatter(X_p(1:N_p),Y_p(1:N_p),60,'kd','filled');
set(gca,'XTick',[-20:20:200]);%设置要显示坐标刻度
set(gca,'YTick',[-20:20:200]);%设置要显示坐标刻度
scatter(X_a_hat(1:N_a),Y_a_hat(1:N_a),120,'b+','LineWidth',1);
scatter(X_p_hat(1:N_p),Y_p_hat(1:N_p),120,[1 0.5 0],'x','LineWidth',1);
% scatter(X,Y,60,'ro','filled');
% scatter(X_p,Y_p,80,'ko','filled');
xlim([-20 200]);
ylim([-20 200]);
legend('Real positions of active nodes','Real positions of silent nodes', ...
    'Estimated positions of active nodes','Estimated positions of silent nodes','location','southwest');
set(gca,'FontName','Times','FontSize',12);
set(legend,'FontName','Times','FontSize',12);


%set (gca,'position',[0.1,0.1,0.9,0.9] );

xlabel('X axis (m)','Interpreter','latex');
ylabel('Y axis (m)','Interpreter','latex');
