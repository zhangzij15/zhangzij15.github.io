clear all; close all; clc;

% N_a=10;
% X=10*rand(N_a,1);
% Y=10*rand(N_a,1);
% X_p=10*rand();
% Y_p=10*rand();
load('Location.mat');
%save('Location.mat','N_a','X','Y','X_p','Y_p');
Ireation=3000;

X_hat_ours=zeros(N_a,Ireation);
Y_hat_ours=zeros(N_a,Ireation);
X_p_hat_ours=zeros(1,Ireation);
Y_p_hat_ours=zeros(1,Ireation);
RMSE_ours=zeros(1,Ireation);

X_hat_EDT=zeros(N_a,Ireation);
Y_hat_EDT=zeros(N_a,Ireation);
X_p_hat_EDT=zeros(1,Ireation);
Y_p_hat_EDT=zeros(1,Ireation);
RMSE_EDT=zeros(1,Ireation);

X_hat_Alt=zeros(N_a,Ireation);
Y_hat_Alt=zeros(N_a,Ireation);
X_p_hat_Alt=zeros(1,Ireation);
Y_p_hat_Alt=zeros(1,Ireation);
RMSE_Alt=zeros(1,Ireation);

light_speed=299792458;
%ppm=[0:400:2000];
ppm=[0:400:2000];

Delay=0.001*light_speed;
noise_power=0*light_speed;

RMSE_ours_mean=zeros(length(ppm),1);
RMSE_EDT_mean=zeros(length(ppm),1);
RMSE_Alt_mean=zeros(length(ppm),1);

for ppp=1:length(ppm)

for qqq=1:Ireation

e=zeros(N_a+1,1);
for i=1:N_a+1
    e(i)=ppm(ppp)*(2*rand()-1)*0.000001;
end
Distance=zeros(N_a+1,N_a+1);
Difference=zeros(N_a,N_a);
for i=1:1:N_a
    for j=i+1:1:N_a
        Distance(i,j)=distance(X(i),Y(i),X(j),Y(j));
        Difference(i,j)=distance(X(i),Y(i),X_p,Y_p)-distance(X(j),Y(j),X_p,Y_p);
    end
end
for j=1:N_a
    Distance(N_a+1,j)=distance(X_p,Y_p,X(j),Y(j));
end
Distance=Distance+Distance';
Difference=Difference-Difference';

[Distance_hat,Difference_hat]=Proposed_algorithm(N_a,e,Delay,noise_power,Distance,Difference);
[X_hat_ours(:,qqq),Y_hat_ours(:,qqq),X_p_hat_ours(1,qqq),Y_p_hat_ours(1,qqq)]=location_apssive(N_a,X,Y,X_p,Y_p,Distance_hat,Difference_hat);
[Distance_hat,Difference_hat]=EDTWR(N_a,e,Delay,noise_power,Distance,Difference);
[X_hat_EDT(:,qqq),Y_hat_EDT(:,qqq),X_p_hat_EDT(1,qqq),Y_p_hat_EDT(1,qqq)]=location_apssive(N_a,X,Y,X_p,Y_p,Distance_hat,Difference_hat);
[Distance_hat,Difference_hat]=AltTWR(N_a,e,Delay,noise_power,Distance,Difference);
[X_hat_Alt(:,qqq),Y_hat_Alt(:,qqq),X_p_hat_Alt(1,qqq),Y_p_hat_Alt(1,qqq)]=location_apssive(N_a,X,Y,X_p,Y_p,Distance_hat,Difference_hat);

RMSE_ours(qqq)=(X_hat_ours(:,qqq)-X)'*(X_hat_ours(:,qqq)-X)+(Y_hat_ours(:,qqq)-Y)'*(Y_hat_ours(:,qqq)-Y);
RMSE_ours(qqq)=RMSE_ours(qqq)+(X_p_hat_ours(1,qqq)-X_p)^2+(Y_p_hat_ours(1,qqq)-Y_p)^2;
RMSE_ours(qqq)=sqrt(RMSE_ours(qqq));

RMSE_EDT(qqq)=(X_hat_EDT(:,qqq)-X)'*(X_hat_EDT(:,qqq)-X)+(Y_hat_EDT(:,qqq)-Y)'*(Y_hat_EDT(:,qqq)-Y);
RMSE_EDT(qqq)=RMSE_EDT(qqq)+(X_p_hat_EDT(1,qqq)-X_p)^2+(Y_p_hat_EDT(1,qqq)-Y_p)^2;
RMSE_EDT(qqq)=sqrt(RMSE_EDT(qqq));

RMSE_Alt(qqq)=(X_hat_Alt(:,qqq)-X)'*(X_hat_Alt(:,qqq)-X)+(Y_hat_Alt(:,qqq)-Y)'*(Y_hat_Alt(:,qqq)-Y);
RMSE_Alt(qqq)=RMSE_Alt(qqq)+(X_p_hat_Alt(1,qqq)-X_p)^2+(Y_p_hat_Alt(1,qqq)-Y_p)^2;
RMSE_Alt(qqq)=sqrt(RMSE_Alt(qqq));
end

RMSE_ours_mean(ppp)=mean(RMSE_ours);
RMSE_EDT_mean(ppp)=mean(RMSE_EDT);
RMSE_Alt_mean(ppp)=mean(RMSE_Alt);

end

figure;
box on;
hold on;
grid on;
set(gca,'XTick',ppm);%����Ҫ��ʾ����̶�

plot(ppm,RMSE_ours_mean,'-p','LineWidth',1.5,'MarkerSize',5);
plot(ppm,RMSE_EDT_mean,'-^','LineWidth',1.5,'MarkerSize',5);
plot(ppm,RMSE_Alt_mean,'-h','LineWidth',1.5,'MarkerSize',5);
legend('Proposed ranging algorithms','ED-TWR+NB-PR','Alt-DSTWR+PER','FontSize',14);
xlabel('Maximum clock frequency deviation e_{max} (ppm)');
ylabel('RMSE (m)');
% set(gcf,'Units','centimeters','Position',[2 2 18 10]);
% set(gca,'looseInset',[0 0 0 0]);
set(gca,'FontName','Times','FontSize',14);

