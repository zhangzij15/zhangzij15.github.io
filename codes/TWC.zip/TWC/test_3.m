clear all; clc;

load('test.mat');

clear N

B=zeros(N_a,N_a);
X_p_hat=zeros(N_p,2);
X_a=[X_a',Y_a'];
X_p=[X_p',Y_p'];

for k=1:N_p
for m=1:N_a
    for n=1:N_a
        B(m,n)=(Difference_hat(m,1,k)-Difference_hat(n,1,k))^2-(X_a(m,:)-X_a(n,:))*(X_a(m,:)-X_a(n,:))';
    end
end
B=0.5*B;

Z=zeros(N_a,3);

for m=1:N_a
    Z(m,1)=X_a(m,1)-X_p(k,1);
    Z(m,2)=X_a(m,2)-X_p(k,2);
    Z(m,3)=1j*(Difference(m,1,k)+Distance(1,N_a+k));
end
E=B-Z*Z.';

[U,V]=eig(B);

V=V^(1/2);

X=U*V;

E=X*X.'-Z*Z.';

X=[X(:,1),X(:,[N_a-1:N_a])];

[X(:,2),X(:,3),X(:,1)] = Relative_localization_2(N_a,Z(:,1),Z(:,2),Z(:,3),X(:,2),X(:,3),X(:,1));

X=-[X(:,2)-X_a(:,1),X(:,3)-X_a(:,2)];

X=mean(X,1);
X_p_hat(k,:)=X;
end



figure;
box on;
hold on;
grid on;
% axis square;
% scatter(X_a(:,1),X_a(:,2),60,'ro','filled');
scatter(X_p(:,1),X_p(:,2),60,'ko','filled');

xlabel('X axis (m)','Interpreter','latex');
ylabel('Y axis (m)','Interpreter','latex');

figure;
box on;
hold on;
grid on;
% axis square;
scatter(X_p_hat(:,1),X_p_hat(:,2),60,'ko','filled');

xlabel('X axis (m)','Interpreter','latex');
ylabel('Y axis (m)','Interpreter','latex');

% E=X*X.'-Z*Z.';
% 
% E=X-X_a;


