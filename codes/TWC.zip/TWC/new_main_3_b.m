clear all; clc;

N_a=40;
N_p=10;
N=N_a+N_p;

light_speed=299792458;
ppm=400;
Delay=0.001*light_speed;
noise=[0:0.025:2];
noise_power=noise*10^(-9)*light_speed;

iteration=3000;

repeat_num=floor(3*N_a*(N_a-1)/2/(N_a+1));
%repeat_num=1;

R_tof_EDTWR=zeros(length(noise),iteration);
R_tofd_EDTWR=zeros(length(noise),iteration);
R_tof_AltTWR=zeros(length(noise),iteration);
R_tofd_AltTWR=zeros(length(noise),iteration);

R_tof_EDTWR_limit=zeros(length(noise),iteration);
R_tofd_EDTWR_limit=zeros(length(noise),iteration);
R_tof_AltTWR_limit=zeros(length(noise),iteration);
R_tofd_AltTWR_limit=zeros(length(noise),iteration);

R_tof_ours=zeros(length(noise),iteration);
R_tofd_ours=zeros(length(noise),iteration);

noiselength=length(noise);

parfor p=1:iteration
for q=1:noiselength
X_a=200*rand(N_a,1);
Y_a=200*rand(N_a,1);
X_p=200*rand(N_p,1);  % 6
Y_p=200*rand(N_p,1); %5.5

[Distance,Difference] = distance_generate(N,N_a,N_p,X_a,Y_a,X_p,Y_p);
[Distance_hat,Difference_hat]=AltTWR(N_a,N_p,Delay,noise_power(q)^0.5,Distance,Difference,ppm);
[R_tof_AltTWR(q,p),R_tofd_AltTWR(q,p)] = ToF_ToFD_error(Distance_hat,Difference_hat,Distance,Difference);

Distance_hat=0; Difference_hat=0;
for kk=1:repeat_num
[Distance_hat_temp,Difference_hat_temp]=EDTWR(N_a,N_p,Delay,noise_power(q)^0.5,Distance,Difference,ppm);
Distance_hat=Distance_hat+Distance_hat_temp;
Difference_hat=Difference_hat+Difference_hat_temp;
end
Distance_hat=Distance_hat/repeat_num;
Difference_hat=Difference_hat/repeat_num;
[R_tof_EDTWR(q,p),R_tofd_EDTWR(q,p)] = ToF_ToFD_error(Distance_hat,Difference_hat,Distance,Difference);
[R_tof_EDTWR_limit(q,p),R_tofd_EDTWR_limit(q,p)] = ToF_ToFD_error(Distance_hat_temp,Difference_hat_temp,Distance,Difference);

Distance_hat=0; Difference_hat=0;
for kk=1:repeat_num
[Distance_hat_temp,Difference_hat_temp]=Proposed_algorithm_2(N_a,N_p,Delay,noise_power(q)^0.5,Distance,Difference,ppm);
Distance_hat=Distance_hat+Distance_hat_temp;
Difference_hat=Difference_hat+Difference_hat_temp;
end
Distance_hat=Distance_hat/repeat_num;
Difference_hat=Difference_hat/repeat_num;
[R_tof_ours(q,p),R_tofd_ours(q,p)] = ToF_ToFD_error(Distance_hat,Difference_hat,Distance,Difference);
[R_tof_ours_limit(q,p),R_tofd_ours_limit(q,p)] = ToF_ToFD_error(Distance_hat_temp,Difference_hat_temp,Distance,Difference);
end
end
R_tof_AltTWR=sqrt(mean(R_tof_AltTWR,2));
R_tofd_AltTWR=sqrt(mean(R_tofd_AltTWR,2));
R_tof_EDTWR=sqrt(mean(R_tof_EDTWR,2));
R_tofd_EDTWR=sqrt(mean(R_tofd_EDTWR,2));
R_tof_ours=sqrt(mean(R_tof_ours,2));
R_tofd_ours=sqrt(mean(R_tofd_ours,2));
R_tof_EDTWR_limit=sqrt(mean(R_tof_EDTWR_limit,2));
R_tofd_EDTWR_limit=sqrt(mean(R_tofd_EDTWR_limit,2));
R_tof_ours_limit=sqrt(mean(R_tof_ours_limit,2));
R_tofd_ours_limit=sqrt(mean(R_tofd_ours_limit,2));

steplength=8;
figure;
box on;
semilogy(noise,R_tof_AltTWR,'-k',noise,R_tof_EDTWR_limit,'--b',noise,R_tof_EDTWR,'-b',noise,R_tof_ours_limit,'--r',noise,R_tof_ours,'-r','LineWidth',1.5,'MarkerSize',6);
hold on;
semilogy(noise(1:steplength:end),R_tof_AltTWR(1:steplength:end),'^k',noise(1:steplength:end),R_tof_EDTWR_limit(1:steplength:end),'>b',noise(1:steplength:end),R_tof_EDTWR(1:steplength:end),'pb',noise(1:steplength:end),R_tof_ours_limit(1:steplength:end),'or',noise(1:steplength:end),R_tof_ours(1:steplength:end),'hr','LineWidth',1.5,'MarkerSize',6);
h1=semilogy(noise(end),R_tof_AltTWR(end),'-^k',noise(end),R_tof_EDTWR_limit(end),'-->b',noise(end),R_tof_EDTWR(end),'-pb',noise(end),R_tof_ours_limit(end),'--or',noise(end),R_tof_ours(end),'-hr','LineWidth',1.5,'MarkerSize',6);
grid on;
legend(h1,'AltDS-TWR [17]~\,~~(2340 signals)','NB-TWR [24]~~~~\,~~~(41 signals)','NB-TWR [24]~~~~\,~~~(2337 signals)','Proposed SM-NR~~~(41 signals)','Proposed SM-NR~~~(2337 signals)','FontSize',14,'location','northwest','Interpreter','latex');
xlabel('Standard deviation of timestamp measurement error $\sigma_{w}$ (ns)','Interpreter','latex');
ylabel('RMSE of absolute ranges $E_{\rm ToF}$ (mm)','Interpreter','latex');
set(gca,'FontName','Times','FontSize',12);



figure;
box on;
semilogy(noise,R_tofd_AltTWR,'-k',noise,R_tofd_EDTWR_limit,'--b',noise,R_tofd_EDTWR,'-b',noise,R_tofd_ours_limit,'--r',noise,R_tofd_ours,'-r','LineWidth',1.5,'MarkerSize',6);
hold on;
semilogy(noise(1:steplength:end),R_tofd_AltTWR(1:steplength:end),'sk',noise(1:steplength:end),R_tofd_EDTWR_limit(1:steplength:end),'vb',noise(1:steplength:end),R_tofd_EDTWR(1:steplength:end),'bd',noise(1:steplength:end),R_tofd_ours_limit(1:steplength:end),'or',noise(1:steplength:end),R_tofd_ours(1:steplength:end),'hr','LineWidth',1.5,'MarkerSize',6);
h2=semilogy(noise(end),R_tofd_AltTWR(end),'-sk',noise(end),R_tofd_EDTWR_limit(end),'--vb',noise(end),R_tofd_EDTWR(end),'-bd',noise(end),R_tofd_ours_limit(end),'--or',noise(end),R_tofd_ours(end),'-hr','LineWidth',1.5,'MarkerSize',6);
grid on;
legend(h2,'PER [28]~~~~~~~\,~~~~~~(2340 signals)','NB-PR [24]~~~~\,~~~~~~(41 signals)','NB-PR [24]~~~~\,~~~~~~(2337 signals)','Proposed SM-NR~~~(41 signals)','Proposed SM-NR~~~(2337 signals)','FontSize',14,'location','northwest','Interpreter','latex');
xlabel('Standard deviation of timestamp measurement error $\sigma_{w}$ (ns)','Interpreter','latex');
ylabel('RMSE of absolute ranges $E_{\rm ToF}$ (mm)','Interpreter','latex');
set(gca,'FontName','Times','FontSize',12);


% figure;
% box on;
% hold on;
% grid on;
% set(gca,'XTick',ppm);%设置要显示坐标刻度
% %set(gca,'XTick',[0:10:100]);%设置要显示坐标刻度
% plot(ppm,R_tof_AltTWR,'-^k','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tof_EDTWR_limit,'->b','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tof_EDTWR,'-pb','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tof_ours_limit,'--or','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tof_ours,'-hr','LineWidth',1.5,'MarkerSize',5);
% 
% legend('AltDS-TWR [17]','NB-TWR [24] (Perform once)','NB-TWR [24]','Proposed SM-NR (Perform once)','Proposed SM-NR','FontSize',14,'location','northwest');
% xlabel('Maximal clock frequency deviation $e_{\max}$ (ppm)','Interpreter','latex');
% ylabel('RMSE of absolute ranges $E_{\rm ToF}$ (mm)','Interpreter','latex');
% % set(gcf,'Units','centimeters','Position',[2 2 18 10]);
% % set(gca,'looseInset',[0 0 0 0]);
% set(gca,'FontName','Times','FontSize',12);

% figure;
% box on;
% hold on;
% grid on;
% set(gca,'XTick',ppm);%设置要显示坐标刻度
% %set(gca,'XTick',[0:10:100]);%设置要显示坐标刻度
% plot(ppm,R_tofd_AltTWR,'-^k','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tofd_EDTWR_limit,'-hb','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tofd_EDTWR,'-pb','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tofd_ours_limit,'--or','LineWidth',1.5,'MarkerSize',5);
% plot(ppm,R_tofd_ours,'-hr','LineWidth',1.5,'MarkerSize',5);
% legend('PER [28]','NB-PR [24] (Perform once)','NB-PR [24]','Proposed SM-NR (Perform once)','Proposed SM-NR','FontSize',14,'location','northwest');
% xlabel('Maximal clock frequency deviation $e_{\max}$ (ppm)','Interpreter','latex');
% ylabel('RMSE of differential ranges $E_{\rm ToFD}$ (mm)','Interpreter','latex');
% % set(gcf,'Units','centimeters','Position',[2 2 18 10]);
% % set(gca,'looseInset',[0 0 0 0]);
% set(gca,'FontName','Times','FontSize',12);
