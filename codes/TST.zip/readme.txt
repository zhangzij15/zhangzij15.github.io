This simulation code package is mainly used to reproduce the results of the following paper [1]:

[1] Z. Zhang and L. Dai, "Reconfigurable intelligent surfaces for 6G: Nine fundamental issues and one critical problem," Tsinghua Sci. Technol., vol. 28, no. 5, pp. 929-939, Oct. 2023. (Invited Paper)

*********************************************************************************************************************************
If you use this simulation code package in any way, please cite the original paper [1] above. 

The author in charge of this simulation code pacakge is: Zijian Zhang (email: zhangzj20@mails.tsinghua.edu.cn).

Reference: We highly respect reproducible research, so we try to provide the simulation codes for our published papers (more information can be found at: 
http://oa.ee.tsinghua.edu.cn/dailinglong/publications/publications.html). 

Please note that the MATLAB R2021a and CVX 3.1 are used for this simulation code package,  and there may be some imcompatibility problems among different software versions. 

Copyright reserved by the Broadband Communications and Signal Processing Laboratory (led by Dr. Linglong Dai), Tsinghua National Laboratory
for Information Science and Technology (TNList), Department of Electronic Engineering, Tsinghua University, Beijing 100084, China. 

*********************************************************************************************************************************
Abstract of the paper: 

Thanks to the recent advances in metamaterials, Reconfigurable Intelligent Surface (RIS) has emerged as a promising technology for future 6G wireless communications. Benefiting from its high array gain, low cost, and low power consumption, RISs are expected to greatly enlarge signal coverage, improve system capacity, and increase energy efficiency. In this article, we systematically overview the emerging RIS technology with the focus on its key basics, nine fundamental issues, and one critical problem. Specifically, we first explain the RIS basics, including its working principles, hardware structures, and potential benefits for communications. Based on these basics, nine fundamental issues of RISs, such as ��What��s the differences between RISs and massive MIMO?�� and��Is RIS really intelligent?��, are explicitly addressed to elaborate its technical features, distinguish it from existing technologies, and clarify some misunderstandings in the literature. Then, one critical problem of RISs is revealed that, due to the ��multiplicative fading�� effect, existing passive RISs can hardly achieve visible performance gains in many communication scenarios with strong direct links. To address this critical problem, a potential solution called active RISs is introduced, and its effectiveness is demonstrated by numerical simulations.

*********************************************************************************************************************************
How to use this simulation code package?

1. Run "main.m" and "main_1_2.m" to obtain the results in Fig. 6.

*********************************************************************************************************************************
Enjoy the reproducible research!






