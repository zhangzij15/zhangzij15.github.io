This simulation code package is mainly used to reproduce the results of the following paper [1]:

[1] Z. Zhang, L. Dai, X. Chen, C. Liu, F. Yang, R. Schober, and H. V. Poor, "Active RISs: Signal modeling, asymptotic analysis, and beamforming design," in Proc. 2022 IEEE Global Communications Conference (IEEE GLOBECOM'22), Rio de Janeiro, Brazil, Dec. 2022.

The joirnal version of this conference paper is:

[2] Z. Zhang, L. Dai, X. Chen, C. Liu, F. Yang, R. Schober, and H. V. Poor, "Active RIS vs. passive RIS: Which will prevail in 6G?," IEEE Trans. Commun., Dec. 2022.
*********************************************************************************************************************************
If you use this simulation code package in any way, please cite the original paper [1] above. 

The author in charge of this simulation code pacakge is: Zijian Zhang (email: zhangzj20@mails.tsinghua.edu.cn).

Reference: We highly respect reproducible research, so we try to provide the simulation codes for our published papers (more information can be found at: 
http://oa.ee.tsinghua.edu.cn/dailinglong/publications/publications.html). 

Please note that the MATLAB R2021a and CVX 3.1 are used for this simulation code package,  and there may be some imcompatibility problems among different software versions. 

Copyright reserved by the Broadband Communications and Signal Processing Laboratory (led by Dr. Linglong Dai), Tsinghua National Laboratory
for Information Science and Technology (TNList), Department of Electronic Engineering, Tsinghua University, Beijing 100084, China. 

*********************************************************************************************************************************
Abstract of the paper: 

Reconfigurable intelligent surfaces (RISs) have emerged as a candidate technology for future 6G networks. However, due to the ��multiplicative fading�� effect, the existing passive RISs only achieve a negligible capacity gain in environments with strong direct links. In this paper, the concept of active RISs is studied to overcome this fundamental limitation. Unlike the existing passive RISs that reflect signals without amplification, active RISs can amplify the reflected signals via amplifiers integrated into their elements. To characterize the signal amplification and incorporate the noise introduced by the active components, we verify the signal model of active RISs through the experimental measurements on a fabricated active RIS element. Based on the verified signal model, we formulate the sum-rate maximization problem for an active RIS aided multi-user multiple-input single-output (MU-MISO) system and a joint transmit precoding and reflect beamforming algorithm is proposed to solve this problem. Simulation results show that, in a typical wireless system, the existing passive RISs can realize only a negligible sum-rate gain of 3%, while the active RISs can achieve a significant sum-rate gain of 62%, thus over coming the ��multiplicative fading�� effect. Finally, we develop a 64-element active RIS aided wireless communication prototype, and the significant gain of active RISs is validated by field test.

*********************************************************************************************************************************
How to use this simulation code package?

1. Run "main_2_conference.m" to obtain the results in Fig. 5.

2. Run "main_2_2_conference.m" to obtain the results in Fig. 6

*********************************************************************************************************************************
Enjoy the reproducible research!






