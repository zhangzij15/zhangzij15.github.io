function [F] = channel_F(N,M,dis)
% N number of receiver
% M number of transmitter
F = zeros(N,M);
F=raylrnd(1,N,M);
for aa=1:N
    for bb=1:M
       F(aa,bb) = F(aa,bb)*exp(1j*2*pi*rand());
    end
end
a = 2*10^(-3)*dis^(-2.8);%3dBi antenna gain
F = sqrt(a)*F;
end

