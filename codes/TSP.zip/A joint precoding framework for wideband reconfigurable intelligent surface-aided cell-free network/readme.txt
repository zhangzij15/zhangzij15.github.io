This simulation code package is mainly used to reproduce the results of the following paper [1]:

[1] Z. Zhang and L. Dai, "A joint precoding framework for wideband reconfigurable intelligent surface-aided cell-free network," IEEE Trans. Signal Process., vol. 69, pp. 4085-4101, Aug. 2021.

The conference version of this journal paper is:

[C1] Z. Zhang and L. Dai, "Capacity improvement in wideband reconfigurable intelligent surface-aided cell-free network," in Proc. IEEE 21st International Workshop on Signal Processing Advances in Wireless Communications (IEEE SPAWC'20), Atlanta, USA, May 2020.

*********************************************************************************************************************************
If you use this simulation code package in any way, please cite the original paper [1] above. 

The author in charge of this simulation code pacakge is: Zijian Zhang (email: zhangzj20@mails.tsinghua.edu.cn).

Reference: We highly respect reproducible research, so we try to provide the simulation codes for our published papers (more information can be found at: 
http://oa.ee.tsinghua.edu.cn/dailinglong/publications/publications.html). 

Please note that the MATLAB R2021a and CVX 3.1 are used for this simulation code package,  and there may be some imcompatibility problems among different software versions. 

Copyright reserved by the Broadband Communications and Signal Processing Laboratory (led by Dr. Linglong Dai), Tsinghua National Laboratory
for Information Science and Technology (TNList), Department of Electronic Engineering, Tsinghua University, Beijing 100084, China. 

*********************************************************************************************************************************
Abstract of the paper: 

Thanks to the strong ability against the inter-cell interference, cell-free network is consideblack as a promising technique to improve network capacity. However, further capacity enhancement requires to deploy more base stations (BSs) with high cost and power consumption. To address this issue, inspired by the recently developed reconfigurable intelligent surface (RIS) technique, we propose the concept of RIS-aided cell-free network to improve the capacity with low cost and power consumption. The key idea is to replace some of the required BSs by low-cost and energy-efficient RISs. Then, in a wideband RIS-aided cell-free network, we formulate the problem of joint precoding design at BSs and RISs to maximize the network capacity. Due to the non-convexity and high complexity of the formulated problem, we develop an alternating optimization algorithm to solve this challenging problem. In particular, we decouple this problem via fractional programming, and solve the subproblems alternatively. Note that most of the considered scenarios in existing works are special cases of the general scenario in this paper, and the proposed joint precoding framework can also serve as a general solution to maximize the capacity in most of existing RIS-aided scenarios. Finally, simulation results demonstrate that, compared with the conventional cell-free network, the network capacity under the proposed scheme can be improved significantly.

*********************************************************************************************************************************
How to use this simulation code package?

1. Run "code_1/main.m" to obtain the results in Fig. 6.

2. Run "code_3/main.m" to obtain the results in Fig. 7.

3. Run "code_1/main_7.m" to obtain the results in Fig. 8.

3. Run "code_1/main_2.m" to obtain the results in Fig. 9.

4. Run "code_1/main_3.m" to obtain the results in Fig. 10.

5. Run "code_2/main.m" to obtain the results in Fig. 11.

6. Run "code_1/main_8.m" to obtain the results in Fig. 12.

7. The functions worth further explanations:
    "MyAlgorithm.m" is the proposed joint precoding scheme in ideal RIS case, which can be used for joint precoding design in most existing works. 
    "MyAlgorithm_xbit.m" is the proposed joint precoding scheme while RIS has discrete phase shifts, which can be used for discrete  precoding directly.
    "MyAlgorithm_sel.m" and "MyAlgorithm_LCR.m" are the proposed two-timescale precoding schemes, which are realized by BrutoForce and LCR, respectively.	
    "MyAlgorithm_Bench.m" is the scheme when direct link doesn't exist, which can verify the effectiveness of the joint design.
    "ReturnNear.m" is used to project the continuous phase shift to discrete phase shift, which can be easily extended to other possible RC settings (such as amplitude-only RIS).

8. Note that running these files costs much time, thus you can simply reduce the number of repetitions by setting "Iteration=1", which may reduce the smoothness of the curve at the same time.

9. More details about the optimization methods in this paper, including Dinklebach, MM, CC, MCQT, PDS, and LCR, can be found in the following references:

[33] K. Shen and W. Yu, "Fractional programming for communication systems��part I: Power control and beamforming," IEEE Trans. Signal Process., vol. 66, no. 10, pp. 2616�C2630, May 2018.

[34] W. Dinklebach, "On nonlinear fractional programming," Manag. Science, vol. 13, no. 7, pp. 492�C498, Oct. 2014.

[35] S. Boyd, N. Parikh, E. Chu, B. Peleato, and J. Eckstein, "Distributed optimization and statistical learning via the alternating direction method of multipliers,"  Nov. 2014, [Online] Available: https://stanford.edu/��boyd/papers/pdf/admm distr stats.pdf.

[42] Y. Sun, P. Babu, and D. P. Palomar, "Majorization-minimization algorithms in signal processing, communications, and machine learning," IEEE Trans. Signal Process., vol. 65, no. 3, pp. 794�C816, Aug. 2017.

[39] T. Nie, S.-C. Fang, Z. Deng, and J. E. Lavery, "On linear conic relaxation of discrete quadratic programs," Optimization Methods and Software, vol. 31, pp. 737�C754, Jan. 2016.

[40] K. C. Toh, M. J. Todd, and R. H. Tutuncu, "SDPT3 �� a Matlab software: package for semidefinite programming, version 1.3," Optimiz. Methods Softw., vol. 11, no. 1-4, pp. 545�C581, Jan. 2008.

*********************************************************************************************************************************
Enjoy the reproducible research!






