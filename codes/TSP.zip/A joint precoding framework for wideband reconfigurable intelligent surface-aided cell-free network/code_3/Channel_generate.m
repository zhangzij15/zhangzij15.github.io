function [ H_bkp,F_rkp,G_brp ] = Channel_generate( B,R,K,P,N_ris,BS_antennas,User_antennas,large_fading_AI,large_fading_DI,Dis_BStoRIS, Dis_BStoUser,Dis_RIStoUser)
H_bkp=zeros(B,K,P,BS_antennas,User_antennas);
F_rkp=zeros(R,K,P,N_ris,User_antennas);
G_brp=zeros(B,R,P,N_ris,BS_antennas);
for b=1:B
    for k=1:K
        for p=1:P
            H_bkp(b,k,p,:,:)=channel_H(BS_antennas,User_antennas,Dis_BStoUser(b,k),large_fading_AI);             
        end
    end
end
for r=1:R
    for k=1:K
        for p=1:P
            F_rkp(r,k,p,:,:)=channel_F(N_ris,User_antennas,Dis_RIStoUser(r,k),large_fading_DI);
        end
    end
end
for b=1:B
    for r=1:R
        for p=1:P
            G_brp(b,r,p,:,:)=channel_G(N_ris,BS_antennas,Dis_BStoRIS(b,r),2);
        end
    end
end

end

