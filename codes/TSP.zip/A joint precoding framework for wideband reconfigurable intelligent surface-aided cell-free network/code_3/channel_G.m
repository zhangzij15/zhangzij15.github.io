function [G] = channel_G(N,M,dis,large_fading)
% N number of receiver
% M number of transmitter
G = ones(N,M);
a = 2*10^(-3)*dis^(-2.2);
a=sqrt(a);
G = a*G;
end

