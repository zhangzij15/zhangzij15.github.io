clear;
tic
Iteration=30;    %�ظ�ʵ�����
dist=65;

B=5;            %��վ����
BS_antennas=2;  %��վ������
User_antennas=2;%�û�������
P_max=0.001;     %��վ���������
K=4;            %�û�6����
P=4;            %���ز�����
R=2;            %RIS����
N_ris=100;      %ÿ��RIS�ϵĵ�Ԫ��
sigma2=10^(-11);%����

fprintf('����\n');

[Dis_BStoRIS, Dis_BStoUser, Dis_RIStoUser]=Position_generate(B,R,K,dist);    %��վRIS�û�λ������  

large_fading_AI=3;                              %�ŵ�˥�� 3
large_fading_DI=2;   
[ H_bkp,F_rkp,G_brp ] = Channel_generate(B,R,K,P,N_ris,BS_antennas,User_antennas,large_fading_AI,large_fading_DI,Dis_BStoRIS, Dis_BStoUser,Dis_RIStoUser);     

[W,Theta] = W_Theta_intialize(P_max,B,K,P,R,N_ris,BS_antennas);       
[~,R_sum_noRIS]=MyAlgorithm_noRIS(B,BS_antennas,User_antennas,P_max,K,P,R,N_ris,sigma2,H_bkp,F_rkp,G_brp,W);      

%[W,Theta] = W_Theta_intialize(P_max,B,K,P,R,N_ris,BS_antennas);   
[~,~,R_sum_bas]=MyAlgorithm_Bas(B,BS_antennas,User_antennas,P_max,K,P,R,N_ris,sigma2,H_bkp,F_rkp,G_brp,W,Theta);

%[W,Theta] = W_Theta_intialize(P_max,B,K,P,R,N_ris,BS_antennas);   
[~,~,R_sum_InFbit]=MyAlgorithm_InFbit(B,BS_antennas,User_antennas,P_max,K,P,R,N_ris,sigma2,H_bkp,F_rkp,G_brp,W,Theta); 

%[W,Theta] = W_Theta_intialize(P_max,B,K,P,R,N_ris,BS_antennas);   
[~,~,R_sum_2bit]=MyAlgorithm_2bit(B,BS_antennas,User_antennas,P_max,K,P,R,N_ris,sigma2,H_bkp,F_rkp,G_brp,W,Theta); 
%[W,Theta] = W_Theta_intialize(P_max,B,K,P,R,N_ris,BS_antennas);   
[~,~,R_sum_1bit]=MyAlgorithm_1bit(B,BS_antennas,User_antennas,P_max,K,P,R,N_ris,sigma2,H_bkp,F_rkp,G_brp,W,Theta);
%[W,Theta] = W_Theta_intialize(P_max,B,K,P,R,N_ris,BS_antennas);   
[~,~,R_sum]=MyAlgorithm(B,BS_antennas,User_antennas,P_max,K,P,R,N_ris,sigma2,H_bkp,F_rkp,G_brp,W,Theta); 

%[W,Theta] = W_Theta_intialize(P_max,B,K,P,R,N_ris,BS_antennas);   
[~,~,R_sum_sel] = MyAlgorithm_sel(B,BS_antennas,User_antennas,P_max,K,P,R,N_ris,sigma2,H_bkp,F_rkp,G_brp,W,Theta);  

%[W,Theta] = W_Theta_intialize(P_max,B,K,P,R,N_ris,BS_antennas);   
[~,~,R_sum_Bench]=MyAlgorithm_Bench(B,BS_antennas,User_antennas,P_max,K,P,R,N_ris,sigma2,0*H_bkp,F_rkp,G_brp,W,Theta); 

R_sum_mean=abs(R_sum);
R_sum_InFbit_mean=abs(R_sum_InFbit);
R_sum_sel_mean=abs(R_sum_sel);
R_sum_2bit_mean=abs(R_sum_2bit);
R_sum_1bit_mean=abs(R_sum_1bit);
R_sum_noRIS_mean=abs(R_sum_noRIS);
R_sum_bas_mean=abs(R_sum_bas);
R_sum_Bench_mean=abs(R_sum_Bench);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%save('temp.mat','Iteration','R_sum_mean','R_sum_InFbit_mean','R_sum_2bit_mean','R_sum_1bit_mean','R_sum_sel_mean','R_sum_Bench_mean','R_sum_bas_mean','R_sum_noRIS_mean');

figure;
hold on;
plot([1:Iteration],R_sum_mean,'-p','LineWidth',1.5);
plot([1:Iteration],R_sum_sel_mean,'-.d','LineWidth',1.5);
plot([1:Iteration],R_sum_InFbit_mean,'--o','LineWidth',1.5);
plot([1:Iteration],R_sum_2bit_mean,'-*','LineWidth',1.5);
plot([1:Iteration],R_sum_1bit_mean,'--s','LineWidth',1.5);
% % plot(N_ris,R_sum_sub_mean,'-^','LineWidth',1.5);
plot([1:Iteration],R_sum_Bench_mean,':*','LineWidth',1.5);
plot([1:Iteration],R_sum_bas_mean,'-s','LineWidth',1.5);
plot([1:Iteration],R_sum_noRIS_mean,'--^','LineWidth',1.5);
% plot(dist,R_sum_ZF_mean,'-d','LineWidth',1.5);
%legend('Ideal RC device','Continuous phase shift','2-bit phase shift','1-bit phase shift','Without RIS','Random phase shift','R_sum_bas_mean')
legend('Ideal RIS case','Two-timescale scheme','Continuous phase shift','2-bit phase shift','1-bit phase shift','Without direct link','Random phase shift','Without RIS','Interpreter','latex')
box on;
grid on
xlabel('Number of iterations $I_{\rm o}$','Interpreter','latex')
ylabel('Weighted sum-rate (bit/s/Hz)','Interpreter','latex')
set(gca,'FontName','Times','FontSize',12);
% xlim([1 30])
% ylim([0 12])
% ylim([20 140]);
toc