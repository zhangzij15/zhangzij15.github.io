function X = OLS(Y, Phi, X_o, s, N)
%%% initialization
X = zeros(N,1);

[~,order] = sort(abs(X_o),'descend');
support = unique(order(1:s));
Phi_s = Phi(:,support);
X(support) = pinv(Phi_s'*Phi_s)*Phi_s'*Y;

