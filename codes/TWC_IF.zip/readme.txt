This simulation code package is mainly used to reproduce the results of the following paper [1]:

[1] M. Cui, Z. Zhang, L. Dai, and K. Huang, “Ice-filling: Near-optimal channel estimation for dense array systems,” IEEE Trans. Wireless Commun., vol. 24, no. 10, pp. 8551-8564, Oct. 2025.

*********************************************************************************************************************************
If you use this simulation code package in any way, please cite the original paper [1] above. 

The author in charge of this simulation code pacakge is: Mingyao Cui (email: cui-my16@tsinghua.org.cn).

Reference: We highly respect reproducible research, so we try to provide the simulation codes for our published papers (more information can be found at: 
http://oa.ee.tsinghua.edu.cn/dailinglong/publications/publications.html). 

Please note that the MATLAB R2024b is used for this simulation code package,  and there may be some imcompatibility problems among different software versions. 

Copyright reserved by the Broadband Communications and Signal Processing Laboratory (led by Dr. Linglong Dai), Tsinghua National Laboratory
for Information Science and Technology (TNList), Department of Electronic Engineering, Tsinghua University, Beijing 100084, China. 


*********************************************************************************************************************************
How to use this simulation code package?

1. Run "NMSE_vs_SNR.m" to obtain the results in Fig. 4.

2. Run "NMSE_vs_Pilot.m" to obtain the results in Fig. 5.

3. Run "NMSE_vs_Spacing.m" to obtain the results in Fig. 6.


*********************************************************************************************************************************
Enjoy the reproducible research!






