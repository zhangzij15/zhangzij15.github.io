function [Dis_BStoRIS, Dis_BStoUser, Dis_RIStoUser]=Position_generate_2(B,R,K)
Dis_BStoRIS=zeros(B,R);
Dis_BStoUser=zeros(B,K);
Dis_RIStoUser=zeros(R,K);

% BS_position=zeros(B,2);
% BS_position(1,:)=[0 20];
% BS_position(2,:)=[0 -20];
% % BS_position(3,:)=[60 15];
% % BS_position(4,:)=[60 -15];
% 
% RIS_position=zeros(R,2);
% RIS_position(1,:)=[30 3];
% RIS_position(2,:)=[45 -3];
% % RIS_position(3,:)=[70 3];
% % RIS_position(4,:)=[80 -3];

BS_position=zeros(B,2);
BS_position(1,:)=[0 -10];
BS_position(2,:)=[0 10];
% BS_position(3,:)=[60 15];
% BS_position(4,:)=[60 -15];

RIS_position=zeros(R,2);
RIS_position(1,:)=[7.5*sqrt(3) 7.5];
RIS_position(2,:)=[7.5 7.5*sqrt(3)];
RIS_position(3,:)=[-7.5*sqrt(3) 7.5];
RIS_position(4,:)=[-7.5 7.5*sqrt(3)];
RIS_position(5,:)=[7.5*sqrt(3) -7.5];
RIS_position(6,:)=[7.5 -7.5*sqrt(3)];
RIS_position(7,:)=[-7.5*sqrt(3) -7.5];
RIS_position(8,:)=[-7.5 -7.5*sqrt(3)];

user_position=zeros(K,2);
user_position(1,:)=[0 15];
user_position(2,:)=[0 -15];
user_position(3,:)=[15 0];
user_position(4,:)=[-15 0];
% user_position(5,:)=[dist+4*(rand()-0.5) 4*(rand()-0.5)];
% user_position(6,:)=[dist+4*(rand()-0.5) 4*(rand()-0.5)];
for b=1:B
    for r=1:R
        BS_position_temp=reshape(BS_position(b,:),2,1);
        RIS_position_temp=reshape(RIS_position(r,:),2,1);
        Dis_BStoRIS(b,r)=distance(BS_position_temp,RIS_position_temp);
    end
end

for b=1:B
    for k=1:K
        BS_position_temp=reshape(BS_position(b,:),2,1);
        user_position_temp=reshape(user_position(k,:),2,1);
        Dis_BStoUser(b,k)=distance(BS_position_temp,user_position_temp);
    end
end

for r=1:R
    for k=1:K
        user_position_temp=reshape(user_position(k,:),2,1);
        RIS_position_temp=reshape(RIS_position(r,:),2,1);
        Dis_RIStoUser(r,k)=distance(RIS_position_temp,user_position_temp);
    end
end

end