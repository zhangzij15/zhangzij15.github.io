close all; clear; clc;
tic
Iteration=3000;    %�ظ�ʵ�����
dist=[15:5:65];
R_sum=zeros(length(dist),Iteration);
R_sum_InFbit=zeros(length(dist),Iteration);
R_sum_2bit=zeros(length(dist),Iteration);
R_sum_1bit=zeros(length(dist),Iteration);
% R_sum_sub=zeros(length(dist),Iteration);
R_sum_bas=zeros(length(dist),Iteration);
% R_sum_ZF=zeros(length(dist),Iteration);
R_sum_noRIS=zeros(length(dist),Iteration);

B=2;            %��վ����
BS_antennas=8;  %��վ������
User_antennas=2;    %�û�������
P_max=1;        %��վ���������
K=4;            %�û�����
P=6;            %���ز�����
R=2;            %RIS����
N_ris=32;      %ÿ��RIS�ϵĵ�Ԫ��
sigma2=10^(-15);%����

fprintf('����\n');
parfor a=1:length(dist)
    fprintf('��%d��\n',a);
    [Dis_BStoRIS, Dis_BStoUser, Dis_RIStoUser]=Position_generate(B,R,K,dist(a));    %��վRIS�û�λ������
    for b=1:Iteration       
        large_fading_AI=3;                              %�ŵ�˥�� 3
        large_fading_DI=2;
        [ H_bkp,F_rkp,G_brp ] = Channel_generate(B,R,K,P,N_ris,BS_antennas,User_antennas,large_fading_AI,large_fading_DI,Dis_BStoRIS, Dis_BStoUser,Dis_RIStoUser);     
        W=sqrt(B*P_max/(B*BS_antennas*K*P))*ones(B*BS_antennas*K*P,1);
        Theta=diag(exp(1j*2*pi*rand(R*N_ris,1)));
%         [W,Theta,R_sum_1bit(a,b)]=MyAlgorithm_1bit(B,BS_antennas,User_antennas,P_max,K,P,R,N_ris,sigma2,H_bkp,F_rkp,G_brp);
%         [W,Theta,R_sum_2bit(a,b)]=MyAlgorithm_2bit(B,BS_antennas,User_antennas,P_max,K,P,R,N_ris,sigma2,H_bkp,F_rkp,G_brp,W,Theta);             
%        [W,Theta,R_sum_InFbit(a,b)]=MyAlgorithm_InFbit(B,BS_antennas,User_antennas,P_max,K,P,R,N_ris,sigma2,H_bkp,F_rkp,G_brp,W,Theta);
         R_sum(a,b)=MyAlgorithm(B,BS_antennas,User_antennas,P_max,K,P,R,N_ris,sigma2,H_bkp,F_rkp,G_brp,W,Theta);
%         %        R_sum_sub(a,b)=MyAlgorithm_Sub(B,BS_antennas,P_max,K,P,R,N_ris,sigma2,H_bkp,F_rkp,G_brp);
%        R_sum_bas(a,b)=MyAlgorithm_Bas(B,BS_antennas,User_antennas,P_max,K,P,R,N_ris,sigma2,H_bkp,F_rkp,G_brp)
%         R_sum_ZF(a,b)=MyAlgorithm_ZF(B,BS_antennas,P_max,K,P,sigma2,H_bkp);
        R_sum_noRIS(a,b)=MyAlgorithm_noRIS(B,BS_antennas,User_antennas,P_max,K,P,R,N_ris,sigma2,H_bkp,F_rkp,G_brp); 
    end
end
R_sum_mean=mean(R_sum,2);
R_sum_InFbit_mean=mean(R_sum_InFbit,2);
R_sum_2bit_mean=mean(R_sum_2bit,2);
R_sum_1bit_mean=mean(R_sum_1bit,2);
% R_sum_sub_mean=mean(R_sum_sub,2);
% R_sum_ZF_mean=mean(R_sum_ZF,2);
R_sum_noRIS_mean=mean(R_sum_noRIS,2);
R_sum_bas_mean=mean(R_sum_bas,2);
% save('temp.mat','dist','R_sum_mean','R_sum_InFbit_mean','R_sum_2bit_mean','R_sum_1bit_mean','R_sum_noRIS_mean','R_sum_bas_mean');
figure;
hold on;
plot(dist,R_sum_mean,'-p','LineWidth',1.5);
% plot(dist,R_sum_InFbit_mean,'--o','LineWidth',1.5);
% plot(dist,R_sum_2bit_mean,'-*','LineWidth',1.5);
% plot(dist,R_sum_1bit_mean,'--s','LineWidth',1.5);
% % plot(dist,R_sum_sub_mean,'-^','LineWidth',1.5);
plot(dist,R_sum_noRIS_mean,'-^','LineWidth',1.5);
%plot(dist,R_sum_bas_mean,'-h','LineWidth',1.5);
% plot(dist,R_sum_ZF_mean,'-d','LineWidth',1.5);
% legend('Ideal RC device','Continuous phase shifter','2-bit phase shifter','1-bit phase shifter','No RIS','Random phase shifter','R_sum_bas_mean')
legend('Ideal RIS case','No RIS')
box on;
grid on
xlabel('Distance L/m')
ylabel('Weighted sum-rate /bit/s/Hz')
%ylim([20 140]);
toc