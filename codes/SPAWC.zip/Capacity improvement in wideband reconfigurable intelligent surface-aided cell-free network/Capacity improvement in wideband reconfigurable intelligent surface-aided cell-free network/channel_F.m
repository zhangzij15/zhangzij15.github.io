function [F] = channel_F(N,M,dis,large_fading)
% N number of receiver
% M number of transmitter
F = zeros(N,M);
F=raylrnd(1,N,M);
for aa=1:N
    for bb=1:M
       F(aa,bb) = F(aa,bb)*exp(1j*2*pi*rand());
    end
end
a = 10^(-2)*dis^(-large_fading);
F = a*F;
end

