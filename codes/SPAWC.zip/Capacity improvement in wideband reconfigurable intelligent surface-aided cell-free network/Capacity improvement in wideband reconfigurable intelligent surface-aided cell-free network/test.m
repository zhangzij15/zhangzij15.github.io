clear all;
load('BS_antennas.mat');