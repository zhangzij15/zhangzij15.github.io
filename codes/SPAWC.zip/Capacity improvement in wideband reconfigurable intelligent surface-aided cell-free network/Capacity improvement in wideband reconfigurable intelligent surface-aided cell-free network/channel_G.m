function [G] = channel_G(N,M,dis,large_fading)
% N number of receiver
% M number of transmitter
G = ones(N,M);
a = 10^(-2)*dis^(-large_fading);
G = a*G;
end

