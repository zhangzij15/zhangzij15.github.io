function [H] = channel_H(N,M,dis,large_fading)
% N number of receiver
% M number of transmitter
H = zeros(N,M);
H=raylrnd(1,N,M);
for aa=1:N
    for bb=1:M
       H(aa,bb) = H(aa,bb)*exp(1j*2*pi*rand());
    end
end
a = 10^(-3)*dis^(-large_fading);
H = a*H;
end

