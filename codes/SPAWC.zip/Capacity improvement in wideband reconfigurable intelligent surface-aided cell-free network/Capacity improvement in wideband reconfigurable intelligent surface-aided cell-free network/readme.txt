This simulation code package is mainly used to reproduce the results of the following paper [1]:

[1] Z. Zhang and L. Dai,��Capacity improvement in wideband reconfigurable intelligent surface-aided cell-free network,��in Proc. IEEE 21st International Workshop on Signal Processing Advances in Wireless Communications (IEEE SPAWC'20), Atlanta, USA, May 2020. 

*********************************************************************************************************************************
If you use this simulation code package in any way, please cite the original paper [1] above. 
 
The author in charge of this simulation code pacakge is: Zijian Zhang (email: zhangzij15@tsinghua.org.cn).

Reference: We highly respect reproducible research, so we try to provide the simulation codes for our published papers (more information can be found at: 
http://oa.ee.tsinghua.edu.cn/dailinglong/publications/publications.html). 

Please note that the MATLAB R2020a and CVX 2.0 are used for this simulation code package,  and there may be some imcompatibility problems among different MATLAB/CVX versions. 

Copyright reserved by the Broadband Communications and Signal Processing Laboratory (led by Dr. Linglong Dai), Beijing National Research Center for Information Science and Technology (BNRist), Department of Electronic Engineering, Tsinghua University, Beijing 100084, China. 

*********************************************************************************************************************************
Abstract of the paper: 

Thanks to the strong ability against the inter-cell interference, cell-free network has been considered as a promising technique to improve the network capacity of future wireless systems. However, for further capacity enhancement, it requires to deploy more base stations (BSs) with high cost and power consumption. To address the issue, inspired by the recently proposed technique called reconfigurable intelligent surface (RIS), we propose the concept of RIS-aided cell-free network to improve the network capacity with low cost and power consumption. Then, for the proposed RIS-aided cell-free network in the typical wideband scenario, we formulate the joint precoding design problem at the BSs and RISs to maximize the network capacity. Due to the non-convexity and high complexity of the formulated problem, we develop an alternating optimization algorithm to solve this challenging problem. Note that most of the considered scenarios in existing works are special cases of the general scenario in this paper, and the proposed joint precoding framework can also serve as a general solution to maximize the capacity in most of existing RIS-aided scenarios. Finally, simulation results verify that, compared with the conventional cell-free network, the network capacity of the proposed scheme can be improved significantly.
*********************************************************************************************************************************
How to use this simulation code package?

All figures can be derived by running the corresponding m file.
The simulation results in Fig. 3 can be directly obtained by running main.m. 
Note that this costs much time, thus you can simply reduce the number of repetitions by setting "Iteration=1" in main.m, which may reduce the smoothness of the curve at the same time.
Besides, some codes of theschemes with low-resolution RIS phase shift are also provided as "MyAlgorithm_2bit.m" and etc. You can simply uncomment the related lines in main.m to use them.
*********************************************************************************************************************************
Enjoy the reproducible research!








