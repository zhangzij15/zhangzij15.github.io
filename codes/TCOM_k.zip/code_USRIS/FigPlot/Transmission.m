%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This simulation code package is mainly used to reproduce the results of 
% the following paper [1]:
% [1] K. Liu, Z. Zhang, L. Dai, and L. Hanzo, “Compact User-Side 
% Reconfigurable Intelligent Surfaces for Uplink Transmission,” arXiv 
% preprint arXiv:2107.08698, Jul. 2021.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all; clear all;
rpt = 12;
Dis_BS2RIS = 20; Dis_RIS2User = 0.02; Dis_Layer = 0.02; % distance
M = 8; K = 2; % # of antennas
R = 2; N1 = [12, 16]; N2 = [8, 12]; % # of vertical and horizontal elements
Sigma = 1E-6; % power of noise
loss = 0.8; % energy loss of transmissive RIS
EUR_threshold = 1/6;
RISWidth = 2; % sidewidth of RIS element = lambda/RISWidth
f = 2.5E9; c = 3E8; lambda = c/f;
Pmax_dB = -3:1:3; Pmax = db2pow(Pmax_dB);

tic;

%%%%%%%%%% Multi-Layer Case %%%%%%%%%%
% Generate Position
[User_Pos, User_y] = User_Generation(lambda, K);
[RIS_Pos, RIS_y] = RIS_Generation(lambda, N2, R, Dis_RIS2User, Dis_Layer, RISWidth);
[BS_Pos, BS_y] = BS_Generation(lambda, M, R, Dis_RIS2User, Dis_BS2RIS);
% Generate Channel
[g, f, ~] = NearFieldChannel(lambda, M, N2, K, R, User_Pos, User_y, RIS_Pos, RIS_y, BS_Pos, BS_y);
% Multi-Layer Transmit Beamformer Design
[SNR_MultiLayer_UC, UC_theta, UC_h, UC_Ratio1, UC_Ratio2, UC_SNR] ...
    = Precoding_MultiLayer(g, f, Sigma, Pmax, rpt, R, loss, N2, EUR_threshold);

%%%%%%%%%% Single-Layer Case %%%%%%%%%%
% Generate Position
[User_Pos, User_y] = User_Generation(lambda, K);
[RIS_Pos, RIS_y] = RIS_Generation(lambda, N1, R, Dis_RIS2User, Dis_Layer, RISWidth);
[BS_Pos, BS_y] = BS_Generation(lambda, M, R, Dis_RIS2User, Dis_BS2RIS);
% Generate Channel
[~, f, g1] = NearFieldChannel(lambda, M, N1, K, R, User_Pos, User_y, RIS_Pos, RIS_y, BS_Pos, BS_y);
% Single-Layer Precoding
[SNR_SingleLayer_CC, SNR_SingleLayer_UC, Tran_h, Tran_theta, Ref_SNR, Tran_SNR, Tran_Ratio] ...
    = Precoding_SingleLayer(g1, f(:, 1:K), Sigma, Pmax, rpt, loss, N1, EUR_threshold);

%%%%%%%%%% No RIS %%%%%%%%%%
% Generate Channel
g = NoRISChannel(lambda, M, K, User_Pos, User_y, BS_Pos, BS_y);
% Precoding
SNR_NoRIS = Precoding_NoRIS(g, Sigma, Pmax);

toc;

SNR_SingleLayer_CC = pow2db(SNR_SingleLayer_CC);
SNR_MultiLayer_UC = pow2db(SNR_MultiLayer_UC);
SNR_SingleLayer_UC = pow2db(SNR_SingleLayer_UC);
SNR_NoRIS = pow2db(SNR_NoRIS);

% Figure Plot
Plot_P2SNR(Pmax_dB, SNR_SingleLayer_CC, SNR_MultiLayer_UC, SNR_SingleLayer_UC, SNR_NoRIS);
Plot_Pattern(UC_theta, UC_h, Tran_h, Tran_theta);
Plot_Convergence(UC_SNR, Ref_SNR, Tran_SNR);

% Display EAR
[UC_Ratio1, UC_Ratio2, (UC_Ratio1+UC_Ratio2)/2, Tran_Ratio]