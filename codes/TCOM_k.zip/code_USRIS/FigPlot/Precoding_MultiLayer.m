function [SNR, theta, h, ratio1, ratio2, SNRPlot] = ...
    Precoding_MultiLayer(g, f, Sigma, Pmax, rpt, R, attenuation, N1, EUR_threshold)
N = size(g, 1);
K = size(f, 2)-(R-1)*N;
v = ones(size(g, 2), 1);
theta = exp(1j*2*pi*rand(N, R));
SNRPlot = zeros(rpt, 1);
for t = 1:rpt
    a = g*v;
    for r = R:-1:2
        a = f(:, K+1+N*(r-2):K+N*(r-1))'*diag(theta(:, r))'*a;
    end
    a = f(:, 1:K)'*diag(theta(:, 1))'*a;
    w = a/norm(a);
    b = v'*g';
    for r = R:-1:2
        b = b*diag(theta(:, r))*f(:, K+1+N*(r-2):K+N*(r-1));
    end
    b = b*diag(f(:, 1:K)*w);
    theta(:, 1) = exp(1j*angle(b'));
    for l = 2:R
        b = v'*g';
        for r = R:-1:l+1
            b = b*diag(theta(:, r))*f(:, K+1+N*(r-2):K+N*(r-1));
        end
        DiagMat = f(:, K+1+N*(l-2):K+N*(l-1));
        for r = l-1:-1:2
            DiagMat = DiagMat*diag(theta(:, r))*f(:, K+1+N*(r-2):K+N*(r-1));
        end
        DiagMat = DiagMat*diag(theta(:, 1))*f(:, 1:K)*w;
        b = b*diag(DiagMat);
        theta(:, l) = exp(1j*angle(b'));
    end
    Prd = diag(theta(:, 1))*f(:, 1:K);
    for r = R:-1:2
        Prd = diag(theta(:, r))*f(:, K+1+N*(r-2):K+N*(r-1))*Prd;
    end
    [v, ~] = eigs(g'*Prd*w*w'*Prd'*g, 1);
    SNR = abs(v'*g'*Prd*w)^2/norm(v)^2/Sigma;
    SNRPlot(t) = SNR;
end
SNR = SNR*Pmax;

Width1 = N1(1);
Width2 = N1(2);
h = zeros(Width1, Width2, R);
PlotPrd = f(:, 1:K)*w;
h(:, :, 1) = reshape(PlotPrd, Width2, Width1)';
for r = 2:R
    PlotPrd = f(:, K+1+N*(r-2):K+N*(r-1))*diag(theta(:, r-1))*PlotPrd;
    PlotPrd = PlotPrd*attenuation;
    h(:, :, r) = reshape(PlotPrd, Width2, Width1)';
end

maxh = max(abs(h).^2, [], 'all');
minh = min(abs(h).^2, [], 'all');
clims = [minh maxh];
%%% plot in one figure
% figure;
% for r = 1:R
%     subplot(1, R, r);
%     imagesc(abs(h(:, :, r)).^2, clims);
%     axis equal;
%     axis off;
%     title(['Layer ', num2str(r)]);
% end

%%% plot in R figures
gcfPosition = [179,742,378,275;
    179,387,378,275];
for r = 1:R
    figure;
    imagesc(pow2db(abs(h(:, :, r)).^2), [-40 -10]);
    colormap(jet);
    axis equal;
    axis off;
    title(['UC-RIS: Layer ', num2str(r)], 'Fontsize', 15);
    set(gcf, 'Position', gcfPosition(r, :));
end

Energy1 = sum(abs(h(:, :, 1)).^2, 'all');
Energy2 = sum(abs(h(:, :, 2)).^2, 'all');

ratio1 = sum(abs(h(:, :, 1)).^2>Energy1/numel(h(:, :, 1))*EUR_threshold, 'all')/numel(h(:, :, 1));
ratio2 = sum(abs(h(:, :, 2)).^2>Energy2/numel(h(:, :, 2))*EUR_threshold, 'all')/numel(h(:, :, 2));
end