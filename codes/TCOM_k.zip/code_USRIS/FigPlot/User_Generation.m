function [BS_Pos, BS_y] = User_Generation(lambda, K)
BS_y = 0;
BS_Pos = zeros(K, 2);
for k = 1:K
    BS_Pos(k, :) = [-(ceil(K/2)-1)*lambda/2-lambda/4+(k-1)*lambda/2, 0];
end
end