function [g, f, g1] = NearFieldChannel(lambda, ...
    M, N1, K, R, ...
    User_Pos, User_y, ...
    RIS_Pos, RIS_y, ...
    BS_Pos, BS_y)
N = N1(1)*N1(2);
g = zeros(N, M);
for n = 1:N
    for m = 1:M
        Dis = DisCal([RIS_Pos(n, 1) RIS_Pos(n, 2) RIS_y(end)], ...
            [BS_Pos(m, 1) BS_Pos(m, 2) BS_y]);
        g(n, m) = lambda/4/pi/Dis*exp(-1j*2*pi*Dis/lambda);
    end
end
f = zeros(N, K+N*(R-1));
for n = 1:N
    for k = 1:K
        f(n, k) = GainCal(lambda, RIS_Pos(n, 1), RIS_Pos(n, 2), ...
            User_Pos(k, 1), User_Pos(k, 2), RIS_y(1)-User_y);
    end
end
temp = zeros(N, N);
for n1 = 1:N
    for n2 = 1:N
        temp(n1, n2) = GainCal(lambda, RIS_Pos(n1, 1), RIS_Pos(n1, 2), ...
            RIS_Pos(n2, 1), RIS_Pos(n2, 2), RIS_y(2)-RIS_y(1));
    end
end
f(:, K+1:end) = repmat(temp, 1, R-1);
g1 = zeros(N, M);
for n = 1:N
    for m = 1:M
        Dis = DisCal([RIS_Pos(n, 1) RIS_Pos(n, 2) RIS_y(1)], ...
            [BS_Pos(m, 1) BS_Pos(m, 2) BS_y]);
        g1(n, m) = lambda/4/pi/Dis*exp(-1j*2*pi*Dis/lambda);
    end
end
end

