function h = GainCal(lambda, xn, zn, xt, zt, d)
X = [lambda/4+xn-xt, lambda/4-xn+xt];
Z = [lambda/4+zn-zt, lambda/4-zn+zt];
h = 0;
for i = 1:2
    for j = 1:2
        x = X(i);
        z = Z(j);
        l = sqrt(x^2+z^2+d^2);
        h = h+x*z*d/3/(z^2+d^2)/l+2/3*atan(x*z/d/l);
    end
end
h = h/4/pi;
h = sqrt(h);
h = h*exp(-1j*2*pi*d/lambda);
end