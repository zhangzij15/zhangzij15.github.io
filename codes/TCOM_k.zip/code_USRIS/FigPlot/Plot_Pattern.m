function Plot_Pattern(UC_theta, UC_h, Tran_h, Tran_theta)
N = size(UC_theta, 1);
N2 = size(Tran_theta, 1);
idx = (0 : N-1)';
idx2 = (0 : N2-1)';
AngleSet = linspace(0, 2*pi, 1E5);
Hset = exp(1j * pi * idx * cos(AngleSet));
Hset2 = exp(1j * pi * idx2 * cos(AngleSet));
pat1 = diag(UC_theta(:, 1))*reshape(UC_h(:, :, 1), [], 1);
pat2 = diag(UC_theta(:, 2))*reshape(UC_h(:, :, 2), [], 1);
pat_Tran = diag(Tran_theta)*reshape(Tran_h, [], 1);

pat1 = reshape(pat1, [], 1);
pat2 = reshape(pat2, [], 1);
pat_Tran = reshape(pat_Tran, [], 1);
pat1_Transpose = reshape(pat1.', [], 1);
pat2_Transpose = reshape(pat2.', [], 1);
pat_Tran_Transpose = reshape(pat_Tran.', [], 1);

amp1 = abs(Hset'*pat1);
amp2 = abs(Hset'*pat2);
amp_Tran = abs(Hset2'*pat_Tran);
amp1_Transpose = abs(Hset'*pat1_Transpose);
amp2_Transpose = abs(Hset'*pat2_Transpose);
amp_Tran_Transpose = abs(Hset2'*pat_Tran_Transpose);

% % Normalization
% max_amp = max(amp2);
% amp2 = mag2db(amp2/max_amp);
% amp_Tran = mag2db(amp_Tran/max_amp);
% amp1 = mag2db(amp1/max_amp);


figure;
hold on;
box on;
plot(AngleSet/pi*180, amp2, 'Linewidth', 2);
plot(AngleSet/pi*180, amp_Tran, ':', 'Linewidth', 2);
plot(AngleSet/pi*180, amp1, '--', 'Linewidth', 2);
legend(['2^{nd} layer of multi-layer US-RIS'], 'Single-layer US-RIS', ...
    ['1^{st} layer of multi-layer US-RIS'], 'Fontsize', 15, 'Fontname', 'Times', ...
    'Position', [0.144642857142857,0.647619047619048,0.416071428571429,0.15952380952381]);
% title('Radiation Pattern', 'Fontsize', 15);
xlim([60 120]);
xticks(60:10:120);
xlabel('$\theta$ (deg)', 'Fontsize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
ylabel('Amplitude', 'Fontsize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
grid on;

% subplot(212);
% plot(AngleSet/pi*180, amp2_Transpose, 'Linewidth', 2);
% hold on;
% plot(AngleSet/pi*180, amp_Tran_Transpose, 'Linewidth', 2);
% plot(AngleSet/pi*180, amp1_Transpose, 'Linewidth', 2);
% legend('2^{nd} Layer of Multi-layer UC-RIS', 'Single-layer UC-RIS', ...
%     '1^{st} Layer of Multi-layer UC-RIS', 'Fontsize', 15);
% title('Radiation Pattern', 'Fontsize', 15);
% xlim([0 180]);
% grid on;

set(gcf, 'Position', [1119,97,560,420]);
end