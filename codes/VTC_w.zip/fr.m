function [output] = fr(R, S_num, S_list, n_sel, N_rf, r)

    if (S_num == 0) || (n_sel == N_rf && r == N_rf+1)
        output = 0;
    else
        temp = 0;
        cnt = 0;
        for i_iter = 1:S_num
            for j_iter = i_iter:S_num
                temp = temp+abs(R(S_list(i_iter), S_list(j_iter)));
                cnt = cnt+1;
            end
        end
        output = temp/S_num;
    end
end

