close all; clc;
clear all;

fc = 30e9;
B = 5e9;
M_tx = 256;
M_rx = 256;
Nt = M_tx;
Nr = M_rx;

c = 3e8;
eps = 1e-2;

lambda = c/fc;

d_near = 2*(M_tx*lambda/2)^2/lambda;

tx_start = -(M_tx/2-0.5)*lambda;
tx_loc = tx_start:lambda:-tx_start;

rx_start = -(M_rx/2-0.5)*lambda;
rx_loc = rx_start:lambda:-rx_start;

% D_list = [2,4,8,16,32,64,128];
% [~, d_len] = size(D_list);
% eigen_value = zeros(d_len, M_tx);
% power = zeros(1,d_len);
% rank_list = zeros(1,d_len);
% for i_d = 1:d_len
%     D = D_list(i_d);
% 
%     [H, c, lambda] = generate_ULA_parallel(fc, M_tx, M_rx,D);
%     H_tmp = squeeze(H);
%     
%     [U, S, V] = svd(H_tmp);
%     if M_rx < M_tx
%         S(M_tx, M_tx) = 0;
%     end
%     eigen_value(i_d, :) = abs(diag(S));
%     power(i_d) = norm(diag(S)).^2;
%     rank_list(i_d) = rank(H_tmp);
% 
% end
% %% normalized singular values
% % figure;
% % hold on;
% % h1 = plot(1:min(M_tx,M_rx),eigen_value(1,1:min(M_tx,M_rx))/eigen_value(1,1),'-','color',[0.3010 0.7450 0.9330],'LineWidth',2);
% % idx = 1:5:min(M_tx,M_rx);
% % h1_1 = plot(idx,eigen_value(1,idx)/eigen_value(1,1),'^','color',[0.3010 0.7450 0.9330],'LineWidth',2);
% % h1_2 = plot(1,eigen_value(1,1)/eigen_value(1,1),'-^','color',[0.3010 0.7450 0.9330],'LineWidth',2);
% % 
% % h2 = plot(1:min(M_tx,M_rx),eigen_value(2,1:min(M_tx,M_rx))/eigen_value(2,1),'-','color',[0.8500 0.3250 0.0980],'LineWidth',2);
% % idx = 1:5:min(M_tx,M_rx);
% % h2_1 = plot(idx,eigen_value(2,idx)/eigen_value(2,1),'x','color',[0.8500 0.3250 0.0980],'LineWidth',2);
% % h2_2 = plot(1,eigen_value(2,1)/eigen_value(2,1),'-x','color',[0.8500 0.3250 0.0980],'LineWidth',2);
% % 
% % h3 = plot(1:min(M_tx,M_rx),eigen_value(3,1:min(M_tx,M_rx))/eigen_value(3,1),'-','color',[0.4940 0.1840 0.5560],'LineWidth',2);
% % idx = 1:5:min(M_tx,M_rx);
% % h3_1 = plot(idx,eigen_value(3,idx)/eigen_value(3,1),'*','color',[0.4940 0.1840 0.5560],'LineWidth',2);
% % h3_2 = plot(1,eigen_value(3,1)/eigen_value(3,1),'-*','color',[0.4940 0.1840 0.5560],'LineWidth',2);
% % 
% % h4 = plot(1:min(M_tx,M_rx),eigen_value(4,1:min(M_tx,M_rx))/eigen_value(4,1),'-','color',[0 0.4470 0.7410],'LineWidth',2);
% % idx = 1:5:min(M_tx,M_rx);
% % h4_1 = plot(idx,eigen_value(4,idx)/eigen_value(4,1),'+','color',[0 0.4470 0.7410],'LineWidth',2);
% % h4_2 = plot(1,eigen_value(4,1)/eigen_value(4,1),'-+','color',[0 0.4470 0.7410],'LineWidth',2);
% % 
% % h5 = plot(1:min(M_tx,M_rx),eigen_value(5,1:min(M_tx,M_rx))/eigen_value(5,1),'-','color',[0.6350 0.0780 0.1840],'LineWidth',2);
% % idx = 1:5:sum(eigen_value(5,1:min(M_tx,M_rx))>eps);
% % h5_1 = plot(idx,eigen_value(5,idx)/eigen_value(5,1),'s','color',[0.6350 0.0780 0.1840],'LineWidth',2);
% % h5_2 = plot(1,eigen_value(5,1)/eigen_value(5,1),'-s','color',[0.6350 0.0780 0.1840],'LineWidth',2);
% % 
% % h6 = plot(1:min(M_tx,M_rx),eigen_value(6,1:min(M_tx,M_rx))/eigen_value(6,1),'-','color',[0.9290 0.6940 0.1250], 'LineWidth',2);
% % idx = 1:5:min(M_tx,M_rx);
% % h6_1 = plot(idx,eigen_value(6,idx)/eigen_value(6,1),'o','color',[0.9290 0.6940 0.1250],'LineWidth',2);
% % h6_2 = plot(1,eigen_value(6,1)/eigen_value(6,1),'-o','color',[0.9290 0.6940 0.1250],'LineWidth',2);
% % grid on;
% 
% %% unnormalized singular values
% figure;
% hold on;
% h1 = plot(1:min(M_tx,M_rx),eigen_value(1,1:min(M_tx,M_rx)),'-','color',[0.3010 0.7450 0.9330],'LineWidth',2);
% idx = 1:5:min(M_tx,M_rx);
% h1_1 = plot(idx,eigen_value(1,idx),'^','color',[0.3010 0.7450 0.9330],'LineWidth',2);
% h1_2 = plot(1,eigen_value(1,1),'-^','color',[0.3010 0.7450 0.9330],'LineWidth',2);
% 
% h2 = plot(1:min(M_tx,M_rx),eigen_value(2,1:min(M_tx,M_rx)),'-','color',[0.8500 0.3250 0.0980],'LineWidth',2);
% idx = 1:5:min(M_tx,M_rx);
% h2_1 = plot(idx,eigen_value(2,idx),'x','color',[0.8500 0.3250 0.0980],'LineWidth',2);
% h2_2 = plot(1,eigen_value(2,1),'-x','color',[0.8500 0.3250 0.0980],'LineWidth',2);
% 
% h3 = plot(1:min(M_tx,M_rx),eigen_value(3,1:min(M_tx,M_rx)),'-','color',[0.4940 0.1840 0.5560],'LineWidth',2);
% idx = 1:5:min(M_tx,M_rx);
% h3_1 = plot(idx,eigen_value(3,idx),'*','color',[0.4940 0.1840 0.5560],'LineWidth',2);
% h3_2 = plot(1,eigen_value(3,1),'-*','color',[0.4940 0.1840 0.5560],'LineWidth',2);
% 
% h4 = plot(1:min(M_tx,M_rx),eigen_value(4,1:min(M_tx,M_rx)),'-','color',[0 0.4470 0.7410],'LineWidth',2);
% idx = 1:5:min(M_tx,M_rx);
% h4_1 = plot(idx,eigen_value(4,idx),'+','color',[0 0.4470 0.7410],'LineWidth',2);
% h4_2 = plot(1,eigen_value(4,1),'-+','color',[0 0.4470 0.7410],'LineWidth',2);
% 
% h5 = plot(1:min(M_tx,M_rx),eigen_value(5,1:min(M_tx,M_rx)),'-','color',[0.6350 0.0780 0.1840],'LineWidth',2);
% idx = 1:5:min(M_tx,M_rx);
% h5_1 = plot(idx,eigen_value(5,idx),'s','color',[0.6350 0.0780 0.1840],'LineWidth',2);
% h5_2 = plot(1,eigen_value(5,1),'-s','color',[0.6350 0.0780 0.1840],'LineWidth',2);
% 
% h6 = plot(1:min(M_tx,M_rx),eigen_value(6,1:min(M_tx,M_rx)),'-','color',[0.9290 0.6940 0.1250], 'LineWidth',2);
% idx = 1:5:min(M_tx,M_rx);
% h6_1 = plot(idx,eigen_value(6,idx),'o','color',[0.9290 0.6940 0.1250],'LineWidth',2);
% h6_2 = plot(1,eigen_value(6,1),'-o','color',[0.9290 0.6940 0.1250],'LineWidth',2);
% grid on;
% 
% %% calculate the singular values based on prolate wave function
% c_list = (Nt-1)*(Nr-1)*(lambda/2)^2*2*pi/lambda/4;
% matdim=200;
% minEigenvalRatio = 10^-10;
% 
% eigen_value_est = zeros(d_len, M_tx);
% for i_d = 1:d_len
%     D = D_list(i_d);
%     c_value = c_list/D;
%     [prolate_dat, iserr] = prolate_1d_crea(c_value,matdim, minEigenvalRatio);
%     eigen_line = abs(prolate_dat.nu)/sqrt(sum(abs(prolate_dat.nu).^2))*sqrt(Nt*Nr);
%     eigen_value_est(i_d, 1:length(prolate_dat.nu)) = eigen_line;
% end
% 
% hold on;
% h7 = plot(1:min(M_tx,M_rx),eigen_value_est(1,1:min(M_tx,M_rx)),'--','color',[0 0 0], 'LineWidth',1.2);
% h8 = plot(1:min(M_tx,M_rx),eigen_value_est(2,1:min(M_tx,M_rx)),'--','color',[0 0 0], 'LineWidth',1.2);
% h9 = plot(1:min(M_tx,M_rx),eigen_value_est(3,1:min(M_tx,M_rx)),'--','color',[0 0 0], 'LineWidth',1.2);
% h10 = plot(1:min(M_tx,M_rx),eigen_value_est(4,1:min(M_tx,M_rx)),'--','color',[0 0 0], 'LineWidth',1.2);
% h11 = plot(1:min(M_tx,M_rx),eigen_value_est(5,1:min(M_tx,M_rx)),'--','color',[0 0 0], 'LineWidth',1.2);
% h12 = plot(1:min(M_tx,M_rx),eigen_value_est(6,1:min(M_tx,M_rx)),'--','color',[0 0 0], 'LineWidth',1.2);
% 
% xlabel('Index of the singular values','FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
% ylabel('Modulus','FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
% 
% legend([h1_2,h2_2,h3_2,h4_2,h5_2,h6_2, h7], 'r = 2 m', 'r = 4 m', 'r = 8 m', 'r = 16 m', 'r = 32 m','r = 64 m','Estimation','FontSize', 13, 'Location', 'NorthEast',...
%     'Fontname', 'Times');
% axis([0 45 0 250]);
% box on;

% title('Calculated and Estimated Singular Values of ULA LoS Channel')


%% compute the capacity of different distances
start_point = 1.5;
mid_point = 20;
end_point = 300;
plot_point1 = 100;
plot_point2 = 80;
% plot_point1 = 5;
% plot_point2 = 5;
D_list = [linspace(start_point,mid_point,plot_point1),linspace(mid_point,end_point,plot_point2)];
[~, d_len] = size(D_list);

SNR_dB = -20:4:-20;
SNR_linear =10.^(SNR_dB/10.);
N_snr = length(SNR_linear);
sum_rate = zeros(d_len, N_snr);
sum_rate_est_eig = zeros(d_len, N_snr);
sum_rate_est_acc = zeros(d_len, N_snr);
power_tot = Nt*Nr;

H = generate_ULA_parallel_new(fc, Nt, Nr,D_list);

c_list = (Nt-1)*(Nr-1)*(lambda/2)^2*2*pi/lambda/4;
matdim = 256;
minEigenvalRatio = 10^-5;
eigen_value_est2 = zeros(d_len, M_tx);
for i_d = 1:d_len
    D = D_list(i_d);
    c_value = c_list/D;
    [prolate_dat, iserr] = prolate_1d_crea(c_value,matdim, minEigenvalRatio);
    eigen_line = abs(prolate_dat.nu)/sqrt(sum(abs(prolate_dat.nu).^2))*sqrt(Nt*Nr);
    if length(prolate_dat.nu) > min(M_tx, M_rx)
        eigen_line = eigen_line(1:min(M_tx, M_rx));
    end
    eigen_value_est2(i_d, 1:length(eigen_line)) = eigen_line;
end

%% DOF estimation
thre = 0.95;
eigen_value = zeros(d_len,Nr);
N_cal = zeros(1,d_len);
N_eigen = zeros(1,d_len);
for i_d = 1:d_len
    H_tmp = squeeze(H(i_d, :,:));
    [~, S, ~] = svd(H_tmp);
    eigen_value(i_d, :) = abs(diag(S));
    
    power_cnt = 0;
    eig_cnt = 0;
    for i_cnt = 1:Nt
        if power_cnt < thre*power_tot
            power_cnt = power_cnt+eigen_value(i_d,i_cnt)^2;
            eig_cnt = eig_cnt+1;
        else
            break;
        end
    end
    N_cal(i_d) = eig_cnt;
    
%     D = D_list(i_d);
%     c_value = c_list/D;
%     [prolate_dat, iserr] = prolate_1d_crea(c_value,matdim, minEigenvalRatio);
%     eigen_line = abs(prolate_dat.nu)/sqrt(sum(abs(prolate_dat.nu).^2))*sqrt(Nt*Nr);
%     eigen_value_est2(i_d, 1:length(prolate_dat.nu)) = eigen_line;
    power_cnt = 0;
    eig_cnt = 0;
    for i_cnt = 1:Nt
        if power_cnt < thre*power_tot
            power_cnt = power_cnt+eigen_value_est2(i_d,i_cnt)^2;
            eig_cnt = eig_cnt+1;
        else
            break;
        end
    end
    N_eigen(i_d) = eig_cnt;
end

%% channel DoF rough estimation 
N_est1 = zeros(1,d_len);
for i_d = 1:d_len
    H_tmp = squeeze(H(i_d, :,:));
    N_est1(i_d) = (Nt-1)*(Nr-1)*(lambda/2)^2/lambda/D_list(i_d);
end

for i_d = 1:d_len
    D = D_list(i_d);
    H_tmp = squeeze(H(i_d, :,:));
    for i_snr = 1:N_snr
        SNR = SNR_linear(i_snr);

        %% digital precoding
        [~, S, V]=svd(H_tmp);
        F_digital=V(:,1:Nt);
        power_allo_water = water_filling(S(1:Nt,1:Nt), SNR, Nr);
        sum_rate(i_d, i_snr) = abs(cal_sum_rate(Nr, H_tmp, F_digital, power_allo_water));
        
        %% accurate DoF estimation
        sum_rate_est_acc(i_d, i_snr) = N_est1(i_d)*log2(1+power_tot*SNR/N_est1(i_d)^2);
        
        %% estimation with PSWFs eigenvalues
        eigen_value_matrix = diag(eigen_value_est2(i_d,:));
        power_allo_water2 = water_filling(S(1:Nt,1:Nt), SNR, Nr);
        sum_rate_est_eig(i_d, i_snr) = sum(log2(1+diag(power_allo_water2).'.*eigen_value_est2(i_d,:).^2));
        
    end
end

%% main figure
figure;
hold_1=axes('position',[0.08 0.1 0.85 0.85]); % 创建�?个坐标系
axes(hold_1);

hold on;
idx = 1:20:plot_point1;
idx = [idx, plot_point1:5:plot_point1+plot_point2];
h1 = plot(D_list,abs(sum_rate),'-','color',[0 0 0],'LineWidth',1.2);
h1_1 = plot(D_list(idx),abs(sum_rate(idx)),'^','color',[0 0 0],'LineWidth',1.2);
h1_2 = plot(D_list(1),abs(sum_rate(1)),'-^','color',[0 0 0],'LineWidth',1.2);

h2 = plot(D_list,abs(sum_rate_est_acc),'-','color',[0 0 1],'LineWidth',1.2);
h2_1 = plot(D_list(idx),abs(sum_rate_est_acc(idx)),'x','color',[0 0 1],'LineWidth',1.2);
h2_2 = plot(D_list(1),abs(sum_rate_est_acc(1)),'-x','color',[0 0 1],'LineWidth',1.2);

h3 = plot(D_list,abs(sum_rate_est_eig),'-','color',[1 0 0],'LineWidth',1.2);
h3_1 = plot(D_list(idx),abs(sum_rate_est_eig(idx)),'o','color',[1 0 0],'LineWidth',1.2);
h3_2 = plot(D_list(1),abs(sum_rate_est_eig(1)),'-o','color',[1 0 0],'LineWidth',1.2);

h=legend([h1_2,h2_2,h3_2], 'Accurate channel DoFs', 'DoFs estimated in [1] ','DoFs estimated with PSWFs', 'FontSize',13);
set(h,'Interpreter','latex','Location','northeast');
% axis([0 35 7 30]);

xlabel('Distance of Tx and Rx (m)');
ylabel('Spectrum Efficiency (bits/s/Hz)');
grid on;
box on;

%% subfigure
hold_2=axes('Position',[0.15 0.15 0.3 0.3]);
axes(hold_2);                  % 将h2设置为当前坐标系
hold on;
% plot(D_list,N_cal, '-','color',[0.8500 0.3250 0.0980],'LineWidth',1.2)
% plot(D_list,N_est1, '-','color',[0.4940 0.1840 0.5560],'LineWidth',1.2)
% plot(D_list,N_eigen, '-','color',[0.6350 0.0780 0.1840],'LineWidth',1.2)
plot(D_list,abs(sum_rate),'-','color',[0 0 0],'LineWidth',1.2);
plot(D_list(idx),abs(sum_rate(idx)),'^','color',[0 0 0],'LineWidth',1.2);
plot(D_list,abs(sum_rate_est_acc),'-','color',[0 0 1],'LineWidth',1.2);
plot(D_list(idx),abs(sum_rate_est_acc(idx)),'x','color',[0 0 1],'LineWidth',1.2);
plot(D_list,abs(sum_rate_est_eig),'-','color',[1 0 0],'LineWidth',1.2);
plot(D_list(idx),abs(sum_rate_est_eig(idx)),'o','color',[1 0 0],'LineWidth',1.2);
axis([5 19.9 21 31]);

set(hold_2);

grid on;
box on;


