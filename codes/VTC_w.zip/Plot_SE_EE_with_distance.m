clear all;
close all;
clc;

load SE_data_Distance_0511.mat;
load EE_data_Distance_0511.mat;

N_dis = length(D_list);
idx = 1:3:N_dis;

figure;
hold on;
h1 = plot(D_list,sum_rate_digital_nf(:,1),'--','color',[0 0 0],'LineWidth',2);
h3 = plot(D_list,sum_rate_fc_nf_8(:,1),'-+','color',[0 0 1],'LineWidth',2);
h4 = plot(D_list,sum_rate_fc_nf_4(:,1),'-o','color',[0 0 1],'LineWidth',2);
h5 = plot(D_list,sum_rate_sub_8(:,1),':+','color',[0.4660 0.6740 0.1880],'LineWidth',2);
h6 = plot(D_list,sum_rate_sub_4(:,1),':o','color',[0.4660 0.6740 0.1880],'LineWidth',2);
h2 = plot(D_list,sum_rate_opt_nf_tmp(:,1),'-^','color',[1 0 0],'LineWidth',2);

xlabel('Distance (m)', 'FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
ylabel('Spectrum Efficiency (bps/Hz)', 'FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
legend([h1,h2,h3,h4,h5,h6],'Fully digital (optimal)', 'Proposed DAP architecture', 'Fully-connected, 8 RF chains', 'Fully-connected, 4 RF chains',...
    'Sub-connected, 8 RF chains', 'Sub-connected, 4 RF chains',...
    'FontSize', 13, 'Location', 'NorthEast','Fontname', 'Times');
grid on;
box on;
axis([0 100 5 45]);



figure;
hold on;
h2_1 = plot(D_list(1:N_dis), energy_efficiency_digital(1:N_dis,1),'--','color',[0 0 0],'LineWidth',2);

h2_3 = plot(D_list(1:N_dis), energy_efficiency_fc_4(1:N_dis,1),'-o','color',[0 0 1],'LineWidth',2);
h2_4 = plot(D_list(1:N_dis), energy_efficiency_sub_8(1:N_dis,1),':+','color',[0.4660 0.6740 0.1880],'LineWidth',2);
h2_5 = plot(D_list(1:N_dis), energy_efficiency_sub_4(1:N_dis,1),':o','color',[0.4660 0.6740 0.1880],'LineWidth',2);
h2_6 = plot(D_list(1:N_dis), energy_efficiency_opt_tmp(1:N_dis,1),'-^','color',[1 0 0],'LineWidth',2);
h2_2 = plot(D_list(1:N_dis), energy_efficiency_fc_8(1:N_dis,1),'-+','color',[0 0 1],'LineWidth',2);

xlabel('Distance (m)', 'FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
ylabel('Energy Efficiency (bps/Hz/mW)', 'FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
legend([h2_1,h2_2,h2_3,h2_4,h2_5,h2_6],'Fully digital', 'Fully-connected, 8 RF chains', 'Fully-connected, 4 RF chains', ...
    'Sub-connected, 8 RF chains',...
    'Sub-connected, 4 RF chains','Proposed DAP architecture', 'FontSize', 13, 'Location', 'NorthEast',...
    'Fontname', 'Times');
grid on;
box on;
axis([0 100 0.0002 0.0025]);

