clear all;
close all;
clc;

Nr = 256;
Nt = 256;
fc = 30e9;
lambda = 3e8/fc; % wavelegenth;

D_list = [1.5,2,2.5,3,4,5,6,8,10,12,14,16,20,22,28,32,40,48,60,72,80,90,100];
N_RF_digital = 256;
eps = 1e-6;

SNR_dB = 30:4:30;
SNR_linear =10.^(SNR_dB/10.);
N_snr = length(SNR_linear);

P_const = 2500;
P_rf = 160;
P_ps = 30;
P_sw = 5;
P_amp = 30;

N_iter = 10;

N_dis = length(D_list);
energy_efficiency_digital = zeros(N_dis, N_snr);
energy_efficiency_opt = zeros(N_dis, N_snr);
energy_efficiency_opt_tmp = zeros(N_dis, N_snr);
energy_efficiency_fc = zeros(N_dis, N_snr);
energy_efficiency_fc_16 = zeros(N_dis, N_snr);
energy_efficiency_fc_8 = zeros(N_dis, N_snr);
energy_efficiency_fc_4 = zeros(N_dis, N_snr);
energy_efficiency_sub = zeros(N_dis, N_snr);
energy_efficiency_sub_64 = zeros(N_dis, N_snr);
energy_efficiency_sub_32 = zeros(N_dis, N_snr);
energy_efficiency_sub_16 = zeros(N_dis, N_snr);
energy_efficiency_sub_8 = zeros(N_dis, N_snr);
energy_efficiency_sub_4 = zeros(N_dis, N_snr);
energy_efficiency_ideal = zeros(N_dis, N_snr);


sum_rate_opt_nf = zeros(N_dis, N_snr);
sum_rate_opt_nf_tmp = zeros(N_dis, N_snr);
sum_rate_digital_nf = zeros(N_dis, N_snr);
sum_rate_fc_nf = zeros(N_dis, N_snr);
sum_rate_fc_nf_16 = zeros(N_dis, N_snr);
sum_rate_fc_nf_8 = zeros(N_dis, N_snr);
sum_rate_fc_nf_4 = zeros(N_dis, N_snr);
sum_rate_sub = zeros(N_dis, N_snr);
sum_rate_sub_64 = zeros(N_dis, N_snr);
sum_rate_sub_32  = zeros(N_dis, N_snr);
sum_rate_sub_16 = zeros(N_dis, N_snr);
sum_rate_sub_8 = zeros(N_dis, N_snr);
sum_rate_sub_4 = zeros(N_dis, N_snr);
sum_rate_fc_ideal = zeros(N_dis, N_snr);


Ns_EE_record = zeros(N_dis, N_snr);
N_est1 = zeros(1,N_dis);
N_est2 = zeros(1,N_dis);
theta = 0;
for i_d = 1:length(D_list)
    d = D_list(i_d);
    [H, c, lambda] = generate_ULA_rotate(fc, Nt, Nr, d, theta);
    H_tmp = squeeze(H);
    for i_snr = 1:N_snr
        SNR = SNR_linear(i_snr);
        
        N_est1(i_d) = (Nt-1)*(Nr-1)*(lambda/2)^2/lambda/D_list(i_d)*cos(theta);
        Ns_SE0 = round(N_est1(i_d));
        N_est2(i_d) = 1+(2*(Nt-1)*(Nr-1)*(lambda/2)^2/lambda/sqrt(4*d^2+(Nr-1)^2*(lambda/2)^2));
        Ns_SE = ceil(N_est2(i_d));
        [~,S,~] = svd(H_tmp);
        power_allo_water = water_filling(S,SNR, Nr);
        Ns_SE = sum(sum(power_allo_water>0));
        
        Ns_EE = Ns_SE;
        Ns_EE_record(i_d, i_snr) = Ns_EE;
        
        %F error
        error = zeros(1,N_iter);
        error_s = zeros(1,N_iter);
        error_rf = zeros(1,N_iter);
        error_bb = zeros(1,N_iter);
        
        %% array partition
        R = H_tmp'*H_tmp;
        [S_list, S_list_num, n_sel] = dynamic_subarray_partitioning_proposed(R, Ns_EE, Nt);
        
        %% calculate the partitioning hybrid precoding
        H_par = zeros(Nr,Nt);
        cnt = 1;
        for i_rf = 1:Ns_EE
            H_par(:,cnt:cnt+S_list_num(i_rf)-1) = H_tmp(:,S_list(i_rf,1:S_list_num(i_rf)));
            cnt = cnt+S_list_num(i_rf);
        end
        
        %% digital
        [~, S, V]=svd(H_tmp);
        F_digital=V(:,1:Nt);
        power_F_hybrid_digital = norm(F_digital,'fro')^2;

        power_allo_water = water_filling(S(1:Nt,1:Nt), SNR, Nr);
        sum_rate_digital_nf(i_d, i_snr) = abs(cal_sum_rate(Nr, H_tmp, F_digital, power_allo_water));
        energy_efficiency_digital(i_d, i_snr) = sum_rate_digital_nf(i_d,i_snr)/(P_const + Nt*P_rf + P_amp*Nt);
        
        %% proposed algorithm
        N_RF = Ns_EE;
        F_rf_init = zeros(Nt, N_RF);

        cnt = 1;
        for i_rf = 1:Ns_EE
            H_sub = H_par(:,cnt:cnt+S_list_num(i_rf)-1);
            R_sub = H_sub'*H_sub;
            [~, S_sub, V_sub] = svd(R_sub);
            F_rf_init(cnt:cnt+S_list_num(i_rf)-1,i_rf) = exp(1j*angle(V_sub(:,1)))/sqrt(S_list_num(i_rf));
            cnt = cnt + S_list_num(i_rf);
        end
        f_hybrid_rf = F_rf_init;
        H_eff = H_par*f_hybrid_rf;
        
        power_par_rf = norm(f_hybrid_rf,'fro');
        
        [~,~,V] = svd(H_eff);
        f_hybrid_bb = V(:,1:N_RF);
        for i_bb = 1:N_RF
            f_hybrid_bb(:, i_bb) = f_hybrid_bb(:, i_bb)/norm(f_hybrid_rf*f_hybrid_bb(:, i_bb));
        end
        power_BB_par = norm(f_hybrid_rf*f_hybrid_bb, 'fro');
        F_hybrid = f_hybrid_rf*f_hybrid_bb;
        
        % water filling
        [~, S_eff, ~]=svd(H_eff);
        power_allo_water = water_filling(S_eff(1:N_RF,1:N_RF), SNR, Nr);
        sum_rate_opt_nf_tmp(i_d ,i_snr) = abs(cal_sum_rate(Nr, H_par, F_hybrid, power_allo_water));
        energy_efficiency_opt_tmp(i_d ,i_snr) = sum_rate_opt_nf_tmp(i_d ,i_snr)/(P_const + N_RF*P_rf + P_ps*Nt + P_amp*Nt);

        %% fully-connected AltMin 8 RF Chains
        N_RF = 8;
        [~, ~, V]=svd(H_tmp);
        F_digital=V(:,1:N_RF);
        F_hybrid_RF = PEAlt(F_digital, Nt, N_RF, N_RF);
        F_hybrid_RF = F_hybrid_RF/sqrt(Nt);

        H_eq = H_tmp*F_hybrid_RF;
        [~,~,V2] = svd(H_eq);
        F_hybrid_BB = V2(:,1:N_RF);
        for i_norm = 1:N_RF
            F_hybrid_BB(:,i_norm) = F_hybrid_BB(:,i_norm)/norm(F_hybrid_RF*F_hybrid_BB(:,i_norm), 2);
        end
        F_hybrid_BB = F_hybrid_BB/norm(F_hybrid_RF*F_hybrid_BB, 'fro')*norm(F_digital, 'fro');
        F_hybrid_Alt = F_hybrid_RF*F_hybrid_BB;

        [~, S2, ~]=svd(H_tmp*F_hybrid_RF);
        power_allo_water = water_filling(S2(1:N_RF,1:N_RF),SNR, Nr);
        sum_rate_fc_nf_8(i_d,i_snr) = abs(cal_sum_rate(Nr, H_tmp, F_hybrid_Alt, power_allo_water));
        energy_efficiency_fc_8(i_d,i_snr) = sum_rate_fc_nf_8(i_d,i_snr)/(P_const + N_RF*P_rf + N_RF*P_ps*Nt + P_amp*Nt);
        
        %% fully-connected AltMin 4 RF Chains
        N_RF = 4;
        F_digital=V(:,1:N_RF);
        F_hybrid_RF = PEAlt(F_digital, Nt, N_RF, N_RF);
        F_hybrid_RF = F_hybrid_RF/sqrt(Nt);

        H_eq = H_tmp*F_hybrid_RF;
        [~,~,V2] = svd(H_eq);
        F_hybrid_BB = V2(:,1:N_RF);
        for i_norm = 1:N_RF
            F_hybrid_BB(:,i_norm) = F_hybrid_BB(:,i_norm)/norm(F_hybrid_RF*F_hybrid_BB(:,i_norm), 2);
        end
        F_hybrid_BB = F_hybrid_BB/norm(F_hybrid_RF*F_hybrid_BB, 'fro')*norm(F_digital, 'fro');
        F_hybrid_Alt = F_hybrid_RF*F_hybrid_BB;

        [~, S2, ~]=svd(H_tmp*F_hybrid_RF);
        power_allo_water = water_filling(S2(1:N_RF,1:N_RF),SNR, Nr);
        sum_rate_fc_nf_4(i_d,i_snr) = abs(cal_sum_rate(Nr, H_tmp, F_hybrid_Alt, power_allo_water));
        energy_efficiency_fc_4(i_d,i_snr) = sum_rate_fc_nf_4(i_d,i_snr)/(P_const + N_RF*P_rf + N_RF*P_ps*Nt + P_amp*Nt);
       

        %% sub-connected 8 RF chains
        N_RF = 8;
        M = Nt/N_RF;
        [F_sub_hybrid, F_sub_hybrid_RF, F_sub_hybrid_BB] = sub_spatially_precoding(N_RF,Nt,Nr,M,H_tmp,SNR);
        F_sub_hybrid_RF = F_sub_hybrid_RF/sqrt(N_RF);
        H_eq = H_tmp*F_sub_hybrid_RF;
        [~,~,V] = svd(H_eq);
        F_sub_hybrid_BB = V(:,1:N_RF);
        for i_norm = 1:N_RF
            F_sub_hybrid_BB(:,i_norm) = F_sub_hybrid_BB(:,i_norm)/norm(F_sub_hybrid_RF*F_sub_hybrid_BB(:,i_norm), 2);
        end
        F_hybrid_sub = F_sub_hybrid_RF*F_sub_hybrid_BB;

        [~, S2, ~]=svd(H_tmp*F_sub_hybrid_RF);
        power_allo_water = water_filling(S2(1:N_RF,1:N_RF),SNR, Nr);
        sum_rate_sub_8(i_d, i_snr) = abs(cal_sum_rate(Nr, H_tmp, F_sub_hybrid, SNR/N_RF*eye(N_RF)));
        energy_efficiency_sub_8(i_d, i_snr) = sum_rate_sub_8(i_d,i_snr)/(P_const + N_RF*P_rf + Nt*P_ps + P_amp*Nt);
       
        %% sub-connected 4 RF chains
        N_RF = 4;
        M = Nt/N_RF;
        [F_sub_hybrid, F_sub_hybrid_RF, F_sub_hybrid_BB] = sub_spatially_precoding(N_RF,Nt,Nr,M,H_tmp,SNR);
        F_sub_hybrid_RF = F_sub_hybrid_RF/sqrt(N_RF);
        H_eq = H_tmp*F_sub_hybrid_RF;
        [~,~,V] = svd(H_eq);
        F_sub_hybrid_BB = V(:,1:N_RF);
        for i_norm = 1:N_RF
            F_sub_hybrid_BB(:,i_norm) = F_sub_hybrid_BB(:,i_norm)/norm(F_sub_hybrid_RF*F_sub_hybrid_BB(:,i_norm), 2);
        end
        F_hybrid_sub = F_sub_hybrid_RF*F_sub_hybrid_BB;

        [~, S2, ~]=svd(H_tmp*F_sub_hybrid_RF);
        power_allo_water = water_filling(S2(1:N_RF,1:N_RF),SNR, Nr);
        sum_rate_sub_4(i_d, i_snr) = abs(cal_sum_rate(Nr, H_tmp, F_sub_hybrid, SNR/N_RF*eye(N_RF)));
        energy_efficiency_sub_4(i_d, i_snr) = sum_rate_sub_4(i_d,i_snr)/(P_const + N_RF*P_rf + Nt*P_ps + P_amp*Nt);

    end
end

figure;
hold on;
plot(D_list,sum_rate_digital_nf(:,1),'--','color',[0 0 0],'LineWidth',2);
plot(D_list,sum_rate_opt_nf_tmp(:,1),'-^','color',[0.6350 0.0780 0.1840],'LineWidth',2);
plot(D_list,sum_rate_fc_nf_8(:,1),'-+','color',[0.4940 0.1840 0.5560],'LineWidth',2);
plot(D_list,sum_rate_fc_nf_4(:,1),'-o','color',[0.4940 0.1840 0.5560],'LineWidth',2);
plot(D_list,sum_rate_sub_8(:,1),'-+','color',[0.4660 0.6740 0.1880],'LineWidth',2);
plot(D_list,sum_rate_sub_4(:,1),'-o','color',[0.4660 0.6740 0.1880],'LineWidth',2);



xlabel('Distance (m)', 'FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
ylabel('Spectrum Efficiency (bps/Hz)', 'FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
legend('Digital','Proposed DAP architecture', 'Fully-connected 8 RF chains', 'Fully-connected 4 RF chains',...
    'Sub-connected 8 RF chains', 'Sub-connected 4 RF chains', 'FontSize', 13, 'Location', 'NorthEast',...
    'Fontname', 'Times');
grid on;


figure;
hold on;
plot(D_list(1:N_dis), energy_efficiency_digital(1:N_dis,1),'--','color',[0 0 0],'LineWidth',2);
plot(D_list(1:N_dis), energy_efficiency_opt_tmp(1:N_dis,1),'-^','color',[0.6350 0.0780 0.1840],'LineWidth',2);
plot(D_list(1:N_dis), energy_efficiency_fc_8(1:N_dis,1),'-+','color',[0.4940 0.1840 0.5560],'LineWidth',2);
plot(D_list(1:N_dis), energy_efficiency_fc_4(1:N_dis,1),'-o','color',[0.4940 0.1840 0.5560],'LineWidth',2);
plot(D_list(1:N_dis), energy_efficiency_sub_8(1:N_dis,1),'-+','color',[0.4660 0.6740 0.1880],'LineWidth',2);
plot(D_list(1:N_dis), energy_efficiency_sub_4(1:N_dis,1),'-o','color',[0.4660 0.6740 0.1880],'LineWidth',2);



xlabel('Distance (m)', 'FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
ylabel('Energy Efficiency (bps/Hz/mW)', 'FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
legend('Digital', 'Proposed DAP architecture', 'Fully-connected 8 RF chains', 'Fully-connected 4 RF chains', ...
    'Sub-connected 8 RF chains',...
    'Sub-connected 4 RF chains', 'FontSize', 13, 'Location', 'NorthEast',...
    'Fontname', 'Times');
grid on;

save('SE_data_Distance_0511','D_list','sum_rate_digital_nf','sum_rate_opt_nf_tmp','sum_rate_fc_nf_8','sum_rate_fc_nf_4'...
    ,'sum_rate_sub_8','sum_rate_sub_4');
save('EE_data_Distance_0511','D_list','energy_efficiency_digital','energy_efficiency_opt_tmp','energy_efficiency_fc_8','energy_efficiency_fc_4'...
    ,'energy_efficiency_sub_8','energy_efficiency_sub_4');