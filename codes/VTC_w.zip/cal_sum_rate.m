function [sum_rate] = cal_sum_rate(Nr, H, F_digital, power_allo_water)
%CAL_SUM_RATE 此处显示有关此函数的摘要
%   此处显示详细说明


% temp = 0;
% for i_sub = 1:Ns
%     temp = temp+log2(1+S2(i_sub,i_sub)^2*power_allo_water(i_sub,i_sub));
% end

eigen = eig(eye(Nr) +  H * F_digital *power_allo_water* F_digital' *  H');
temp = sum(log2(eigen));
sum_rate = temp;
end

