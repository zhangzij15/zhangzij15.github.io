function [S_list,S_list_num, n_sel] = dynamic_subarray_partitioning_proposed(R, Nt_RF, Nt)

n_sel = 0;
S_list = zeros(Nt_RF+1, Nt);
S_list(Nt_RF+1,:) = 1:Nt;
S_list_num = zeros(1, Nt_RF+1);
S_list_num(Nt_RF+1) = Nt;
S0 = (Nt_RF+1)*ones(1,Nt);

%% initialization with uniform distributed arrays plan 1
num_group = floor(Nt/Nt_RF);
num_group_upbound = round(num_group*2);

R_up = abs(triu(R,1));
R_up_tmp = R_up;

for i_tmp = 1:Nt_RF
    loc = num_group*(i_tmp-1)+1;
    S0(loc) = i_tmp;
    S_list_num(i_tmp) = S_list_num(i_tmp)+1;
    S_list(i_tmp, S_list_num(i_tmp)) = loc;
    S_list_num(Nt_RF+1) = S_list_num(Nt_RF+1) - 1;
    line = S_list(Nt_RF+1,:);
    line(line==loc) = [];
    S_list(Nt_RF+1,1:length(line)) = line;
    S_list(Nt_RF+1,length(line)+1:end) = 0;
    R_up_tmp(:, loc) = 0;
end


%% add the largest item per row
linear_list = linspace(1,Nt,Nt);
for i = 1:Nt-Nt_RF
    S_select = (S0~=Nt_RF+1);
    R_select = R_up_tmp(S_select,:);
    [R_max, R_max_idx] = max(R_select, [], 2);
    [R_max_max, R_max_max_idx] = max(R_max);
    target_array = R_max_idx(R_max_max_idx);
    
    fr_add = zeros(1,Nt_RF);
    for j = 1:Nt_RF
        set_number2 = j;
        S_list_num_new = S_list_num(set_number2)+1;
        S_list_new = S_list(set_number2,:);
        S_list_new(S_list_num_new) = target_array;
        fr_add(j) = fr(R, S_list_num_new, S_list_new, 0, Nt_RF, 0) - ...
            fr(R, S_list_num(set_number2), S_list(set_number2,:), 0, Nt_RF, 0);
    end
    [~, fr_max_idx] = max(fr_add);
    set_number = fr_max_idx;
    S_list_num(set_number) = S_list_num(set_number)+1;
    S_list(set_number,S_list_num(set_number)) = target_array;
    S_list_num(Nt_RF+1) = S_list_num(Nt_RF+1) - 1;
    line = S_list(Nt_RF+1,:);
    line(line==target_array) = [];
    S_list(Nt_RF+1,1:length(line)) = line;
    S_list(Nt_RF+1,length(line)+1:end) = 0;
    S0(target_array) = set_number;
    R_up_tmp(:, target_array) = 0;
    if S_list_num(set_number) >= num_group_upbound
        R_sub = R(S_list(set_number,1:S_list_num(set_number)),S_list(set_number,1:S_list_num(set_number)));
        sum_row = sum(abs(R_sub),2);
        [~,target_row_idx] = min(sum_row);
        target_row = S_list(set_number, target_row_idx);
        fr_add_new = 0*ones(1,Nt_RF);
        for i_sub_array = 1:Nt_RF
            if i_sub_array~=set_number && S_list_num(i_sub_array) < num_group_upbound
                set_number_new = i_sub_array;
                S_list_num_new = S_list_num(set_number_new)+1;
                S_list_new = S_list(set_number_new,:);
                S_list_new(S_list_num_new) = target_row;
                fr_add_new(i_sub_array) = fr(R, S_list_num_new, S_list_new, 0, Nt_RF, 0) - ...
                    fr(R, S_list_num(set_number_new), S_list(set_number_new,:), 0, Nt_RF, 0);
            end
        end
        [fr_add_new_max, add_set] = max(fr_add_new);
        if fr_add_new_max> 0
            S_list_num(add_set) = S_list_num(add_set)+1;
            S_list(add_set,S_list_num(add_set)) = target_row;
            S_list_num(set_number) = S_list_num(set_number) - 1;
            line = S_list(set_number,:);
            line(line==target_row) = [];
            S_list(set_number,1:length(line)) = line;
            S_list(set_number,length(line)+1:end) = 0;
            S0(target_row) = add_set;
        end
    end

end
for i_iter2 = 1:Nt_RF
    R_sub = R(S_list(i_iter2,1:S_list_num(i_iter2)),S_list(i_iter2,1:S_list_num(i_iter2)));
    sum_row = sum(abs(R_sub),2);
    [~,target_row_idx] = min(sum_row);
    target_row = S_list(i_iter2, target_row_idx);
    fr_add_new = 0*ones(1,Nt_RF);
    for i_sub_array = 1:Nt_RF
        if i_sub_array~=i_iter2 && S_list_num(i_sub_array) < num_group_upbound
            set_number_new = i_sub_array;
            S_list_num_new = S_list_num(set_number_new)+1;
            S_list_new = S_list(set_number_new,:);
            S_list_new(S_list_num_new) = target_row;
            fr_add_new(i_sub_array) = fr(R, S_list_num_new, S_list_new, 0, Nt_RF, 0) - ...
                fr(R, S_list_num(set_number_new), S_list(set_number_new,:), 0, Nt_RF, 0);
        end
    end
    [fr_add_new_max, add_set] = max(fr_add_new);
    if fr_add_new_max> 0
        S_list_num(add_set) = S_list_num(add_set)+1;
        S_list(add_set,S_list_num(add_set)) = target_row;
        S_list_num(i_iter2) = S_list_num(i_iter2) - 1;
        line = S_list(i_iter2,:);
        line(line==target_row) = [];
        S_list(i_iter2,1:length(line)) = line;
        S_list(i_iter2,length(line)+1:end) = 0;
        S0(target_row) = add_set;
    end
end


end

