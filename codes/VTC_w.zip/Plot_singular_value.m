close all; clc;
clear all;

fc = 30e9;
B = 5e9;
M_tx = 256;
M_rx = 256;
Nt = M_tx;
Nr = M_rx;

c = 3e8;
eps = 1e-2;

lambda = c/fc;

d_near = 2*(M_tx*lambda/2)^2/lambda;

tx_start = -(M_tx/2-0.5)*lambda;
tx_loc = tx_start:lambda:-tx_start;

rx_start = -(M_rx/2-0.5)*lambda;
rx_loc = rx_start:lambda:-rx_start;

D_list = [5,8,12,16,32,64,128];
[~, d_len] = size(D_list);
eigen_value = zeros(d_len, M_tx);
power = zeros(1,d_len);
rank_list = zeros(1,d_len);
for i_d = 1:d_len
    D = D_list(i_d);

    [H, c, lambda] = generate_ULA_parallel(fc, M_tx, M_rx,D);
    H_tmp = squeeze(H);
    
    [U, S, V] = svd(H_tmp);
    if M_rx < M_tx
        S(M_tx, M_tx) = 0;
    end
    eigen_value(i_d, :) = abs(diag(S));
    power(i_d) = norm(diag(S)).^2;
    rank_list(i_d) = rank(H_tmp);

end

%% unnormalized singular values
figure;
hold on;
h1 = plot(1:min(M_tx,M_rx),eigen_value(1,1:min(M_tx,M_rx)),'-','color',[0.3010 0.7450 0.9330],'LineWidth',2);
idx = 1:5:min(M_tx,M_rx);
h1_1 = plot(idx,eigen_value(1,idx),'^','color',[0.3010 0.7450 0.9330],'LineWidth',2);
h1_2 = plot(1,eigen_value(1,1),'-^','color',[0.3010 0.7450 0.9330],'LineWidth',2);

h2 = plot(1:min(M_tx,M_rx),eigen_value(2,1:min(M_tx,M_rx)),'-','color',[0.8500 0.3250 0.0980],'LineWidth',2);
idx = 1:5:min(M_tx,M_rx);
h2_1 = plot(idx,eigen_value(2,idx),'x','color',[0.8500 0.3250 0.0980],'LineWidth',2);
h2_2 = plot(1,eigen_value(2,1),'-x','color',[0.8500 0.3250 0.0980],'LineWidth',2);

h3 = plot(1:min(M_tx,M_rx),eigen_value(3,1:min(M_tx,M_rx)),'-','color',[0.4940 0.1840 0.5560],'LineWidth',2);
idx = 1:5:min(M_tx,M_rx);
h3_1 = plot(idx,eigen_value(3,idx),'*','color',[0.4940 0.1840 0.5560],'LineWidth',2);
h3_2 = plot(1,eigen_value(3,1),'-*','color',[0.4940 0.1840 0.5560],'LineWidth',2);

h4 = plot(1:min(M_tx,M_rx),eigen_value(4,1:min(M_tx,M_rx)),'-','color',[0 0.4470 0.7410],'LineWidth',2);
idx = 1:5:min(M_tx,M_rx);
h4_1 = plot(idx,eigen_value(4,idx),'+','color',[0 0.4470 0.7410],'LineWidth',2);
h4_2 = plot(1,eigen_value(4,1),'-+','color',[0 0.4470 0.7410],'LineWidth',2);

h5 = plot(1:min(M_tx,M_rx),eigen_value(5,1:min(M_tx,M_rx)),'-','color',[0.6350 0.0780 0.1840],'LineWidth',2);
idx = 1:5:min(M_tx,M_rx);
h5_1 = plot(idx,eigen_value(5,idx),'s','color',[0.6350 0.0780 0.1840],'LineWidth',2);
h5_2 = plot(1,eigen_value(5,1),'-s','color',[0.6350 0.0780 0.1840],'LineWidth',2);

h6 = plot(1:min(M_tx,M_rx),eigen_value(6,1:min(M_tx,M_rx)),'-','color',[0.9290 0.6940 0.1250], 'LineWidth',2);
idx = 1:5:min(M_tx,M_rx);
h6_1 = plot(idx,eigen_value(6,idx),'o','color',[0.9290 0.6940 0.1250],'LineWidth',2);
h6_2 = plot(1,eigen_value(6,1),'-o','color',[0.9290 0.6940 0.1250],'LineWidth',2);
grid on;

%% calculate the singular values based on prolate wave function
c_list = (Nt-1)*(Nr-1)*(lambda/2)^2*2*pi/lambda/4;
matdim=200;
minEigenvalRatio = 10^-10;

eigen_value_est = zeros(d_len, M_tx);
for i_d = 1:d_len
    D = D_list(i_d);
    c_value = c_list/D;
    [prolate_dat, iserr] = prolate_1d_crea(c_value,matdim, minEigenvalRatio);
    eigen_line = abs(prolate_dat.nu)/sqrt(sum(abs(prolate_dat.nu).^2))*sqrt(Nt*Nr);
    eigen_value_est(i_d, 1:length(prolate_dat.nu)) = eigen_line;
end

hold on;
h7 = plot(1:min(M_tx,M_rx),eigen_value_est(1,1:min(M_tx,M_rx)),'--','color',[0 0 0], 'LineWidth',1.2);
h8 = plot(1:min(M_tx,M_rx),eigen_value_est(2,1:min(M_tx,M_rx)),'--','color',[0 0 0], 'LineWidth',1.2);
h9 = plot(1:min(M_tx,M_rx),eigen_value_est(3,1:min(M_tx,M_rx)),'--','color',[0 0 0], 'LineWidth',1.2);
h10 = plot(1:min(M_tx,M_rx),eigen_value_est(4,1:min(M_tx,M_rx)),'--','color',[0 0 0], 'LineWidth',1.2);
h11 = plot(1:min(M_tx,M_rx),eigen_value_est(5,1:min(M_tx,M_rx)),'--','color',[0 0 0], 'LineWidth',1.2);
h12 = plot(1:min(M_tx,M_rx),eigen_value_est(6,1:min(M_tx,M_rx)),'--','color',[0 0 0], 'LineWidth',1.2);

xlabel('Index of the singular values','FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
ylabel('Modulus','FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');

legend([h1_2,h2_2,h3_2,h4_2,h5_2,h6_2, h7], 'r = 5 m', 'r = 8 m', 'r = 12 m', 'r = 16 m', 'r = 32 m','r = 64 m','Estimation','FontSize', 13, 'Location', 'NorthEast',...
    'Fontname', 'Times');
axis([0 60 0 200]);
box on;



