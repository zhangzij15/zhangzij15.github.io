
This simulation code package is mainly used to reproduce the results of the following paper [1]:

[1] K. Liu, Z. Zhang, L. Dai, S. Xu, and F. Yang, ��Active Reconfigurable Intelligent Surface: Fully-Connected or Sub-Connected?,�� IEEE Commun. Lett., vol. 26, no. 1, pp. 167-171, Jan. 2022.

*********************************************************************************************************************************
If you use this simulation code package in any way, please cite the original paper [1] above. 
 
The author in charge of this simulation code package is: Kunzan Liu (email: lkz18@mails.tsinghua.edu.cn).

Reference: We highly respect reproducible research, so we try to provide the simulation codes for our published papers (more information can be found at: 
http://oa.ee.tsinghua.edu.cn/dailinglong/publications/publications.html). 

Please note that the MATLAB R2019b is used for this simulation code package, and there may be some incompatibility problems among different MATLAB versions. 

Copyright reserved by the Broadband Communications and Signal Processing Laboratory (led by Dr. Linglong Dai), Beijing National Research Center for Information Science and Technology (BNRist), Department of Electronic Engineering, Tsinghua University, Beijing 100084, China. 

*********************************************************************************************************************************
Abstract of the paper: 

To overcome the ��multiplicative fading effect�� introduced by passive reconfigurable intelligent surface (RIS), the concept of active RIS has been recently proposed to amplify the radiated signals. However, the existing fully-connected architecture of active RIS consumes high power due to the additionally integrated active components. To address this issue, we propose the sub-connected architecture of active RIS. Different from fully-connected architecture, where each element integrates a dedicated power amplifier, in the sub-connected architecture, multiple elements control their phase shifts independently but share a same power amplifier, which significantly reduces the number of power amplifiers for power saving at the cost of fewer degrees of freedom (DoFs) for beamforming design. Fortunately, our analysis reveals that performance loss introduced by the sub-connected architecture is slight, indicating that it can achieve much higher energy efficiency (EE). Furthermore, we formulate the EE maximization problem in the active RIS-aided system for both architectures and develop a corresponding joint beamforming design. Simulation results verify the proposed sub-connected architecture as an energy-efficient realization of active RIS.
*********************************************************************************************************************************
How to use this simulation code package?

All figures can be derived by running the corresponding m file.

The simulation results in Fig. 2 can be directly obtained by running Main_dist2EE.m. 

The simulation results in Table 2 can be directly obtained by running Main_T2EE.m.

For simulation results on active RIS with fully-connected architecture, we refer readers to the package that is also provided in our website.

Note that it may cost much time for simulation, thus you can simply reduce the number of repetitions by changing algorithmic parameters like "Iteration" and "Dink_max" for shorter computational time. This may also reduce the smoothness of the curves at the same time.
*********************************************************************************************************************************
Enjoy the reproducible research!